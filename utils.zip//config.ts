// App configuration utility
export const config = {
  // App info
  app: {
    name: process.env.REACT_APP_APP_NAME || 'Networking BudE',
    description: process.env.REACT_APP_APP_DESCRIPTION || 'Professional networking platform',
    version: process.env.REACT_APP_VERSION || '1.0.0',
    url: process.env.REACT_APP_APP_URL || 'http://localhost:3000',
    company: process.env.REACT_APP_COMPANY_NAME || 'The BudE System™',
  },

  // Environment
  env: {
    isDevelopment: process.env.NODE_ENV === 'development',
    isProduction: process.env.NODE_ENV === 'production',
    environment: process.env.REACT_APP_ENVIRONMENT || 'development',
  },

  // API configuration
  api: {
    baseUrl: process.env.REACT_APP_API_URL || '/api',
    websocketUrl: process.env.REACT_APP_WEBSOCKET_URL || 'ws://localhost:3001',
    uploadUrl: process.env.REACT_APP_UPLOAD_URL || '/api/uploads',
    timeout: 10000,
    useMockData: process.env.REACT_APP_MOCK_API === 'true',
  },

  // Feature flags
  features: {
    messaging: process.env.REACT_APP_ENABLE_MESSAGING !== 'false',
    events: process.env.REACT_APP_ENABLE_EVENTS !== 'false',
    connections: process.env.REACT_APP_ENABLE_CONNECTIONS !== 'false',
    analytics: process.env.REACT_APP_ENABLE_ANALYTICS === 'true',
    debugMode: process.env.REACT_APP_DEBUG_MODE === 'true',
  },

  // External services
  services: {
    unsplash: {
      accessKey: process.env.REACT_APP_UNSPLASH_ACCESS_KEY,
    },
    googleMaps: {
      apiKey: process.env.REACT_APP_GOOGLE_MAPS_API_KEY,
    },
    analytics: {
      googleAnalyticsId: process.env.REACT_APP_GOOGLE_ANALYTICS_ID,
      mixpanelToken: process.env.REACT_APP_MIXPANEL_TOKEN,
    },
    auth: {
      linkedinClientId: process.env.REACT_APP_LINKEDIN_CLIENT_ID,
      googleClientId: process.env.REACT_APP_GOOGLE_CLIENT_ID,
    },
  },

  // Security settings
  security: {
    sessionTimeout: parseInt(process.env.REACT_APP_SESSION_TIMEOUT || '86400000'),
    maxFileSize: parseInt(process.env.REACT_APP_MAX_FILE_SIZE || '10485760'),
  },

  // UI settings
  ui: {
    pageSize: 20,
    mobileBreakpoint: 768,
    tabletBreakpoint: 1024,
    maxUploadSizeMB: 10,
  },

  // App constants
  constants: {
    brandColor: '#22c55e',
    supportEmail: 'support@networking-bude.com',
    maxProfileImageSize: 5 * 1024 * 1024, // 5MB
    maxSkills: 20,
    maxInterests: 15,
    maxBioLength: 500,
    minPasswordLength: 8,
  },

  // Storage keys
  storage: {
    userSession: 'networking-bude-session',
    preferences: 'networking-bude-preferences',
    tempData: 'networking-bude-temp',
    onboardingProgress: 'networking-bude-onboarding',
  },

  // URLs and routes
  routes: {
    home: '/',
    dashboard: '/dashboard',
    events: '/events',
    connections: '/connections',
    messenger: '/messenger',
    profile: '/profile',
    settings: '/settings',
  },

  // Development helpers
  dev: {
    logLevel: process.env.REACT_APP_LOG_LEVEL || 'error',
    showReduxDevTools: process.env.NODE_ENV === 'development',
    enableHMR: process.env.NODE_ENV === 'development',
  },
};

// Validation helper
export const validateConfig = () => {
  const errors: string[] = [];

  // Check required environment variables for production
  if (config.env.isProduction) {
    if (!config.api.baseUrl) {
      errors.push('REACT_APP_API_URL is required in production');
    }
    
    if (!config.services.analytics.googleAnalyticsId && config.features.analytics) {
      errors.push('Google Analytics ID is required when analytics are enabled');
    }
  }

  // Log validation results
  if (errors.length > 0) {
    console.error('Configuration validation failed:', errors);
    throw new Error(`Configuration validation failed: ${errors.join(', ')}`);
  }

  if (config.env.isDevelopment) {
    console.log('✅ Configuration validated successfully');
    console.log('📊 Feature flags:', config.features);
    console.log('🔧 API config:', {
      baseUrl: config.api.baseUrl,
      useMockData: config.api.useMockData,
    });
  }
};

// Helper to get feature flag status
export const isFeatureEnabled = (feature: keyof typeof config.features): boolean => {
  return config.features[feature] ?? false;
};

// Helper to get API endpoint
export const getApiUrl = (endpoint: string): string => {
  return `${config.api.baseUrl}${endpoint.startsWith('/') ? '' : '/'}${endpoint}`;
};

// Helper to check if development mode
export const isDev = (): boolean => {
  return config.env.isDevelopment;
};

// Helper to check if production mode
export const isProd = (): boolean => {
  return config.env.isProduction;
};

// Initialize configuration validation
if (typeof window !== 'undefined') {
  try {
    validateConfig();
  } catch (error) {
    console.error('Configuration initialization failed:', error);
  }
}

export default config;