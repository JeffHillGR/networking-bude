import { FormValidation } from '../types';

// Validation rule types
type ValidationRule = {
  required?: boolean;
  minLength?: number;
  maxLength?: number;
  pattern?: RegExp;
  custom?: (value: any) => string | null;
};

type ValidationRules = Record<string, ValidationRule>;

// Common validation patterns
export const VALIDATION_PATTERNS = {
  email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  phone: /^\+?[\d\s\-\(\)]{10,}$/,
  url: /^https?:\/\/.+/,
  linkedin: /^https?:\/\/(www\.)?linkedin\.com\/in\/.+/,
  noSpecialChars: /^[a-zA-Z0-9\s]+$/,
  alphanumeric: /^[a-zA-Z0-9]+$/,
};

// Common validation messages
export const VALIDATION_MESSAGES = {
  required: 'This field is required',
  email: 'Please enter a valid email address',
  minLength: (min: number) => `Must be at least ${min} characters`,
  maxLength: (max: number) => `Must be no more than ${max} characters`,
  pattern: 'Please enter a valid format',
  phone: 'Please enter a valid phone number',
  url: 'Please enter a valid URL',
  linkedin: 'Please enter a valid LinkedIn URL',
};

// Main validation function
export function validateField(value: any, rules: ValidationRule): string | null {
  // Required validation
  if (rules.required && (!value || (typeof value === 'string' && !value.trim()))) {
    return VALIDATION_MESSAGES.required;
  }

  // Skip other validations if field is empty and not required
  if (!value || (typeof value === 'string' && !value.trim())) {
    return null;
  }

  // Min length validation
  if (rules.minLength && value.length < rules.minLength) {
    return VALIDATION_MESSAGES.minLength(rules.minLength);
  }

  // Max length validation
  if (rules.maxLength && value.length > rules.maxLength) {
    return VALIDATION_MESSAGES.maxLength(rules.maxLength);
  }

  // Pattern validation
  if (rules.pattern && !rules.pattern.test(value)) {
    return VALIDATION_MESSAGES.pattern;
  }

  // Custom validation
  if (rules.custom) {
    return rules.custom(value);
  }

  return null;
}

// Validate entire form
export function validateForm(data: Record<string, any>, rules: ValidationRules): FormValidation {
  const errors: Record<string, string> = {};

  for (const [field, fieldRules] of Object.entries(rules)) {
    const error = validateField(data[field], fieldRules);
    if (error) {
      errors[field] = error;
    }
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}

// Specific validation functions
export const validators = {
  email: (value: string): string | null => {
    if (!value) return null;
    return VALIDATION_PATTERNS.email.test(value) ? null : VALIDATION_MESSAGES.email;
  },

  phone: (value: string): string | null => {
    if (!value) return null;
    return VALIDATION_PATTERNS.phone.test(value) ? null : VALIDATION_MESSAGES.phone;
  },

  linkedin: (value: string): string | null => {
    if (!value) return null;
    return VALIDATION_PATTERNS.linkedin.test(value) ? null : VALIDATION_MESSAGES.linkedin;
  },

  url: (value: string): string | null => {
    if (!value) return null;
    return VALIDATION_PATTERNS.url.test(value) ? null : VALIDATION_MESSAGES.url;
  },

  password: (value: string): string | null => {
    if (!value) return null;
    if (value.length < 8) return 'Password must be at least 8 characters';
    if (!/(?=.*[a-z])/.test(value)) return 'Password must contain a lowercase letter';
    if (!/(?=.*[A-Z])/.test(value)) return 'Password must contain an uppercase letter';
    if (!/(?=.*\d)/.test(value)) return 'Password must contain a number';
    return null;
  },

  confirmPassword: (value: string, originalPassword: string): string | null => {
    if (!value) return null;
    return value === originalPassword ? null : 'Passwords do not match';
  },

  name: (value: string): string | null => {
    if (!value) return null;
    if (value.length < 2) return 'Name must be at least 2 characters';
    if (value.length > 50) return 'Name must be no more than 50 characters';
    if (!/^[a-zA-Z\s\-']+$/.test(value)) return 'Name contains invalid characters';
    return null;
  },

  company: (value: string): string | null => {
    if (!value) return null;
    if (value.length < 2) return 'Company name must be at least 2 characters';
    if (value.length > 100) return 'Company name must be no more than 100 characters';
    return null;
  },

  title: (value: string): string | null => {
    if (!value) return null;
    if (value.length < 2) return 'Title must be at least 2 characters';
    if (value.length > 100) return 'Title must be no more than 100 characters';
    return null;
  },

  bio: (value: string): string | null => {
    if (!value) return null;
    if (value.length > 500) return 'Bio must be no more than 500 characters';
    return null;
  },

  skills: (value: string[]): string | null => {
    if (!Array.isArray(value)) return 'Skills must be a list';
    if (value.length > 20) return 'You can select up to 20 skills';
    return null;
  },

  interests: (value: string[]): string | null => {
    if (!Array.isArray(value)) return 'Interests must be a list';
    if (value.length > 15) return 'You can select up to 15 interests';
    return null;
  },
};

// Validation rule presets for common forms
export const VALIDATION_RULES = {
  onboarding: {
    firstName: { required: true, minLength: 2, maxLength: 50, custom: validators.name },
    lastName: { required: true, minLength: 2, maxLength: 50, custom: validators.name },
    email: { required: true, custom: validators.email },
    title: { required: true, custom: validators.title },
    company: { required: true, custom: validators.company },
    bio: { custom: validators.bio },
    skills: { custom: validators.skills },
    interests: { custom: validators.interests },
  },

  profile: {
    firstName: { required: true, custom: validators.name },
    lastName: { required: true, custom: validators.name },
    title: { required: true, custom: validators.title },
    company: { required: true, custom: validators.company },
    bio: { custom: validators.bio },
    skills: { custom: validators.skills },
    interests: { custom: validators.interests },
  },

  contact: {
    name: { required: true, custom: validators.name },
    email: { required: true, custom: validators.email },
    message: { required: true, minLength: 10, maxLength: 1000 },
  },

  settings: {
    email: { required: true, custom: validators.email },
    currentPassword: { required: true },
    newPassword: { custom: validators.password },
    confirmPassword: { 
      custom: (value: string, formData: any) => 
        validators.confirmPassword(value, formData?.newPassword) 
    },
  },
};

// Real-time validation hook
export function useFormValidation(initialData: Record<string, any>, rules: ValidationRules) {
  const [data, setData] = useState(initialData);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  const validateField = useCallback((field: string, value: any) => {
    const fieldRules = rules[field];
    if (!fieldRules) return null;

    return validateField(value, fieldRules);
  }, [rules]);

  const handleChange = useCallback((field: string, value: any) => {
    setData(prev => ({ ...prev, [field]: value }));

    // Validate field if it has been touched
    if (touched[field]) {
      const error = validateField(field, value);
      setErrors(prev => ({
        ...prev,
        [field]: error || '',
      }));
    }
  }, [touched, validateField]);

  const handleBlur = useCallback((field: string) => {
    setTouched(prev => ({ ...prev, [field]: true }));
    
    const error = validateField(field, data[field]);
    setErrors(prev => ({
      ...prev,
      [field]: error || '',
    }));
  }, [data, validateField]);

  const validateAll = useCallback(() => {
    const validation = validateForm(data, rules);
    setErrors(validation.errors);
    
    // Mark all fields as touched
    const allTouched = Object.keys(rules).reduce((acc, field) => {
      acc[field] = true;
      return acc;
    }, {} as Record<string, boolean>);
    setTouched(allTouched);

    return validation;
  }, [data, rules]);

  const reset = useCallback(() => {
    setData(initialData);
    setErrors({});
    setTouched({});
  }, [initialData]);

  return {
    data,
    errors,
    touched,
    handleChange,
    handleBlur,
    validateAll,
    reset,
    isValid: Object.keys(errors).length === 0,
  };
}