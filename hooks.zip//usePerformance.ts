// Performance monitoring hook - Stub implementation
import { useCallback } from 'react';

interface PerformanceConfig {
  enableLogging?: boolean;
  enableAnalytics?: boolean;
  sampleRate?: number;
}

export function usePerformance(config: PerformanceConfig = {}) {
  const finalConfig = {
    enableLogging: false,
    enableAnalytics: false,
    sampleRate: 0.1,
    ...config
  };
  const measureRoute = useCallback((routeName: string) => {
    const startTime = performance.now();
    return () => {
      const endTime = performance.now();
      if (finalConfig.enableLogging) {
        console.log(`Route ${routeName} took ${endTime - startTime}ms`);
      }
    };
  }, [finalConfig.enableLogging]);

  const logMetric = useCallback((name: string, value: number) => {
    if (finalConfig.enableLogging) {
      console.log(`Metric ${name}: ${value}`);
    }
  }, [finalConfig.enableLogging]);

  return {
    measureRoute,
    logMetric
  };
}