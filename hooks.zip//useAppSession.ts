// Enhanced session management hook - Extracted from App.tsx for better organization
import { useState, useCallback, useEffect } from 'react';
import { UserData } from '../types';

interface SessionConfig {
  sessionKey: string;
  expiryKey: string;
  expiryDuration: number; // in milliseconds
  warningDuration: number; // warn user this many ms before expiry
}

const DEFAULT_CONFIG: SessionConfig = {
  sessionKey: 'networking-bude-session',
  expiryKey: 'networking-bude-session-expiry',
  expiryDuration: 7 * 24 * 60 * 60 * 1000, // 7 days
  warningDuration: 5 * 60 * 1000 // 5 minutes
};

export const useAppSession = (config: Partial<SessionConfig> = {}) => {
  const sessionConfig = { ...DEFAULT_CONFIG, ...config };
  
  const [userData, setUserData] = useState<UserData | null>(null);
  const [isOnboarded, setIsOnboarded] = useState(false);
  const [sessionExpiry, setSessionExpiry] = useState<number | null>(null);
  const [isSessionValid, setIsSessionValid] = useState(false);

  // Session validation and cleanup
  const validateSession = useCallback((): boolean => {
    try {
      const storedSession = localStorage.getItem(sessionConfig.sessionKey);
      const expiry = localStorage.getItem(sessionConfig.expiryKey);
      
      if (!storedSession || !expiry) {
        setIsSessionValid(false);
        return false;
      }
      
      const expiryTime = parseInt(expiry, 10);
      if (Date.now() > expiryTime) {
        // Session expired, clean up
        clearSession();
        return false;
      }
      
      const sessionData = JSON.parse(storedSession);
      setUserData(sessionData);
      setIsOnboarded(true);
      setSessionExpiry(expiryTime);
      setIsSessionValid(true);
      return true;
    } catch (error) {
      console.error('Session validation error:', error);
      clearSession();
      return false;
    }
  }, [sessionConfig.sessionKey, sessionConfig.expiryKey]);
  
  const saveSession = useCallback((data: UserData) => {
    try {
      const expiryTime = Date.now() + sessionConfig.expiryDuration;
      
      // Update state synchronously
      setUserData(data);
      setIsOnboarded(true);
      setSessionExpiry(expiryTime);
      setIsSessionValid(true);
      
      // Save to localStorage
      localStorage.setItem(sessionConfig.sessionKey, JSON.stringify(data));
      localStorage.setItem(sessionConfig.expiryKey, expiryTime.toString());
      
      // Force a synchronous re-render by dispatching storage event
      window.dispatchEvent(new StorageEvent('storage', {
        key: sessionConfig.sessionKey,
        newValue: JSON.stringify(data),
        storageArea: localStorage
      }));
      
    } catch (error) {
      console.error('Session saving error:', error);
      throw error; // Re-throw to handle upstream
    }
  }, [sessionConfig.sessionKey, sessionConfig.expiryKey, sessionConfig.expiryDuration]);
  
  const clearSession = useCallback(() => {
    setIsOnboarded(false);
    setUserData(null);
    setSessionExpiry(null);
    setIsSessionValid(false);
    
    localStorage.removeItem(sessionConfig.sessionKey);
    localStorage.removeItem(sessionConfig.expiryKey);
    
    // Clear caches gracefully
    if ('caches' in window) {
      caches.keys().then(names => {
        names.forEach(name => {
          if (name.includes('networking-bude')) {
            caches.delete(name).catch(error => {
              console.warn('Failed to delete cache:', error.message);
            });
          }
        });
      }).catch(error => {
        console.warn('Failed to access caches:', error.message);
      });
    }
  }, [sessionConfig.sessionKey, sessionConfig.expiryKey]);
  
  const extendSession = useCallback(() => {
    if (userData) {
      saveSession(userData);
    }
  }, [userData, saveSession]);

  // Auto-logout and warning management
  useEffect(() => {
    if (!sessionExpiry) return;
    
    const timeUntilExpiry = sessionExpiry - Date.now();
    if (timeUntilExpiry <= 0) {
      clearSession();
      return;
    }
    
    // Warn user before expiry
    const warningTime = Math.max(0, timeUntilExpiry - sessionConfig.warningDuration);
    const warningTimer = setTimeout(() => {
      console.log('Session will expire in 5 minutes');
      // Could dispatch a custom event here for components to listen to
      window.dispatchEvent(new CustomEvent('sessionWarning', { 
        detail: { timeUntilExpiry: sessionConfig.warningDuration } 
      }));
    }, warningTime);
    
    // Auto-logout at expiry
    const logoutTimer = setTimeout(() => {
      clearSession();
      window.dispatchEvent(new CustomEvent('sessionExpired'));
    }, timeUntilExpiry);
    
    return () => {
      clearTimeout(warningTimer);
      clearTimeout(logoutTimer);
    };
  }, [sessionExpiry, clearSession, sessionConfig.warningDuration]);

  // Initialize session on mount
  useEffect(() => {
    validateSession();
  }, [validateSession]);
  
  return {
    userData,
    isOnboarded,
    sessionExpiry,
    isSessionValid,
    validateSession,
    saveSession,
    clearSession,
    extendSession
  };
};