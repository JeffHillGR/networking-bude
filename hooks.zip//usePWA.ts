// Progressive Web App Enhancement Hook
import { useState, useEffect, useCallback } from 'react';

interface PWAConfig {
  enableOfflineMode: boolean;
  enablePushNotifications: boolean;
  enableBackgroundSync: boolean;
  enableInstallPrompt: boolean;
  cacheStrategy: 'cache-first' | 'network-first' | 'stale-while-revalidate';
}

interface PWAState {
  isOnline: boolean;
  isInstallable: boolean;
  isInstalled: boolean;
  hasUpdate: boolean;
  notificationPermission: NotificationPermission;
  syncStatus: 'idle' | 'syncing' | 'synced' | 'failed';
  offlineActions: OfflineAction[];
}

interface OfflineAction {
  id: string;
  type: string;
  data: any;
  timestamp: number;
  retryCount: number;
}

interface BeforeInstallPromptEvent extends Event {
  prompt(): Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export function usePWA(config: PWAConfig = {
  enableOfflineMode: true,
  enablePushNotifications: true,
  enableBackgroundSync: true,
  enableInstallPrompt: true,
  cacheStrategy: 'stale-while-revalidate'
}) {
  const [state, setState] = useState<PWAState>({
    isOnline: navigator.onLine,
    isInstallable: false,
    isInstalled: false,
    hasUpdate: false,
    notificationPermission: 'default',
    syncStatus: 'idle',
    offlineActions: []
  });

  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [serviceWorker, setServiceWorker] = useState<ServiceWorkerRegistration | null>(null);

  // Service Worker registration and management
  const registerServiceWorker = useCallback(async () => {
    if (!('serviceWorker' in navigator)) {
      console.log('Service Worker not supported');
      return;
    }

    // Skip service worker registration in iframe environments (like Figma)
    if (window.location !== window.parent.location) {
      console.log('Skipping Service Worker registration in iframe environment');
      return;
    }

    try {
      const registration = await navigator.serviceWorker.register('/sw.js', {
        scope: '/'
      });
      
      setServiceWorker(registration);
      console.log('✅ Service Worker registered');

      // Check for updates
      registration.addEventListener('updatefound', () => {
        const newWorker = registration.installing;
        if (newWorker) {
          newWorker.addEventListener('statechange', () => {
            if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
              setState(prev => ({ ...prev, hasUpdate: true }));
            }
          });
        }
      });

      return registration;
    } catch (error) {
      console.warn('Service Worker registration failed (gracefully degrading):', error.message);
      // Gracefully degrade - app continues to work without service worker
      return null;
    }
  }, []);

  // Install app functionality
  const installApp = useCallback(async () => {
    if (!installPrompt) return false;

    try {
      await installPrompt.prompt();
      const { outcome } = await installPrompt.userChoice;
      
      if (outcome === 'accepted') {
        setState(prev => ({ ...prev, isInstalled: true, isInstallable: false }));
        setInstallPrompt(null);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('App installation failed:', error);
      return false;
    }
  }, [installPrompt]);

  // Update service worker
  const updateServiceWorker = useCallback(async () => {
    if (!serviceWorker) return;

    try {
      await serviceWorker.update();
      setState(prev => ({ ...prev, hasUpdate: false }));
      
      // Reload page to apply update
      window.location.reload();
    } catch (error) {
      console.error('Service Worker update failed:', error);
    }
  }, [serviceWorker]);

  // Push notification setup
  const enableNotifications = useCallback(async () => {
    if (!('Notification' in window)) return false;

    try {
      const permission = await Notification.requestPermission();
      setState(prev => ({ ...prev, notificationPermission: permission }));

      if (permission === 'granted' && serviceWorker) {
        try {
          // Get push subscription
          const subscription = await serviceWorker.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: process.env.REACT_APP_VAPID_PUBLIC_KEY || 'demo-key'
          });

          // Send subscription to server (mock in demo environment)
          if (window.location.hostname === 'localhost' || window.location.hostname.includes('figma')) {
            console.log('Mock: Notification subscription saved');
          } else {
            await fetch('/api/notifications/subscribe', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(subscription)
            });
          }

          return true;
        } catch (subscriptionError) {
          console.warn('Push subscription failed, falling back to basic notifications:', subscriptionError.message);
          // Still return true as basic notifications work
          return true;
        }
      }
      
      return permission === 'granted';
    } catch (error) {
      console.warn('Notification setup failed:', error.message);
      return false;
    }
  }, [serviceWorker]);

  // Show notification
  const showNotification = useCallback(async (title: string, options?: NotificationOptions) => {
    if (state.notificationPermission !== 'granted') return;

    try {
      if (serviceWorker) {
        // Use service worker notification if available
        await serviceWorker.showNotification(title, {
          icon: '/icon-192x192.png',
          badge: '/badge-72x72.png',
          vibrate: [200, 100, 200],
          actions: [
            { action: 'open', title: 'Open App', icon: '/icon-open.png' },
            { action: 'dismiss', title: 'Dismiss', icon: '/icon-close.png' }
          ],
          ...options
        });
      } else if ('Notification' in window) {
        // Fallback to browser notification API
        new Notification(title, {
          icon: '/icon-192x192.png',
          ...options
        });
      }
    } catch (error) {
      console.warn('Notification failed, using fallback:', error.message);
      // Fallback to browser notification
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(title, {
          icon: '/icon-192x192.png',
          ...options
        });
      }
    }
  }, [state.notificationPermission, serviceWorker]);

  // Offline action queue
  const queueOfflineAction = useCallback((type: string, data: any) => {
    const action: OfflineAction = {
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      type,
      data,
      timestamp: Date.now(),
      retryCount: 0
    };

    setState(prev => ({
      ...prev,
      offlineActions: [...prev.offlineActions, action]
    }));

    // Store in IndexedDB for persistence (if available)
    if ('indexedDB' in window) {
      storeOfflineAction(action).catch(error => {
        console.warn('Failed to store offline action (gracefully degrading):', error.message);
      });
    } else {
      // Fallback to localStorage for simple environments
      try {
        const existing = JSON.parse(localStorage.getItem('offline-actions') || '[]');
        existing.push(action);
        localStorage.setItem('offline-actions', JSON.stringify(existing));
      } catch (error) {
        console.warn('Failed to store offline action in localStorage:', error.message);
      }
    }
  }, []);

  // Background sync
  const syncOfflineActions = useCallback(async () => {
    if (!state.isOnline || !serviceWorker || state.offlineActions.length === 0) return;

    setState(prev => ({ ...prev, syncStatus: 'syncing' }));

    try {
      for (const action of state.offlineActions) {
        try {
          // Attempt to sync action
          await syncAction(action);
          
          // Remove successful action
          setState(prev => ({
            ...prev,
            offlineActions: prev.offlineActions.filter(a => a.id !== action.id)
          }));
          
          // Remove from IndexedDB
          removeOfflineAction(action.id);
        } catch (error) {
          console.error(`Failed to sync action ${action.id}:`, error);
          
          // Increment retry count
          action.retryCount++;
          
          // Remove if exceeded max retries
          if (action.retryCount >= 3) {
            setState(prev => ({
              ...prev,
              offlineActions: prev.offlineActions.filter(a => a.id !== action.id)
            }));
            removeOfflineAction(action.id);
          }
        }
      }
      
      setState(prev => ({ ...prev, syncStatus: 'synced' }));
      
      // Reset status after 2 seconds
      setTimeout(() => {
        setState(prev => ({ ...prev, syncStatus: 'idle' }));
      }, 2000);
      
    } catch (error) {
      console.error('Background sync failed:', error);
      setState(prev => ({ ...prev, syncStatus: 'failed' }));
    }
  }, [state.isOnline, state.offlineActions, serviceWorker]);

  // Helper function to sync individual actions
  const syncAction = async (action: OfflineAction) => {
    const endpoints: Record<string, string> = {
      'send_message': '/api/messages',
      'update_profile': '/api/profile',
      'create_connection': '/api/connections',
      'rsvp_event': '/api/events/rsvp'
    };

    const endpoint = endpoints[action.type];
    if (!endpoint) throw new Error(`Unknown action type: ${action.type}`);

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(action.data)
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    return response.json();
  };

  // IndexedDB operations for offline actions
  const storeOfflineAction = async (action: OfflineAction) => {
    try {
      const db = await openOfflineDB();
      const transaction = db.transaction(['actions'], 'readwrite');
      const store = transaction.objectStore('actions');
      await store.add(action);
    } catch (error) {
      console.error('Failed to store offline action:', error);
    }
  };

  const removeOfflineAction = async (id: string) => {
    try {
      const db = await openOfflineDB();
      const transaction = db.transaction(['actions'], 'readwrite');
      const store = transaction.objectStore('actions');
      await store.delete(id);
    } catch (error) {
      console.error('Failed to remove offline action:', error);
    }
  };

  const loadOfflineActions = async () => {
    try {
      const db = await openOfflineDB();
      const transaction = db.transaction(['actions'], 'readonly');
      const store = transaction.objectStore('actions');
      const actions = await store.getAll();
      
      setState(prev => ({ ...prev, offlineActions: actions }));
    } catch (error) {
      console.warn('Failed to load offline actions from IndexedDB, trying localStorage:', error.message);
      // Fallback to localStorage
      try {
        const stored = localStorage.getItem('offline-actions');
        if (stored) {
          const actions = JSON.parse(stored);
          setState(prev => ({ ...prev, offlineActions: actions }));
        }
      } catch (fallbackError) {
        console.warn('Failed to load offline actions from localStorage:', fallbackError.message);
      }
    }
  };

  const openOfflineDB = (): Promise<IDBDatabase> => {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('NetworkingBudeOffline', 1);
      
      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result);
      
      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains('actions')) {
          const store = db.createObjectStore('actions', { keyPath: 'id' });
          store.createIndex('timestamp', 'timestamp');
        }
      };
    });
  };

  // Network status monitoring
  useEffect(() => {
    const handleOnline = () => {
      setState(prev => ({ ...prev, isOnline: true }));
      
      // Trigger background sync when coming back online
      if (config.enableBackgroundSync) {
        setTimeout(syncOfflineActions, 1000);
      }
    };

    const handleOffline = () => {
      setState(prev => ({ ...prev, isOnline: false }));
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [syncOfflineActions, config.enableBackgroundSync]);

  // Install prompt handling
  useEffect(() => {
    if (!config.enableInstallPrompt) return;

    // Skip install prompts in iframe environments
    if (window.location !== window.parent.location) {
      console.log('Skipping install prompt setup in iframe environment');
      return;
    }

    const handleBeforeInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as BeforeInstallPromptEvent);
      setState(prev => ({ ...prev, isInstallable: true }));
    };

    const handleAppInstalled = () => {
      setState(prev => ({ ...prev, isInstalled: true, isInstallable: false }));
      setInstallPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, [config.enableInstallPrompt]);

  // Initialize PWA features
  useEffect(() => {
    // Initialize with graceful degradation
    const initializePWA = async () => {
      try {
        await registerServiceWorker();
        await loadOfflineActions();

        // Check if already installed
        if (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) {
          setState(prev => ({ ...prev, isInstalled: true }));
        }

        // Get current notification permission
        if ('Notification' in window) {
          setState(prev => ({ ...prev, notificationPermission: Notification.permission }));
        }
      } catch (error) {
        console.warn('PWA initialization failed, continuing with basic functionality:', error.message);
      }
    };

    initializePWA();
  }, [registerServiceWorker]);

  return {
    ...state,
    installApp,
    updateServiceWorker,
    enableNotifications,
    showNotification,
    queueOfflineAction,
    syncOfflineActions
  };
}