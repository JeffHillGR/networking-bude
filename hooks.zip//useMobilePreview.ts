// Mobile preview hook - Extracted from App.tsx for better organization
import { useState, useEffect, useCallback } from 'react';

interface MobilePreviewConfig {
  enableUrlParams: boolean;
  defaultBreakpoint: 'mobile' | 'tablet' | 'desktop';
  enableCustomEvents: boolean;
}

const DEFAULT_CONFIG: MobilePreviewConfig = {
  enableUrlParams: true,
  defaultBreakpoint: 'mobile',
  enableCustomEvents: true
};

export const useMobilePreview = (config: Partial<MobilePreviewConfig> = {}) => {
  const previewConfig = { ...DEFAULT_CONFIG, ...config };
  
  const [forceMobileView, setForceMobileView] = useState(false);
  const [previewBreakpoint, setPreviewBreakpoint] = useState<'mobile' | 'tablet' | 'desktop'>('mobile');

  // Initialize mobile preview from URL params
  useEffect(() => {
    if (!previewConfig.enableUrlParams) return;
    
    const urlParams = new URLSearchParams(window.location.search);
    const isMobilePreview = urlParams.get('mobile') === 'true' || urlParams.get('preview') === 'mobile';
    const isTabletPreview = urlParams.get('preview') === 'tablet';
    
    setForceMobileView(isMobilePreview);
    
    if (isMobilePreview) {
      setPreviewBreakpoint('mobile');
    } else if (isTabletPreview) {
      setPreviewBreakpoint('tablet');
    } else {
      setPreviewBreakpoint('desktop');
    }
  }, [previewConfig.enableUrlParams]);
  
  const toggleMobilePreview = useCallback(() => {
    setForceMobileView(prev => {
      const newState = !prev;
      
      if (previewConfig.enableUrlParams) {
        const url = new URL(window.location.href);
        
        if (newState) {
          url.searchParams.set('mobile', 'true');
          url.searchParams.set('preview', 'mobile');
        } else {
          url.searchParams.delete('mobile');
          url.searchParams.delete('preview');
        }
        
        window.history.replaceState({}, '', url.toString());
      }
      
      setPreviewBreakpoint(newState ? 'mobile' : 'desktop');
      
      // Trigger custom event for other components to respond
      if (previewConfig.enableCustomEvents) {
        window.dispatchEvent(new CustomEvent('mobilePreviewToggle', { 
          detail: { enabled: newState, breakpoint: newState ? 'mobile' : 'desktop' } 
        }));
      }
      
      return newState;
    });
  }, [previewConfig.enableUrlParams, previewConfig.enableCustomEvents]);

  const setPreviewMode = useCallback((mode: 'mobile' | 'tablet' | 'desktop') => {
    const isMobile = mode === 'mobile';
    setForceMobileView(isMobile);
    setPreviewBreakpoint(mode);
    
    if (previewConfig.enableUrlParams) {
      const url = new URL(window.location.href);
      
      if (mode === 'mobile') {
        url.searchParams.set('mobile', 'true');
        url.searchParams.set('preview', 'mobile');
      } else if (mode === 'tablet') {
        url.searchParams.delete('mobile');
        url.searchParams.set('preview', 'tablet');
      } else {
        url.searchParams.delete('mobile');
        url.searchParams.delete('preview');
      }
      
      window.history.replaceState({}, '', url.toString());
    }
    
    if (previewConfig.enableCustomEvents) {
      window.dispatchEvent(new CustomEvent('previewModeChanged', { 
        detail: { mode, enabled: isMobile } 
      }));
    }
  }, [previewConfig.enableUrlParams, previewConfig.enableCustomEvents]);

  const exitPreviewMode = useCallback(() => {
    setForceMobileView(false);
    setPreviewBreakpoint('desktop');
    
    if (previewConfig.enableUrlParams) {
      const url = new URL(window.location.href);
      url.searchParams.delete('mobile');
      url.searchParams.delete('preview');
      window.history.replaceState({}, '', url.toString());
    }
    
    if (previewConfig.enableCustomEvents) {
      window.dispatchEvent(new CustomEvent('previewModeExited'));
    }
  }, [previewConfig.enableUrlParams, previewConfig.enableCustomEvents]);

  const getPreviewContainerClass = useCallback(() => {
    switch (previewBreakpoint) {
      case 'mobile':
        return 'mobile-preview-container max-w-sm';
      case 'tablet':
        return 'tablet-preview-container max-w-md';
      default:
        return '';
    }
  }, [previewBreakpoint]);
  
  return {
    forceMobileView,
    previewBreakpoint,
    toggleMobilePreview,
    setPreviewMode,
    exitPreviewMode,
    getPreviewContainerClass,
    setForceMobileView // Keep for backwards compatibility
  };
};