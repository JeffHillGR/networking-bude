import { useState, useEffect, useCallback } from 'react';
import { ApiResponse, LoadingState } from '../types';

// Generic API hook for handling loading states and errors
export function useApi<T>(
  apiFunction: () => Promise<ApiResponse<T>>,
  dependencies: any[] = []
) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await apiFunction();
      
      if (response.success && response.data) {
        setData(response.data);
      } else {
        setError(response.error || 'Unknown error occurred');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Network error');
    } finally {
      setLoading(false);
    }
  }, dependencies);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const refetch = useCallback(() => {
    fetchData();
  }, [fetchData]);

  return {
    data,
    loading,
    error,
    refetch,
  };
}

// Hook for mutations (POST, PUT, DELETE)
export function useMutation<T, P = any>(
  mutationFunction: (params: P) => Promise<ApiResponse<T>>
) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<T | null>(null);

  const mutate = useCallback(async (params: P) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await mutationFunction(params);
      
      if (response.success && response.data) {
        setData(response.data);
        return { success: true, data: response.data };
      } else {
        setError(response.error || 'Mutation failed');
        return { success: false, error: response.error };
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Network error';
      setError(errorMessage);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, [mutationFunction]);

  const reset = useCallback(() => {
    setLoading(false);
    setError(null);
    setData(null);
  }, []);

  return {
    mutate,
    loading,
    error,
    data,
    reset,
  };
}

// Optimistic updates hook
export function useOptimisticUpdate<T>(
  initialData: T,
  updateFunction: (data: T) => Promise<ApiResponse<T>>
) {
  const [data, setData] = useState<T>(initialData);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const updateOptimistically = useCallback(async (optimisticUpdate: Partial<T>) => {
    // Apply optimistic update immediately
    const previousData = data;
    const optimisticData = { ...data, ...optimisticUpdate };
    setData(optimisticData);
    setLoading(true);
    setError(null);

    try {
      const response = await updateFunction(optimisticData);
      
      if (response.success && response.data) {
        setData(response.data);
      } else {
        // Revert optimistic update on failure
        setData(previousData);
        setError(response.error || 'Update failed');
      }
    } catch (err) {
      // Revert optimistic update on error
      setData(previousData);
      setError(err instanceof Error ? err.message : 'Network error');
    } finally {
      setLoading(false);
    }
  }, [data, updateFunction]);

  return {
    data,
    loading,
    error,
    updateOptimistically,
  };
}

// Debounced API calls hook
export function useDebouncedApi<T>(
  apiFunction: (query: string) => Promise<ApiResponse<T>>,
  delay: number = 300
) {
  const [query, setQuery] = useState('');
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!query.trim()) {
      setData(null);
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    const timeoutId = setTimeout(async () => {
      try {
        const response = await apiFunction(query);
        
        if (response.success && response.data) {
          setData(response.data);
        } else {
          setError(response.error || 'Search failed');
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Network error');
      } finally {
        setLoading(false);
      }
    }, delay);

    return () => clearTimeout(timeoutId);
  }, [query, apiFunction, delay]);

  return {
    query,
    setQuery,
    data,
    loading,
    error,
  };
}

// Infinite scroll hook
export function useInfiniteScroll<T>(
  fetchFunction: (page: number) => Promise<ApiResponse<T[]>>,
  pageSize: number = 20
) {
  const [data, setData] = useState<T[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(true);
  const [page, setPage] = useState(1);

  const fetchMore = useCallback(async () => {
    if (loading || !hasMore) return;

    setLoading(true);
    setError(null);

    try {
      const response = await fetchFunction(page);
      
      if (response.success && response.data) {
        const newData = response.data;
        
        if (newData.length < pageSize) {
          setHasMore(false);
        }
        
        setData(prevData => [...prevData, ...newData]);
        setPage(prevPage => prevPage + 1);
      } else {
        setError(response.error || 'Failed to fetch more data');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Network error');
    } finally {
      setLoading(false);
    }
  }, [fetchFunction, page, pageSize, loading, hasMore]);

  const reset = useCallback(() => {
    setData([]);
    setPage(1);
    setHasMore(true);
    setError(null);
  }, []);

  return {
    data,
    loading,
    error,
    hasMore,
    fetchMore,
    reset,
  };
}