import { useState, useCallback } from 'react';

export function useAppCore() {
  const [isLoading, setIsLoading] = useState(true);
  const [showWidget, setShowWidget] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const initializeWidget = useCallback(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('widget') === 'true') {
      setShowWidget(true);
      setIsLoading(false);
      return true;
    }
    return false;
  }, []);

  const startTransition = useCallback(() => {
    setIsTransitioning(true);
  }, []);

  const completeTransition = useCallback(() => {
    setIsTransitioning(false);
  }, []);

  return {
    isLoading,
    setIsLoading,
    showWidget,
    setShowWidget,
    isTransitioning,
    setIsTransitioning,
    initializeWidget,
    startTransition,
    completeTransition
  };
}