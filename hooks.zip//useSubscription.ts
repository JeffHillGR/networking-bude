import { useState, useCallback, useMemo, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useGlobalState } from './useGlobalState';
import { toast } from 'sonner@2.0.3';

export type SubscriptionStatus = 'preview' | 'active' | 'cancelled' | 'expired';

export interface SubscriptionState {
  status: SubscriptionStatus;
  plan: string | null;
  price: number | null;
  billingCycle: 'monthly' | 'annual' | null;
  nextBillingDate: string | null;
  termsAccepted: boolean;
  termsAcceptedAt: string | null;
}

export function useSubscription() {
  const navigate = useNavigate();
  const { state: globalState, setState: setGlobalState } = useGlobalState();
  
  // Reactive state for developer mode checking
  const [isAdminBypass, setIsAdminBypass] = useState(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const devParam = urlParams.get('dev');
    const adminParam = urlParams.get('admin');
    const demoParam = urlParams.get('demo');
    
    // Check localStorage for persistent developer mode
    const developerMode = localStorage.getItem('networkingbude_developer_mode');
    const permanentDev = localStorage.getItem('networking_bude_permanent_dev');
    
    // Check sessionStorage for active developer editing
    const developerEditing = sessionStorage.getItem('networking-bude-editing');
    
    // Full access granted if:
    // 1. URL has ?dev=true (primary developer mode)
    // 2. localStorage has developer mode enabled
    // 3. localStorage has permanent dev access
    // 4. sessionStorage has active editing session
    // 5. Legacy admin/demo modes for backwards compatibility
    return (
      devParam === 'true' || 
      developerMode === 'enabled' ||
      permanentDev === 'true' ||
      developerEditing !== null ||
      adminParam === 'true' || 
      adminParam === 'bypass' || 
      demoParam === 'true'
    );
  });

  // Expose emergency developer access to console for permanent fix
  useEffect(() => {
    if (typeof window !== 'undefined') {
      (window as any).NetworkingBudE = {
        enableDeveloperMode: () => {
          localStorage.setItem('networkingbude_developer_mode', 'enabled');
          localStorage.setItem('networking_bude_permanent_dev', 'true');
          sessionStorage.setItem('networking-bude-editing', 'true');
          const url = new URL(window.location.href);
          url.searchParams.set('dev', 'true');
          window.history.replaceState({}, '', url.toString());
          window.location.reload();
          return 'Developer mode enabled permanently!';
        },
        disableDeveloperMode: () => {
          localStorage.removeItem('networkingbude_developer_mode');
          localStorage.removeItem('networking_bude_permanent_dev');
          sessionStorage.removeItem('networking-bude-editing');
          const url = new URL(window.location.href);
          url.searchParams.delete('dev');
          window.history.replaceState({}, '', url.toString());
          window.location.reload();
          return 'Developer mode disabled!';
        },
        status: () => {
          return {
            isAdminBypass,
            developerMode: localStorage.getItem('networkingbude_developer_mode'),
            permanentDev: localStorage.getItem('networking_bude_permanent_dev'),
            sessionEditing: sessionStorage.getItem('networking-bude-editing'),
            urlParams: window.location.search
          };
        }
      };
      
      console.log('🔧 Networking BudE Developer Console Commands:');
      console.log('• NetworkingBudE.enableDeveloperMode() - Enable permanent developer access');
      console.log('• NetworkingBudE.disableDeveloperMode() - Disable developer access');
      console.log('• NetworkingBudE.status() - Check current developer mode status');
    }
  }, [isAdminBypass]);

  // Update isAdminBypass when storage changes
  useEffect(() => {
    const checkAdminBypass = () => {
      const urlParams = new URLSearchParams(window.location.search);
      const devParam = urlParams.get('dev');
      const adminParam = urlParams.get('admin');
      const demoParam = urlParams.get('demo');
      
      const developerMode = localStorage.getItem('networkingbude_developer_mode');
      const permanentDev = localStorage.getItem('networking_bude_permanent_dev');
      const developerEditing = sessionStorage.getItem('networking-bude-editing');
      
      const newIsAdminBypass = (
        devParam === 'true' || 
        developerMode === 'enabled' ||
        permanentDev === 'true' ||
        developerEditing !== null ||
        adminParam === 'true' || 
        adminParam === 'bypass' || 
        demoParam === 'true'
      );
      
      setIsAdminBypass(newIsAdminBypass);
    };

    // Listen for storage events
    window.addEventListener('storage', checkAdminBypass);
    
    // Also check periodically in case of programmatic changes
    const interval = setInterval(checkAdminBypass, 500);
    
    return () => {
      window.removeEventListener('storage', checkAdminBypass);
      clearInterval(interval);
    };
  }, []);
  
  const subscriptionState = globalState.subscription || {
    status: 'preview' as SubscriptionStatus,
    plan: null,
    price: null,
    billingCycle: null,
    nextBillingDate: null,
    termsAccepted: false,
    termsAcceptedAt: null
  };

  const isPreviewMode = subscriptionState.status === 'preview' && !isAdminBypass;
  const isPaidSubscriber = subscriptionState.status === 'active' || isAdminBypass;
  const hasActiveSubscription = isPaidSubscriber;

  const checkFeatureAccess = useCallback((feature: string): boolean => {
    // Debug logging for development
    if (process.env.NODE_ENV === 'development') {
      console.log('🔐 Subscription Check:', {
        feature,
        isAdminBypass,
        isPreviewMode,
        isPaidSubscriber,
        urlParams: window.location.search,
        developerMode: localStorage.getItem('networkingbude_developer_mode'),
        permanentDev: localStorage.getItem('networking_bude_permanent_dev'),
        developerEditing: sessionStorage.getItem('networking-bude-editing')
      });
    }
    
    // Admin bypass always grants access for demo purposes
    if (isAdminBypass) {
      if (process.env.NODE_ENV === 'development') {
        console.log('✅ Access granted via developer mode');
      }
      return true;
    }
    
    // In preview mode, users can't access premium features
    if (isPreviewMode) {
      if (process.env.NODE_ENV === 'development') {
        console.log('❌ Access denied - preview mode');
      }
      return false;
    }
    
    // Paid subscribers get access to all features
    if (isPaidSubscriber) {
      if (process.env.NODE_ENV === 'development') {
        console.log('✅ Access granted - paid subscriber');
      }
      return true;
    }
    
    if (process.env.NODE_ENV === 'development') {
      console.log('❌ Access denied - no valid subscription');
    }
    return false;
  }, [isAdminBypass, isPreviewMode, isPaidSubscriber]);

  const requiresUpgrade = useCallback((feature: string): boolean => {
    return !checkFeatureAccess(feature);
  }, [checkFeatureAccess]);

  const showUpgradePrompt = useCallback((feature: string, context?: string) => {
    // Don't show upgrade prompt for developer mode users
    if (isAdminBypass) {
      return;
    }
    
    const contextMessage = context ? ` ${context}` : '';
    
    toast.error(`Premium Feature Required${contextMessage}`, {
      description: `This feature is only available to paid subscribers. Upgrade now starting at $9.99/month to access all features.`,
      duration: 4000,
      action: {
        label: 'Upgrade Now',
        onClick: () => {
          navigate('/payment-portal');
        }
      }
    });
  }, [isAdminBypass, navigate]);

  const acceptTerms = useCallback(() => {
    const now = new Date().toISOString();
    const newSubscriptionState = {
      ...subscriptionState,
      termsAccepted: true,
      termsAcceptedAt: now
    };
    
    setGlobalState({
      ...globalState,
      subscription: newSubscriptionState
    });
    
    // Also update user data if available
    if (globalState.user) {
      setGlobalState({
        ...globalState,
        user: {
          ...globalState.user,
          termsAccepted: true,
          _onboardingData: {
            ...globalState.user._onboardingData,
            termsAcceptedAt: now
          }
        },
        subscription: newSubscriptionState
      });
    }
    
    return true;
  }, [subscriptionState, globalState, setGlobalState]);

  const activateSubscription = useCallback((plan: string, price: number, billingCycle: 'monthly' | 'annual') => {
    const nextBillingDate = new Date();
    if (billingCycle === 'monthly') {
      nextBillingDate.setMonth(nextBillingDate.getMonth() + 1);
    } else {
      nextBillingDate.setFullYear(nextBillingDate.getFullYear() + 1);
    }

    const newSubscriptionState: SubscriptionState = {
      status: 'active',
      plan,
      price,
      billingCycle,
      nextBillingDate: nextBillingDate.toISOString(),
      termsAccepted: subscriptionState.termsAccepted,
      termsAcceptedAt: subscriptionState.termsAcceptedAt
    };
    
    setGlobalState({
      ...globalState,
      subscription: newSubscriptionState
    });
    
    // Also update user subscription status
    if (globalState.user) {
      setGlobalState({
        ...globalState,
        user: {
          ...globalState.user,
          subscriptionStatus: 'active'
        },
        subscription: newSubscriptionState
      });
    }
    
    toast.success('Subscription activated! Welcome to Networking BudE Premium!');
    return true;
  }, [subscriptionState, globalState, setGlobalState]);

  const cancelSubscription = useCallback(() => {
    const newSubscriptionState = {
      ...subscriptionState,
      status: 'cancelled' as SubscriptionStatus
    };
    
    setGlobalState({
      ...globalState,
      subscription: newSubscriptionState
    });
    
    toast.info('Subscription cancelled. Access will continue until your next billing date.');
    return true;
  }, [subscriptionState, globalState, setGlobalState]);

  // Developer mode controls (grants full access for development)
  const enableDeveloperMode = useCallback(() => {
    localStorage.setItem('networkingbude_developer_mode', 'enabled');
    sessionStorage.setItem('networking-bude-editing', 'true');
    const url = new URL(window.location.href);
    url.searchParams.set('dev', 'true');
    window.history.replaceState({}, '', url.toString());
    
    // Force immediate state update
    setIsAdminBypass(true);
    
    toast.success('Developer mode enabled', {
      description: 'Full access to all features for development and testing.'
    });
    
    // Trigger storage event to ensure all components update
    window.dispatchEvent(new StorageEvent('storage', {
      key: 'networkingbude_developer_mode',
      newValue: 'enabled',
      storageArea: localStorage
    }));
  }, []);

  const disableDeveloperMode = useCallback(() => {
    localStorage.removeItem('networkingbude_developer_mode');
    sessionStorage.removeItem('networking-bude-editing');
    const url = new URL(window.location.href);
    url.searchParams.delete('dev');
    window.history.replaceState({}, '', url.toString());
    
    // Force immediate state update
    setIsAdminBypass(false);
    
    toast.info('Developer mode disabled. Premium features require subscription.');
    
    // Trigger storage event to ensure all components update
    window.dispatchEvent(new StorageEvent('storage', {
      key: 'networkingbude_developer_mode',
      newValue: null,
      storageArea: localStorage
    }));
  }, []);

  // Emergency developer mode activation (for permanent access)
  const emergencyDeveloperAccess = useCallback(() => {
    localStorage.setItem('networkingbude_developer_mode', 'enabled');
    localStorage.setItem('networking_bude_permanent_dev', 'true');
    sessionStorage.setItem('networking-bude-editing', 'true');
    const url = new URL(window.location.href);
    url.searchParams.set('dev', 'true');
    window.history.replaceState({}, '', url.toString());
    
    // Force immediate state update
    setIsAdminBypass(true);
    
    // Trigger storage event
    window.dispatchEvent(new StorageEvent('storage', {
      key: 'networkingbude_developer_mode',
      newValue: 'enabled',
      storageArea: localStorage
    }));
    
    console.log('🔓 Emergency developer access activated');
    
    return true;
  }, []);

  return {
    // State
    subscription: subscriptionState,
    isPreviewMode,
    isPaidSubscriber,
    hasActiveSubscription,
    isAdminBypass,
    
    // Feature access
    checkFeatureAccess,
    requiresUpgrade,
    showUpgradePrompt,
    
    // Actions
    acceptTerms,
    activateSubscription,
    cancelSubscription,
    
    // Developer controls
    enableDeveloperMode,
    disableDeveloperMode,
    emergencyDeveloperAccess
  };
}

// Specific feature access hooks for common use cases
export function useEventAccess() {
  const { checkFeatureAccess, showUpgradePrompt } = useSubscription();
  
  const canAccessEvent = (eventId: string) => checkFeatureAccess('events');
  const requireEventUpgrade = () => showUpgradePrompt('events', 'to access event details and RSVP');
  
  return { canAccessEvent, requireEventUpgrade };
}

export function useConnectionAccess() {
  const { checkFeatureAccess, showUpgradePrompt } = useSubscription();
  
  const canConnect = () => checkFeatureAccess('connections');
  const requireConnectionUpgrade = () => showUpgradePrompt('connections', 'to connect with other professionals');
  
  return { canConnect, requireConnectionUpgrade };
}

export function useMessagingAccess() {
  const { checkFeatureAccess, showUpgradePrompt } = useSubscription();
  
  const canMessage = () => checkFeatureAccess('messaging');
  const requireMessagingUpgrade = () => showUpgradePrompt('messaging', 'to send and receive messages');
  
  return { canMessage, requireMessagingUpgrade };
}