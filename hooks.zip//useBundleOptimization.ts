// Bundle Size & Loading Performance Optimization Hook
import { useEffect, useCallback, useState } from 'react';

interface BundleOptimizationConfig {
  enablePreloading?: boolean;
  enableResourceHints?: boolean;
  enableComponentCaching?: boolean;
  criticalComponents?: string[];
}

interface PerformanceMetrics {
  bundleSize: number;
  loadTime: number;
  firstContentfulPaint: number;
  largestContentfulPaint: number;
  cumulativeLayoutShift: number;
  firstInputDelay: number;
}

export function useBundleOptimization(config: BundleOptimizationConfig = {}) {
  const finalConfig = {
    enablePreloading: true,
    enableResourceHints: true,
    enableComponentCaching: true,
    criticalComponents: [],
    ...config
  };
  const [metrics, setMetrics] = useState<PerformanceMetrics | null>(null);
  const [isOptimizing, setIsOptimizing] = useState(false);

  // Aggressive component preloading based on user behavior
  const preloadComponent = useCallback(async (componentName: string) => {
    if (!finalConfig.enablePreloading) return;

    try {
      const componentMap: Record<string, () => Promise<any>> = {
        'Events': () => import('../components/Events'),
        'Matches': () => import('../components/Matches'),
        'UserProfile': () => import('../components/UserProfile'),
        'Messenger': () => import('../components/Messenger'),
        'EventDetail': () => import('../components/EventDetail'),
        'Conversation': () => import('../components/Conversation'),
        'AccountSettings': () => import('../components/AccountSettings'),
        'PaymentPortal': () => import('../components/PaymentPortal'),
        'ContentArchive': () => import('../components/ContentArchive')
      };

      const componentLoader = componentMap[componentName];
      if (componentLoader) {
        await componentLoader();
        console.log(`✅ Preloaded ${componentName} component`);
      }
    } catch (error) {
      console.warn(`Failed to preload ${componentName}:`, error);
    }
  }, [finalConfig.enablePreloading]);

  // Intelligent resource hints based on user navigation patterns
  const addResourceHints = useCallback(() => {
    if (!finalConfig.enableResourceHints) return;

    const hints = [
      // Only add resource hints for external services that are commonly available
      { rel: 'dns-prefetch', href: 'https://fonts.googleapis.com' },
      { rel: 'dns-prefetch', href: 'https://images.unsplash.com' }
      // Skip internal API hints in iframe environments
    ];

    // Add internal hints only if not in iframe
    if (window.location === window.parent.location) {
      hints.push(
        { rel: 'preconnect', href: 'https://api.networking-bude.com' },
        { rel: 'prefetch', href: '/api/events' },
        { rel: 'prefetch', href: '/api/connections' }
      );
    }

    hints.forEach(({ rel, href }) => {
      try {
        if (!document.querySelector(`link[href="${href}"]`)) {
          const link = document.createElement('link');
          link.rel = rel;
          link.href = href;
          document.head.appendChild(link);
        }
      } catch (error) {
        console.warn(`Failed to add resource hint for ${href}:`, error.message);
      }
    });
  }, [finalConfig.enableResourceHints]);

  // Component caching with intelligent invalidation
  const setupComponentCache = useCallback(() => {
    if (!finalConfig.enableComponentCaching || !('caches' in window)) return;

    // Skip cache setup in iframe environments or when resources aren't available
    if (window.location !== window.parent.location) {
      console.log('Skipping component cache setup in iframe environment');
      return;
    }

    const cacheComponents = async () => {
      try {
        const cache = await caches.open('networking-bude-components-v2');
        
        // Only cache resources that actually exist and are accessible
        const availableResources = [
          // Start with just the current page to avoid 404s
          window.location.href
        ];

        // Test each resource before trying to cache it
        const criticalResources = [
          '/components/Dashboard.js',
          '/components/Events.js', 
          '/components/Matches.js',
          '/styles/globals.css'
        ];

        for (const resource of criticalResources) {
          try {
            const response = await fetch(resource, { method: 'HEAD' });
            if (response.ok) {
              availableResources.push(resource);
            }
          } catch (error) {
            console.log(`Skipping unavailable resource: ${resource}`);
          }
        }

        if (availableResources.length > 1) {
          await cache.addAll(availableResources);
          console.log(`✅ Component cache initialized with ${availableResources.length} resources`);
        } else {
          console.log('ℹ️ Component cache skipped - no cacheable resources found');
        }
      } catch (error) {
        console.warn('Component caching failed (gracefully degrading):', error.message);
      }
    };

    cacheComponents();
  }, [finalConfig.enableComponentCaching]);

  // Performance metrics collection
  const collectMetrics = useCallback(() => {
    if (typeof window.performance !== 'object') return;

    const observer = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      
      entries.forEach((entry) => {
        setMetrics(prev => ({
          bundleSize: prev?.bundleSize || 0,
          loadTime: entry.duration,
          firstContentfulPaint: prev?.firstContentfulPaint || 0,
          largestContentfulPaint: entry.startTime,
          cumulativeLayoutShift: prev?.cumulativeLayoutShift || 0,
          firstInputDelay: prev?.firstInputDelay || 0
        }));
      });
    });

    observer.observe({ entryTypes: ['navigation', 'largest-contentful-paint'] });

    return () => observer.disconnect();
  }, []);

  // Bundle size analysis
  const analyzeBundleSize = useCallback(async () => {
    setIsOptimizing(true);
    
    try {
      // Estimate bundle size from loaded resources
      const resources = performance.getEntriesByType('resource') as PerformanceResourceTiming[];
      const totalSize = resources.reduce((total, resource) => {
        return total + (resource.transferSize || 0);
      }, 0);

      setMetrics(prev => ({
        ...prev!,
        bundleSize: totalSize
      }));

      console.log(`📊 Estimated bundle size: ${(totalSize / 1024).toFixed(2)}KB`);
    } catch (error) {
      console.warn('Bundle analysis failed:', error);
    } finally {
      setIsOptimizing(false);
    }
  }, []);

  // Optimize critical rendering path
  const optimizeCriticalPath = useCallback(() => {
    // Defer non-critical CSS
    const stylesheets = document.querySelectorAll('link[rel="stylesheet"]');
    stylesheets.forEach((sheet) => {
      const link = sheet as HTMLLinkElement;
      if (!config.criticalComponents.some(comp => link.href.includes(comp))) {
        link.media = 'print';
        link.addEventListener('load', () => {
          link.media = 'all';
        });
      }
    });

    // Optimize font loading
    if (document.fonts) {
      document.fonts.ready.then(() => {
        console.log('✅ Fonts loaded');
      });
    }
  }, [config.criticalComponents]);

  // User behavior-based preloading
  const setupBehaviorBasedPreloading = useCallback(() => {
    let mouseTimer: NodeJS.Timeout;
    let touchTimer: NodeJS.Timeout;

    const handleMouseOver = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      const link = target.closest('a[href]') as HTMLAnchorElement;
      
      if (link) {
        clearTimeout(mouseTimer);
        mouseTimer = setTimeout(() => {
          const path = new URL(link.href, window.location.origin).pathname;
          const componentName = getComponentFromPath(path);
          if (componentName) {
            preloadComponent(componentName);
          }
        }, 150); // Preload after 150ms hover
      }
    };

    const handleTouchStart = (event: TouchEvent) => {
      const target = event.target as HTMLElement;
      const link = target.closest('a[href]') as HTMLAnchorElement;
      
      if (link) {
        clearTimeout(touchTimer);
        touchTimer = setTimeout(() => {
          const path = new URL(link.href, window.location.origin).pathname;
          const componentName = getComponentFromPath(path);
          if (componentName) {
            preloadComponent(componentName);
          }
        }, 100); // Faster preload on touch
      }
    };

    document.addEventListener('mouseover', handleMouseOver, { passive: true });
    document.addEventListener('touchstart', handleTouchStart, { passive: true });

    return () => {
      document.removeEventListener('mouseover', handleMouseOver);
      document.removeEventListener('touchstart', handleTouchStart);
      clearTimeout(mouseTimer);
      clearTimeout(touchTimer);
    };
  }, [preloadComponent]);

  // Helper function to map paths to components
  const getComponentFromPath = (path: string): string | null => {
    const pathMap: Record<string, string> = {
      '/events': 'Events',
      '/connections': 'Matches',
      '/messenger': 'Messenger',
      '/profile': 'UserProfile',
      '/settings': 'AccountSettings',
      '/payment-portal': 'PaymentPortal'
    };

    return pathMap[path] || null;
  };

  // Initialize optimizations
  useEffect(() => {
    const cleanup = collectMetrics();
    addResourceHints();
    setupComponentCache();
    optimizeCriticalPath();
    const behaviorCleanup = setupBehaviorBasedPreloading();
    
    // Analyze bundle size after initial load
    setTimeout(analyzeBundleSize, 2000);

    return () => {
      cleanup?.();
      behaviorCleanup?.();
    };
  }, [collectMetrics, addResourceHints, setupComponentCache, optimizeCriticalPath, setupBehaviorBasedPreloading, analyzeBundleSize]);

  return {
    metrics,
    isOptimizing,
    preloadComponent,
    analyzeBundleSize
  };
}