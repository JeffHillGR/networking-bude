import { useState, useCallback, useMemo } from 'react';

export function useAppUI() {
  const [forceMobileView] = useState(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get('mobile') === 'true';
  });

  const getPreviewContainerClass = useCallback(() => {
    return forceMobileView ? 'mobile-preview-container' : '';
  }, [forceMobileView]);

  const isMobilePreview = useMemo(() => forceMobileView, [forceMobileView]);

  const shouldShowMobileHeader = useCallback(() => {
    return forceMobileView || window.innerWidth < 768;
  }, [forceMobileView]);

  const shouldShowDesktopSidebar = useCallback(() => {
    return !forceMobileView && window.innerWidth >= 768;
  }, [forceMobileView]);

  const getMainContentClass = useCallback(() => {
    return `flex-1 ${forceMobileView ? 'pb-20' : 'md:ml-64 pb-20 md:pb-0'} transition-all duration-200`;
  }, [forceMobileView]);

  return {
    forceMobileView,
    isMobilePreview,
    getPreviewContainerClass,
    shouldShowMobileHeader,
    shouldShowDesktopSidebar,
    getMainContentClass
  };
}