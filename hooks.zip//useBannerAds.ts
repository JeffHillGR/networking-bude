import { useState, useEffect, useCallback } from 'react';
import { toast } from 'sonner@2.0.3';

export interface BannerAd {
  id: string;
  name: string;
  imageUrl: string;
  title: string;
  subtitle?: string;
  ctaText: string;
  ctaUrl: string;
  isActive: boolean;
  priority: number; // Higher number = higher priority in rotation
  targetPages: ('dashboard' | 'events' | 'connections' | 'all')[];
  schedule?: {
    startDate?: string;
    endDate?: string;
  };
  analytics: {
    views: number;
    clicks: number;
    ctr: number; // Click-through rate
  };
  createdDate: string;
  lastUpdated: string;
}

// Mock banner ads data - in real app this would come from backend
const INITIAL_BANNER_ADS: BannerAd[] = [
  {
    id: '1',
    name: 'Grand Rapids Chamber Networking',
    imageUrl: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800&h=240&fit=crop&crop=center',
    title: 'Join Grand Rapids Chamber',
    subtitle: 'Connect with 2,000+ local business leaders',
    ctaText: 'Learn More',
    ctaUrl: 'https://grandrapids.org',
    isActive: true,
    priority: 10,
    targetPages: ['dashboard', 'events'],
    schedule: {
      startDate: '2025-01-01',
      endDate: '2025-12-31'
    },
    analytics: {
      views: 1247,
      clicks: 89,
      ctr: 7.1
    },
    createdDate: '2025-01-01',
    lastUpdated: '2025-01-15'
  },
  {
    id: '2',
    name: 'BudE+ Premium Features',
    imageUrl: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=200&h=120&fit=crop&crop=center',
    title: 'Upgrade to BudE+ Today',
    subtitle: 'Unlock premium networking features',
    ctaText: 'Upgrade Now',
    ctaUrl: '/payment-portal',
    isActive: true,
    priority: 8,
    targetPages: ['all'],
    analytics: {
      views: 892,
      clicks: 156,
      ctr: 17.5
    },
    createdDate: '2025-02-01',
    lastUpdated: '2025-02-01'
  },
  {
    id: '3',
    name: 'Local Coffee Shop Partnership',
    imageUrl: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=800&h=240&fit=crop&crop=center',
    title: 'Network at Brew Coffee House',
    subtitle: '15% off for BudE members',
    ctaText: 'Get Discount',
    ctaUrl: 'https://brewcoffeehouse.com/bude',
    isActive: true,
    priority: 5,
    targetPages: ['dashboard'],
    schedule: {
      startDate: '2025-01-15',
      endDate: '2025-03-15'
    },
    analytics: {
      views: 654,
      clicks: 32,
      ctr: 4.9
    },
    createdDate: '2025-01-15',
    lastUpdated: '2025-01-20'
  },
  {
    id: '4',
    name: 'Tech Meetup Series',
    imageUrl: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&h=240&fit=crop&crop=center',
    title: 'Grand Rapids Tech Meetups',
    subtitle: 'Every Tuesday at 6 PM',
    ctaText: 'Join Meetup',
    ctaUrl: 'https://meetup.com/gr-tech',
    isActive: false,
    priority: 6,
    targetPages: ['events'],
    analytics: {
      views: 423,
      clicks: 67,
      ctr: 15.8
    },
    createdDate: '2025-01-10',
    lastUpdated: '2025-01-25'
  },
  {
    id: '5',
    name: 'BudE Lapel Pin Collection',
    imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=200&h=120&fit=crop&crop=center',
    title: 'Show Your BudE Pride',
    subtitle: 'Premium lapel pins now available',
    ctaText: 'Shop Now',
    ctaUrl: '/shop/lapel-pins',
    isActive: true,
    priority: 3,
    targetPages: ['dashboard', 'connections'],
    analytics: {
      views: 234,
      clicks: 18,
      ctr: 7.7
    },
    createdDate: '2025-02-01',
    lastUpdated: '2025-02-01'
  },
  {
    id: '6',
    name: 'The Right Place Economic Development',
    imageUrl: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800&h=240&fit=crop&crop=center',
    title: 'Grow Your Business in West Michigan',
    subtitle: 'Economic development resources and networking',
    ctaText: 'Explore Opportunities',
    ctaUrl: 'https://rightplace.org',
    isActive: true,
    priority: 7,
    targetPages: ['events', 'connections'],
    analytics: {
      views: 687,
      clicks: 73,
      ctr: 10.6
    },
    createdDate: '2025-01-20',
    lastUpdated: '2025-02-01'
  },
  {
    id: '7',
    name: 'Economics Club of Grand Rapids',
    imageUrl: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=800&h=240&fit=crop&crop=center',
    title: 'Join Economic Leaders',
    subtitle: 'Monthly policy discussions and networking',
    ctaText: 'Learn More',
    ctaUrl: 'https://econclub.net',
    isActive: true,
    priority: 6,
    targetPages: ['events'],
    analytics: {
      views: 543,
      clicks: 41,
      ctr: 7.5
    },
    createdDate: '2025-01-25',
    lastUpdated: '2025-02-01'
  },
  {
    id: '8',
    name: 'Bamboo Coworking Space',
    imageUrl: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&h=240&fit=crop&crop=center',
    title: 'Network at Bamboo',
    subtitle: 'Modern coworking in downtown Grand Rapids',
    ctaText: 'Tour Space',
    ctaUrl: 'https://bamboocowork.com',
    isActive: true,
    priority: 5,
    targetPages: ['events', 'connections'],
    analytics: {
      views: 421,
      clicks: 38,
      ctr: 9.0
    },
    createdDate: '2025-01-28',
    lastUpdated: '2025-02-01'
  },
  {
    id: '9',
    name: 'Hello West Michigan',
    imageUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&h=240&fit=crop&crop=center',
    title: 'Connect with West Michigan',
    subtitle: 'Virtual networking events and community',
    ctaText: 'Join Community',
    ctaUrl: 'https://hellowestmichigan.com',
    isActive: true,
    priority: 4,
    targetPages: ['events', 'connections'],
    analytics: {
      views: 312,
      clicks: 29,
      ctr: 9.3
    },
    createdDate: '2025-01-30',
    lastUpdated: '2025-02-01'
  },
  {
    id: '10',
    name: 'BudE Professional Services',
    imageUrl: 'https://images.unsplash.com/photo-1560472355-536de3962603?w=200&h=120&fit=crop&crop=center',
    title: 'BudE Professional Coaching',
    subtitle: 'One-on-one networking strategy sessions',
    ctaText: 'Book Session',
    ctaUrl: '/coaching',
    isActive: true,
    priority: 9,
    targetPages: ['dashboard'],
    analytics: {
      views: 145,
      clicks: 23,
      ctr: 15.9
    },
    createdDate: '2025-02-03',
    lastUpdated: '2025-02-03'
  },
  {
    id: '11',
    name: 'BudE Success Stories',
    imageUrl: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=200&h=120&fit=crop&crop=center',
    title: 'Read Success Stories',
    subtitle: 'How BudE members landed their dream jobs',
    ctaText: 'Read Stories',
    ctaUrl: '/success-stories',
    isActive: true,
    priority: 6,
    targetPages: ['dashboard'],
    analytics: {
      views: 287,
      clicks: 31,
      ctr: 10.8
    },
    createdDate: '2025-02-03',
    lastUpdated: '2025-02-03'
  }
];

export function useBannerAds() {
  const [bannerAds, setBannerAds] = useState<BannerAd[]>(INITIAL_BANNER_ADS);
  const [currentAdRotation, setCurrentAdRotation] = useState<{ [key: string]: number }>({});

  // Get active ads for a specific page
  const getActiveBannerAds = useCallback((page: 'dashboard' | 'events' | 'connections' | 'all' = 'all') => {
    const now = new Date();
    
    return bannerAds
      .filter(ad => {
        // Check if ad is active
        if (!ad.isActive) return false;
        
        // Check if ad targets this page
        if (!ad.targetPages.includes(page) && !ad.targetPages.includes('all')) return false;
        
        // Check schedule
        if (ad.schedule) {
          if (ad.schedule.startDate && new Date(ad.schedule.startDate) > now) return false;
          if (ad.schedule.endDate && new Date(ad.schedule.endDate) < now) return false;
        }
        
        return true;
      })
      .sort((a, b) => b.priority - a.priority); // Sort by priority (highest first)
  }, [bannerAds]);

  // Get current ad for rotation
  const getCurrentBannerAd = useCallback((page: 'dashboard' | 'events' | 'connections' | 'all' = 'all') => {
    const activeAds = getActiveBannerAds(page);
    if (activeAds.length === 0) return null;
    
    // Use rotation index for this page
    const rotationIndex = currentAdRotation[page] || 0;
    return activeAds[rotationIndex % activeAds.length];
  }, [getActiveBannerAds, currentAdRotation]);

  // Rotate to next ad
  const rotateToNextAd = useCallback((page: 'dashboard' | 'events' | 'connections' | 'all' = 'all') => {
    const activeAds = getActiveBannerAds(page);
    if (activeAds.length <= 1) return;
    
    setCurrentAdRotation(prev => ({
      ...prev,
      [page]: ((prev[page] || 0) + 1) % activeAds.length
    }));
  }, [getActiveBannerAds]);

  // Initial rotation setup on mount (no automatic rotation to prevent issues)
  useEffect(() => {
    const pages: ('dashboard' | 'events' | 'connections')[] = ['dashboard', 'events', 'connections'];
    
    // Initial random rotation on mount only
    pages.forEach(page => {
      const now = new Date();
      const activeAds = bannerAds
        .filter(ad => {
          if (!ad.isActive) return false;
          if (!ad.targetPages.includes(page) && !ad.targetPages.includes('all')) return false;
          if (ad.schedule) {
            if (ad.schedule.startDate && new Date(ad.schedule.startDate) > now) return false;
            if (ad.schedule.endDate && new Date(ad.schedule.endDate) < now) return false;
          }
          return true;
        })
        .sort((a, b) => b.priority - a.priority);
        
      if (activeAds.length > 1) {
        const randomIndex = Math.floor(Math.random() * activeAds.length);
        setCurrentAdRotation(prev => ({
          ...prev,
          [page]: randomIndex
        }));
      }
    });
  }, []); // Empty dependency array - only run once on mount

  // Record banner view
  const recordBannerView = useCallback((bannerId: string) => {
    setBannerAds(prev => prev.map(ad => 
      ad.id === bannerId 
        ? { 
            ...ad, 
            analytics: { 
              ...ad.analytics, 
              views: ad.analytics.views + 1,
              ctr: ad.analytics.clicks / (ad.analytics.views + 1) * 100
            } 
          }
        : ad
    ));
  }, []);

  // Record banner click
  const recordBannerClick = useCallback((bannerId: string) => {
    setBannerAds(prev => prev.map(ad => 
      ad.id === bannerId 
        ? { 
            ...ad, 
            analytics: { 
              ...ad.analytics, 
              clicks: ad.analytics.clicks + 1,
              ctr: (ad.analytics.clicks + 1) / ad.analytics.views * 100
            } 
          }
        : ad
    ));
  }, []);

  // Create new banner ad
  const createBannerAd = useCallback((adData: Omit<BannerAd, 'id' | 'analytics' | 'createdDate' | 'lastUpdated'>) => {
    const newAd: BannerAd = {
      ...adData,
      id: Date.now().toString(),
      analytics: {
        views: 0,
        clicks: 0,
        ctr: 0
      },
      createdDate: new Date().toISOString().split('T')[0],
      lastUpdated: new Date().toISOString().split('T')[0]
    };

    setBannerAds(prev => [...prev, newAd]);
    toast.success('Banner ad created successfully!');
    return newAd;
  }, []);

  // Update existing banner ad
  const updateBannerAd = useCallback((adId: string, updates: Partial<BannerAd>) => {
    setBannerAds(prev => prev.map(ad => 
      ad.id === adId 
        ? { 
            ...ad, 
            ...updates, 
            lastUpdated: new Date().toISOString().split('T')[0] 
          }
        : ad
    ));
    toast.success('Banner ad updated successfully!');
  }, []);

  // Delete banner ad
  const deleteBannerAd = useCallback((adId: string) => {
    setBannerAds(prev => prev.filter(ad => ad.id !== adId));
    toast.success('Banner ad deleted successfully!');
  }, []);

  // Toggle banner ad status
  const toggleBannerAdStatus = useCallback((adId: string) => {
    setBannerAds(prev => prev.map(ad => 
      ad.id === adId 
        ? { 
            ...ad, 
            isActive: !ad.isActive,
            lastUpdated: new Date().toISOString().split('T')[0] 
          }
        : ad
    ));
    
    const ad = bannerAds.find(a => a.id === adId);
    toast.success(`Banner ad ${ad?.isActive ? 'deactivated' : 'activated'} successfully!`);
  }, [bannerAds]);

  // Get banner statistics
  const getBannerStatistics = useCallback(() => {
    const totalViews = bannerAds.reduce((sum, ad) => sum + ad.analytics.views, 0);
    const totalClicks = bannerAds.reduce((sum, ad) => sum + ad.analytics.clicks, 0);
    const averageCTR = totalViews > 0 ? (totalClicks / totalViews * 100) : 0;
    const activeAds = bannerAds.filter(ad => ad.isActive).length;
    
    return {
      totalAds: bannerAds.length,
      activeAds,
      totalViews,
      totalClicks,
      averageCTR: Math.round(averageCTR * 100) / 100
    };
  }, [bannerAds]);

  return {
    bannerAds,
    getActiveBannerAds,
    getCurrentBannerAd,
    rotateToNextAd,
    recordBannerView,
    recordBannerClick,
    createBannerAd,
    updateBannerAd,
    deleteBannerAd,
    toggleBannerAdStatus,
    getBannerStatistics
  };
}