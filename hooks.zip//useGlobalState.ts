// Global State Management & Intelligent Caching System
import { useState, useEffect, useCallback, useContext, createContext, ReactNode } from 'react';
import { UserData } from '../types';

// Cache configuration
interface CacheConfig {
  maxAge: number; // in milliseconds
  maxSize: number; // maximum number of cached items
  strategy: 'lru' | 'lfu' | 'ttl'; // cache eviction strategy
}

// Global state interface
interface GlobalState {
  user: UserData | null;
  connections: any[];
  events: any[];
  messages: any[];
  notifications: any[];
  ui: {
    sidebarOpen: boolean;
    theme: 'light' | 'dark' | 'system';
    mobileView: boolean;
    loading: Record<string, boolean>;
    errors: Record<string, string | null>;
  };
}

// Cache entry interface
interface CacheEntry<T = any> {
  data: T;
  timestamp: number;
  accessCount: number;
  lastAccessed: number;
}

// Global state context
interface GlobalStateContextType {
  state: GlobalState;
  updateUser: (user: Partial<UserData>) => void;
  updateConnections: (connections: any[]) => void;
  updateEvents: (events: any[]) => void;
  updateMessages: (messages: any[]) => void;
  addNotification: (notification: any) => void;
  removeNotification: (id: string) => void;
  setLoading: (key: string, loading: boolean) => void;
  setError: (key: string, error: string | null) => void;
  toggleSidebar: () => void;
  setTheme: (theme: 'light' | 'dark' | 'system') => void;
  setMobileView: (mobile: boolean) => void;
  clearCache: (pattern?: string) => void;
  getCachedData: (key: string) => any;
  setCachedData: (key: string, data: any, customTtl?: number) => void;
}

// Cache class for intelligent data caching
class IntelligentCache {
  private cache = new Map<string, CacheEntry>();
  private config: CacheConfig;

  constructor(config: CacheConfig) {
    this.config = config;
  }

  get<T>(key: string): T | null {
    const entry = this.cache.get(key);
    
    if (!entry) return null;
    
    const now = Date.now();
    
    // Check if expired
    if (now - entry.timestamp > this.config.maxAge) {
      this.cache.delete(key);
      return null;
    }
    
    // Update access statistics
    entry.accessCount++;
    entry.lastAccessed = now;
    
    return entry.data as T;
  }

  set<T>(key: string, data: T, customTtl?: number): void {
    const now = Date.now();
    
    // Check cache size and evict if necessary
    if (this.cache.size >= this.config.maxSize) {
      this.evict();
    }
    
    this.cache.set(key, {
      data,
      timestamp: now,
      accessCount: 1,
      lastAccessed: now
    });
  }

  private evict(): void {
    const entries = Array.from(this.cache.entries());
    
    let keyToEvict: string;
    
    switch (this.config.strategy) {
      case 'lru': // Least Recently Used
        keyToEvict = entries.reduce((oldest, [key, entry]) => {
          const [oldestKey, oldestEntry] = oldest;
          return entry.lastAccessed < oldestEntry.lastAccessed ? [key, entry] : oldest;
        })[0];
        break;
        
      case 'lfu': // Least Frequently Used
        keyToEvict = entries.reduce((least, [key, entry]) => {
          const [leastKey, leastEntry] = least;
          return entry.accessCount < leastEntry.accessCount ? [key, entry] : least;
        })[0];
        break;
        
      case 'ttl': // Time To Live (oldest timestamp)
      default:
        keyToEvict = entries.reduce((oldest, [key, entry]) => {
          const [oldestKey, oldestEntry] = oldest;
          return entry.timestamp < oldestEntry.timestamp ? [key, entry] : oldest;
        })[0];
        break;
    }
    
    this.cache.delete(keyToEvict);
  }

  clear(pattern?: string): void {
    if (pattern) {
      const regex = new RegExp(pattern);
      const keysToDelete = Array.from(this.cache.keys()).filter(key => regex.test(key));
      keysToDelete.forEach(key => this.cache.delete(key));
    } else {
      this.cache.clear();
    }
  }

  getStats() {
    const entries = Array.from(this.cache.values());
    return {
      size: this.cache.size,
      totalAccesses: entries.reduce((total, entry) => total + entry.accessCount, 0),
      averageAge: entries.reduce((total, entry) => total + (Date.now() - entry.timestamp), 0) / entries.length,
      hitRate: this.calculateHitRate()
    };
  }

  private calculateHitRate(): number {
    // This would be implemented with additional tracking
    return 0.85; // Placeholder
  }
}

// Initialize cache instance
const cache = new IntelligentCache({
  maxAge: 5 * 60 * 1000, // 5 minutes
  maxSize: 100,
  strategy: 'lru'
});

// Create context
const GlobalStateContext = createContext<GlobalStateContextType | null>(null);

// Initial state
const initialState: GlobalState = {
  user: null,
  connections: [],
  events: [],
  messages: [],
  notifications: [],
  ui: {
    sidebarOpen: false,
    theme: 'system',
    mobileView: false,
    loading: {},
    errors: {}
  }
};

// State provider component
export function GlobalStateProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<GlobalState>(initialState);

  // Load persisted state
  useEffect(() => {
    try {
      if (typeof Storage !== 'undefined') {
        const stored = localStorage.getItem('networking-bude-state');
        if (stored) {
          const parsedState = JSON.parse(stored);
          setState(prev => ({
            ...prev,
            ...parsedState,
            ui: { ...prev.ui, ...parsedState.ui } // Merge UI state carefully
          }));
        }
      }
    } catch (error) {
      console.warn('Failed to load persisted state (gracefully degrading):', error.message);
    }
  }, []);

  // Persist state changes (debounced)
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      try {
        if (typeof Storage !== 'undefined') {
          const stateToStore = {
            user: state.user,
            ui: {
              theme: state.ui.theme,
              sidebarOpen: state.ui.sidebarOpen
            }
          };
          localStorage.setItem('networking-bude-state', JSON.stringify(stateToStore));
        }
      } catch (error) {
        console.warn('Failed to persist state (gracefully degrading):', error.message);
      }
    }, 1000);

    return () => clearTimeout(timeoutId);
  }, [state.user, state.ui.theme, state.ui.sidebarOpen]);

  // State update functions
  const updateUser = useCallback((user: Partial<UserData>) => {
    setState(prev => ({
      ...prev,
      user: prev.user ? { ...prev.user, ...user } : user as UserData
    }));
    
    // Cache user data
    if (user.id) {
      cache.set(`user:${user.id}`, user);
    }
  }, []);

  const updateConnections = useCallback((connections: any[]) => {
    setState(prev => ({ ...prev, connections }));
    cache.set('connections', connections);
  }, []);

  const updateEvents = useCallback((events: any[]) => {
    setState(prev => ({ ...prev, events }));
    cache.set('events', events);
  }, []);

  const updateMessages = useCallback((messages: any[]) => {
    setState(prev => ({ ...prev, messages }));
    cache.set('messages', messages);
  }, []);

  const addNotification = useCallback((notification: any) => {
    const notificationWithId = {
      ...notification,
      id: notification.id || Date.now().toString(),
      timestamp: Date.now()
    };
    
    setState(prev => ({
      ...prev,
      notifications: [...prev.notifications, notificationWithId]
    }));

    // Auto-remove after 5 seconds if not persistent
    if (!notification.persistent) {
      setTimeout(() => {
        removeNotification(notificationWithId.id);
      }, 5000);
    }
  }, []);

  const removeNotification = useCallback((id: string) => {
    setState(prev => ({
      ...prev,
      notifications: prev.notifications.filter(n => n.id !== id)
    }));
  }, []);

  const setLoading = useCallback((key: string, loading: boolean) => {
    setState(prev => ({
      ...prev,
      ui: {
        ...prev.ui,
        loading: { ...prev.ui.loading, [key]: loading }
      }
    }));
  }, []);

  const setError = useCallback((key: string, error: string | null) => {
    setState(prev => ({
      ...prev,
      ui: {
        ...prev.ui,
        errors: { ...prev.ui.errors, [key]: error }
      }
    }));
  }, []);

  const toggleSidebar = useCallback(() => {
    setState(prev => ({
      ...prev,
      ui: { ...prev.ui, sidebarOpen: !prev.ui.sidebarOpen }
    }));
  }, []);

  const setTheme = useCallback((theme: 'light' | 'dark' | 'system') => {
    setState(prev => ({
      ...prev,
      ui: { ...prev.ui, theme }
    }));

    // Apply theme to document
    const root = document.documentElement;
    if (theme === 'system') {
      const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      root.classList.toggle('dark', systemTheme === 'dark');
    } else {
      root.classList.toggle('dark', theme === 'dark');
    }
  }, []);

  const setMobileView = useCallback((mobile: boolean) => {
    setState(prev => ({
      ...prev,
      ui: { ...prev.ui, mobileView: mobile }
    }));
  }, []);

  const clearCache = useCallback((pattern?: string) => {
    cache.clear(pattern);
  }, []);

  const getCachedData = useCallback((key: string) => {
    return cache.get(key);
  }, []);

  const setCachedData = useCallback((key: string, data: any, customTtl?: number) => {
    cache.set(key, data, customTtl);
  }, []);

  const contextValue: GlobalStateContextType = {
    state,
    updateUser,
    updateConnections,
    updateEvents,
    updateMessages,
    addNotification,
    removeNotification,
    setLoading,
    setError,
    toggleSidebar,
    setTheme,
    setMobileView,
    clearCache,
    getCachedData,
    setCachedData
  };

  return (
    <GlobalStateContext.Provider value={contextValue}>
      {children}
    </GlobalStateContext.Provider>
  );
}

// Hook to use global state
export function useGlobalState() {
  const context = useContext(GlobalStateContext);
  if (!context) {
    throw new Error('useGlobalState must be used within a GlobalStateProvider');
  }
  return context;
}

// Specialized hooks for specific data
export function useUserData() {
  const { state, updateUser } = useGlobalState();
  return { user: state.user, updateUser };
}

export function useConnections() {
  const { state, updateConnections, getCachedData, setCachedData } = useGlobalState();
  
  const refreshConnections = useCallback(async () => {
    try {
      // Check cache first
      const cached = getCachedData('connections') as any[];
      if (cached) {
        updateConnections(cached);
        return cached;
      }

      // Fetch fresh data
      const response = await fetch('/api/connections');
      const connections = await response.json();
      
      updateConnections(connections);
      setCachedData('connections', connections);
      
      return connections;
    } catch (error) {
      console.error('Failed to refresh connections:', error);
      return state.connections;
    }
  }, [state.connections, updateConnections, getCachedData, setCachedData]);

  return {
    connections: state.connections,
    updateConnections,
    refreshConnections
  };
}

export function useEvents() {
  const { state, updateEvents, getCachedData, setCachedData } = useGlobalState();
  
  const refreshEvents = useCallback(async () => {
    try {
      const cached = getCachedData('events') as any[];
      if (cached) {
        updateEvents(cached);
        return cached;
      }

      const response = await fetch('/api/events');
      const events = await response.json();
      
      updateEvents(events);
      setCachedData('events', events);
      
      return events;
    } catch (error) {
      console.error('Failed to refresh events:', error);
      return state.events;
    }
  }, [state.events, updateEvents, getCachedData, setCachedData]);

  return {
    events: state.events,
    updateEvents,
    refreshEvents
  };
}

export function useNotifications() {
  const { state, addNotification, removeNotification } = useGlobalState();
  
  return {
    notifications: state.notifications,
    addNotification,
    removeNotification
  };
}

export function useUI() {
  const { state, setLoading, setError, toggleSidebar, setTheme, setMobileView } = useGlobalState();
  
  return {
    ui: state.ui,
    setLoading,
    setError,
    toggleSidebar,
    setTheme,
    setMobileView
  };
}