import { useCallback, useTransition } from 'react';
import { useNavigate } from 'react-router-dom';

export function useAppRouting() {
  const navigate = useNavigate();
  const [isPending, startTransition] = useTransition();

  const navigateWithTransition = useCallback((path: string, options: { replace?: boolean } = {}) => {
    startTransition(() => {
      if (options.replace) {
        navigate(path, { replace: true });
      } else {
        navigate(path);
      }
    });
  }, [navigate]);

  const navigateBack = useCallback(() => {
    startTransition(() => {
      window.history.back();
    });
  }, []);

  const replaceUrl = useCallback((path: string) => {
    window.history.replaceState({}, '', path);
  }, []);

  return { 
    isPending, 
    navigateWithTransition, 
    navigateBack, 
    replaceUrl 
  };
}