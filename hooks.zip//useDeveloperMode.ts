// Developer mode hook - Extracted from App.tsx for better organization
import { useState, useEffect, useCallback } from 'react';

interface DeveloperModeConfig {
  enableUrlParams: boolean;
  enableSessionStorage: boolean;
  defaultComponent?: string;
}

const DEFAULT_CONFIG: DeveloperModeConfig = {
  enableUrlParams: true,
  enableSessionStorage: true,
  defaultComponent: 'dashboard'
};

export const useDeveloperMode = (config: Partial<DeveloperModeConfig> = {}) => {
  const devConfig = { ...DEFAULT_CONFIG, ...config };
  
  const [isDeveloperMode, setIsDeveloperMode] = useState(false);
  const [editingComponent, setEditingComponent] = useState<string | null>(null);

  // Initialize developer mode from URL params and session storage
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const devMode = devConfig.enableUrlParams && urlParams.get('dev') === 'true';
    const editing = devConfig.enableUrlParams ? urlParams.get('editing') : null;
    
    setIsDeveloperMode(devMode);
    
    if (editing) {
      setEditingComponent(editing);
      if (devConfig.enableSessionStorage) {
        sessionStorage.setItem('networking-bude-editing', editing);
      }
    } else if (devMode && devConfig.enableSessionStorage) {
      const storedEditing = sessionStorage.getItem('networking-bude-editing');
      if (storedEditing) {
        setEditingComponent(storedEditing);
      } else if (devConfig.defaultComponent) {
        setEditingComponent(devConfig.defaultComponent);
      }
    }
  }, [devConfig.enableUrlParams, devConfig.enableSessionStorage, devConfig.defaultComponent]);
  
  const enterDeveloperMode = useCallback((component: string = devConfig.defaultComponent || 'dashboard') => {
    if (devConfig.enableUrlParams) {
      const url = new URL(window.location.href);
      url.searchParams.set('dev', 'true');
      url.searchParams.set('editing', component);
      window.history.replaceState({}, '', url.toString());
    }
    
    setIsDeveloperMode(true);
    setEditingComponent(component);
    
    if (devConfig.enableSessionStorage) {
      sessionStorage.setItem('networking-bude-editing', component);
    }
    
    // Dispatch custom event for other components to listen to
    window.dispatchEvent(new CustomEvent('developerModeEntered', { 
      detail: { component } 
    }));
  }, [devConfig.enableUrlParams, devConfig.enableSessionStorage, devConfig.defaultComponent]);
  
  const exitDeveloperMode = useCallback(() => {
    if (devConfig.enableUrlParams) {
      const url = new URL(window.location.href);
      url.searchParams.delete('dev');
      url.searchParams.delete('editing');
      window.history.replaceState({}, '', url.toString());
    }
    
    setIsDeveloperMode(false);
    setEditingComponent(null);
    
    if (devConfig.enableSessionStorage) {
      sessionStorage.removeItem('networking-bude-editing');
    }
    
    // Dispatch custom event
    window.dispatchEvent(new CustomEvent('developerModeExited'));
  }, [devConfig.enableUrlParams, devConfig.enableSessionStorage]);
  
  const updateEditingComponent = useCallback((component: string) => {
    if (devConfig.enableUrlParams) {
      const url = new URL(window.location.href);
      url.searchParams.set('editing', component);
      window.history.replaceState({}, '', url.toString());
    }
    
    setEditingComponent(component);
    
    if (devConfig.enableSessionStorage) {
      sessionStorage.setItem('networking-bude-editing', component);
    }
    
    // Dispatch custom event
    window.dispatchEvent(new CustomEvent('editingComponentChanged', { 
      detail: { component } 
    }));
  }, [devConfig.enableUrlParams, devConfig.enableSessionStorage]);

  const getAvailableComponents = useCallback(() => {
    return [
      { key: 'dashboard', path: '/dashboard', label: 'Dashboard' },
      { key: 'events', path: '/events', label: 'Events' },
      { key: 'connections', path: '/connections', label: 'Connections' },
      { key: 'messenger', path: '/messenger', label: 'Messenger' },
      { key: 'profile', path: '/profile/current', label: 'Profile' },
      { key: 'settings', path: '/settings', label: 'Settings' }
    ];
  }, []);
  
  return {
    isDeveloperMode,
    editingComponent,
    enterDeveloperMode,
    exitDeveloperMode,
    updateEditingComponent,
    getAvailableComponents
  };
};