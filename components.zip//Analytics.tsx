import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { 
  TrendingUp, 
  Users, 
  Calendar, 
  MessageCircle, 
  Target,
  Award,
  BarChart3,
  Activity,
  DollarSign,
  UserPlus,
  Handshake,
  MapPin
} from 'lucide-react';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const monthlyGrowthData = [
  { month: 'Jan', users: 1200, events: 45, matches: 890, revenue: 14800 },
  { month: 'Feb', users: 1850, events: 62, matches: 1340, revenue: 22400 },
  { month: 'Mar', users: 2400, events: 78, matches: 1820, revenue: 31200 },
  { month: 'Apr', users: 3200, events: 95, matches: 2450, revenue: 41600 },
  { month: 'May', users: 4100, events: 118, matches: 3200, revenue: 54300 },
  { month: 'Jun', users: 5300, events: 142, matches: 4180, revenue: 71200 },
  { month: 'Jul', users: 6800, events: 168, matches: 5420, revenue: 92400 },
  { month: 'Aug', users: 8500, events: 195, matches: 6890, revenue: 118600 },
  { month: 'Sep', users: 10200, events: 224, matches: 8340, revenue: 147800 }
];

const userEngagementData = [
  { day: 'Mon', activeUsers: 3420, messagesSent: 1240, eventsJoined: 89 },
  { day: 'Tue', activeUsers: 3680, messagesSent: 1580, eventsJoined: 125 },
  { day: 'Wed', activeUsers: 4120, messagesSent: 1890, eventsJoined: 156 },
  { day: 'Thu', activeUsers: 4560, messagesSent: 2140, eventsJoined: 178 },
  { day: 'Fri', activeUsers: 4890, messagesSent: 2380, eventsJoined: 204 },
  { day: 'Sat', activeUsers: 3240, messagesSent: 1120, eventsJoined: 98 },
  { day: 'Sun', activeUsers: 2980, messagesSent: 980, eventsJoined: 67 }
];

const industryBreakdown = [
  { name: 'Technology', value: 35, color: '#22c55e' },
  { name: 'Finance', value: 18, color: '#3b82f6' },
  { name: 'Healthcare', value: 15, color: '#f59e0b' },
  { name: 'Marketing', value: 12, color: '#ef4444' },
  { name: 'Education', value: 10, color: '#8b5cf6' },
  { name: 'Other', value: 10, color: '#6b7280' }
];

const geographicData = [
  { city: 'San Francisco', users: 2840, growth: '+18%' },
  { city: 'New York', users: 2230, growth: '+22%' },
  { city: 'Los Angeles', users: 1680, growth: '+15%' },
  { city: 'Seattle', users: 1420, growth: '+28%' },
  { city: 'Austin', users: 1180, growth: '+31%' },
  { city: 'Boston', users: 980, growth: '+19%' }
];

const successMetrics = [
  { metric: 'Connection Success Rate', value: '78%', change: '+5.2%', trend: 'up' },
  { metric: 'Event Attendance Rate', value: '82%', change: '+8.1%', trend: 'up' },
  { metric: 'Message Response Rate', value: '71%', change: '+3.4%', trend: 'up' },
  { metric: 'User Retention (30-day)', value: '84%', change: '+12.3%', trend: 'up' },
  { metric: 'Premium Conversion', value: '23%', change: '+6.7%', trend: 'up' },
  { metric: 'Net Promoter Score', value: '68', change: '+9.2%', trend: 'up' }
];

export function Analytics() {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl mb-2">Platform Analytics</h1>
        <p className="text-muted-foreground">
          Real-time insights into user engagement, growth metrics, and platform performance
        </p>
      </div>

      {/* Key Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Users</p>
                <p className="text-2xl font-bold">10,247</p>
                <p className="text-sm text-green-600">+20.1% from last month</p>
              </div>
              <Users className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Monthly Revenue</p>
                <p className="text-2xl font-bold">$147,800</p>
                <p className="text-sm text-green-600">+24.7% from last month</p>
              </div>
              <DollarSign className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Connections</p>
                <p className="text-2xl font-bold">8,342</p>
                <p className="text-sm text-green-600">+18.3% from last month</p>
              </div>
              <Handshake className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Events Hosted</p>
                <p className="text-2xl font-bold">224</p>
                <p className="text-sm text-green-600">+14.9% from last month</p>
              </div>
              <Calendar className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* User Growth Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Platform Growth</CardTitle>
            <CardDescription>Monthly user acquisition and revenue trends</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={monthlyGrowthData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis yAxisId="left" />
                <YAxis yAxisId="right" orientation="right" />
                <Tooltip />
                <Legend />
                <Line 
                  yAxisId="left" 
                  type="monotone" 
                  dataKey="users" 
                  stroke="#22c55e" 
                  strokeWidth={3}
                  name="Total Users"
                />
                <Line 
                  yAxisId="right" 
                  type="monotone" 
                  dataKey="revenue" 
                  stroke="#3b82f6" 
                  strokeWidth={2}
                  name="Revenue ($)"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Engagement Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Weekly Engagement</CardTitle>
            <CardDescription>Daily active users and platform interactions</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={userEngagementData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Area 
                  type="monotone" 
                  dataKey="activeUsers" 
                  stackId="1"
                  stroke="#22c55e" 
                  fill="#22c55e" 
                  fillOpacity={0.3}
                  name="Active Users"
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Success Metrics */}
      <Card>
        <CardHeader>
          <CardTitle>Key Performance Indicators</CardTitle>
          <CardDescription>Critical metrics showing platform health and user satisfaction</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {successMetrics.map((metric, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm text-muted-foreground">{metric.metric}</p>
                  <TrendingUp className="h-4 w-4 text-green-600" />
                </div>
                <p className="text-2xl font-bold">{metric.value}</p>
                <p className="text-sm text-green-600">{metric.change} vs last month</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Industry and Geographic Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Industry Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle>User Distribution by Industry</CardTitle>
            <CardDescription>Professional backgrounds of platform users</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={industryBreakdown}
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}%`}
                >
                  {industryBreakdown.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Geographic Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Top Markets</CardTitle>
            <CardDescription>User concentration by metropolitan area</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {geographicData.map((city, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="font-medium">{city.city}</p>
                      <p className="text-sm text-muted-foreground">{city.users} users</p>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-green-600">
                    {city.growth}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Network Effects */}
      <Card>
        <CardHeader>
          <CardTitle>Network Effects & Virality</CardTitle>
          <CardDescription>Platform growth through user referrals and organic expansion</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center p-4 border rounded-lg">
              <UserPlus className="h-8 w-8 text-primary mx-auto mb-2" />
              <p className="text-2xl font-bold">3.2</p>
              <p className="text-sm text-muted-foreground">Avg Referrals per User</p>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <Activity className="h-8 w-8 text-primary mx-auto mb-2" />
              <p className="text-2xl font-bold">42%</p>
              <p className="text-sm text-muted-foreground">Viral Coefficient</p>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <Target className="h-8 w-8 text-primary mx-auto mb-2" />
              <p className="text-2xl font-bold">$18</p>
              <p className="text-sm text-muted-foreground">Customer Acquisition Cost</p>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <Award className="h-8 w-8 text-primary mx-auto mb-2" />
              <p className="text-2xl font-bold">$240</p>
              <p className="text-sm text-muted-foreground">Lifetime Value</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}