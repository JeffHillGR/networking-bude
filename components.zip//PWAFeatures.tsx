// PWA features component - Extracted PWA functionality from App.tsx
import { memo, useState, useEffect, useCallback } from 'react';
import { usePWA } from '../hooks/usePWA';

interface PWAFeaturesProps {
  forceMobileView?: boolean;
  onHapticFeedback?: (type: 'light' | 'medium' | 'heavy') => void;
  enableInstallBanner?: boolean;
  enableOfflineIndicator?: boolean;
  enablePerformanceMetrics?: boolean;
  isDeveloperMode?: boolean;
}

interface PerformanceMetrics {
  bundleSize: number;
  largestContentfulPaint: number;
  cumulativeLayoutShift: number;
  isOptimizing: boolean;
}

export const PWAFeatures = memo<PWAFeaturesProps>(({
  forceMobileView = false,
  onHapticFeedback,
  enableInstallBanner = true,
  enableOfflineIndicator = true,
  enablePerformanceMetrics = false,
  isDeveloperMode = false
}) => {
  const [showInstallBanner, setShowInstallBanner] = useState(false);
  const [performanceMetrics, setPerformanceMetrics] = useState<PerformanceMetrics | null>(null);

  const { 
    isOnline, 
    isInstallable, 
    installApp,
    showNotification
  } = usePWA({
    enableOfflineMode: true,
    enablePushNotifications: true,
    enableBackgroundSync: true,
    enableInstallPrompt: true,
    cacheStrategy: 'stale-while-revalidate'
  });

  const handleHapticFeedback = useCallback((type: 'light' | 'medium' | 'heavy') => {
    onHapticFeedback?.(type);
  }, [onHapticFeedback]);

  const handleInstallApp = useCallback(() => {
    installApp();
    handleHapticFeedback('medium');
    setShowInstallBanner(false);
    
    showNotification('App Installed!', {
      body: 'Networking BudE is now available on your home screen',
      icon: '/icon-192x192.png'
    });
  }, [installApp, handleHapticFeedback, showNotification]);

  // Show install banner when PWA is installable
  useEffect(() => {
    if (enableInstallBanner) {
      setShowInstallBanner(isInstallable);
    }
  }, [isInstallable, enableInstallBanner]);

  // Mock performance metrics for development (in a real app, these would come from actual measurements)
  useEffect(() => {
    if (enablePerformanceMetrics && isDeveloperMode) {
      // Simulate getting performance metrics
      const updateMetrics = () => {
        setPerformanceMetrics({
          bundleSize: 720 * 1024, // 720KB
          largestContentfulPaint: 800, // 800ms
          cumulativeLayoutShift: 0.03,
          isOptimizing: Math.random() > 0.8 // Randomly show optimizing state
        });
      };

      updateMetrics();
      const interval = setInterval(updateMetrics, 5000);

      return () => clearInterval(interval);
    }
  }, [enablePerformanceMetrics, isDeveloperMode]);

  return (
    <>
      {/* PWA Installation Banner */}
      {enableInstallBanner && showInstallBanner && !forceMobileView && (
        <div className="fixed bottom-4 left-4 right-4 md:left-auto md:w-80 bg-primary text-primary-foreground p-4 rounded-lg shadow-lg z-50">
          <div className="flex items-start space-x-3">
            <div className="text-2xl">📱</div>
            <div className="flex-1">
              <h3 className="font-medium mb-1">Install Networking BudE</h3>
              <p className="text-sm opacity-90 mb-3">
                Get the full app experience with offline access and notifications
              </p>
              <div className="flex space-x-2">
                <button
                  onClick={handleInstallApp}
                  className="bg-white text-primary px-3 py-1.5 rounded text-sm font-medium hover:bg-gray-100 transition-colors"
                >
                  Install
                </button>
                <button
                  onClick={() => setShowInstallBanner(false)}
                  className="text-primary-foreground/80 hover:text-primary-foreground px-3 py-1.5 text-sm transition-colors"
                >
                  Later
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Offline Status Indicator */}
      {enableOfflineIndicator && !isOnline && (
        <div className="fixed top-16 left-1/2 transform -translate-x-1/2 bg-orange-600 text-white px-4 py-2 rounded-lg shadow-lg z-50 animate-in slide-in-from-top">
          <div className="flex items-center space-x-2 text-sm">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse" aria-hidden="true"></div>
            <span>You're offline - changes will sync when reconnected</span>
          </div>
        </div>
      )}
      
      {/* Performance Metrics (Development Only) */}
      {enablePerformanceMetrics && isDeveloperMode && performanceMetrics && (
        <div className="fixed bottom-4 left-4 bg-black/90 text-white p-3 rounded-lg text-xs font-mono z-50 max-w-xs">
          <div className="mb-2 font-bold">⚡ Performance Metrics</div>
          <div>Bundle: {(performanceMetrics.bundleSize / 1024).toFixed(1)}KB</div>
          <div>LCP: {performanceMetrics.largestContentfulPaint.toFixed(0)}ms</div>
          <div>CLS: {performanceMetrics.cumulativeLayoutShift.toFixed(3)}</div>
          {performanceMetrics.isOptimizing && (
            <div className="text-yellow-400 mt-1">🔄 Analyzing...</div>
          )}
        </div>
      )}
    </>
  );
});

PWAFeatures.displayName = 'PWAFeatures';