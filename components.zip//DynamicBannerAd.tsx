import React, { useEffect, memo, useRef } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { ExternalLink, RotateCcw } from 'lucide-react';
import { useBannerAds, BannerAd } from '../hooks/useBannerAds';
import { ImageWithFallback } from './figma/ImageWithFallback';
import budePlusFavicon from 'figma:asset/4c851da8b9f1d17e66ebdf644bf3b311a0b5bef8.png';
import budeFavicon from 'figma:asset/ae84c71c2e47b0ec7988c21ec262430a2ea0c320.png';

interface DynamicBannerAdProps {
  page: 'dashboard' | 'events' | 'connections' | 'all';
  showRotateButton?: boolean;
  className?: string;
  isAdminMode?: boolean;
}

// Individual banner ad component
const BannerAdDisplay = memo(({ 
  ad, 
  onView, 
  onClick, 
  showRotateButton, 
  onRotate,
  isAdminMode
}: {
  ad: BannerAd;
  onView: (id: string) => void;
  onClick: (id: string) => void;
  showRotateButton?: boolean;
  onRotate?: () => void;
  isAdminMode?: boolean;
}) => {
  const viewedRef = useRef<Set<string>>(new Set());
  
  useEffect(() => {
    // Record view when banner is displayed (only once per ad.id per session)
    if (!viewedRef.current.has(ad.id)) {
      const timeout = setTimeout(() => {
        onView(ad.id);
        viewedRef.current.add(ad.id);
      }, 100);
      
      return () => clearTimeout(timeout);
    }
  }, [ad.id]); // Remove onView dependency to prevent re-execution

  const handleClick = () => {
    onClick(ad.id);
    
    // Open internal links in same tab, external in new tab
    if (ad.ctaUrl.startsWith('/') || ad.ctaUrl.includes(window.location.hostname)) {
      window.location.href = ad.ctaUrl;
    } else {
      window.open(ad.ctaUrl, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <Card className="overflow-hidden bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 border-2 hover:shadow-lg transition-all duration-300 group">
      <div className="relative">
        {/* Admin mode indicator */}
        {isAdminMode && (
          <div className="absolute top-2 left-2 z-20">
            <div className="bg-purple-600 text-white px-2 py-1 rounded text-xs font-medium">
              Banner ID: {ad.id}
            </div>
          </div>
        )}
        
        {/* Rotate button */}
        {showRotateButton && onRotate && (
          <div className="absolute top-2 right-2 z-20">
            <Button
              variant="secondary"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                onRotate();
              }}
              className="bg-white/90 hover:bg-white shadow-md"
              title="Rotate to next ad"
            >
              <RotateCcw className="h-4 w-4" />
            </Button>
          </div>
        )}
        
        <div className="p-4 space-y-4">
          {/* Sample Banner Ad Label */}
          <div className="text-center">
            <span className="text-xs text-muted-foreground bg-background/80 px-2 py-1 rounded-full border">
              Sample Banner Ad
            </span>
          </div>
          
          {/* Banner Image - Full width in vertical layout */}
          <div className="w-full h-32 rounded-lg overflow-hidden bg-muted">
            <ImageWithFallback
              src={ad.id === '2' ? budePlusFavicon : (ad.id === '5' || ad.id === '10' || ad.id === '11') ? budeFavicon : ad.imageUrl}
              alt={ad.title}
              className={`w-full h-full ${(ad.id === '2' || ad.id === '5' || ad.id === '10' || ad.id === '11') ? 'object-contain p-2' : 'object-cover'} group-hover:scale-105 transition-transform duration-300`}
            />
          </div>
          
          {/* Content - Vertical layout for better sidebar fit */}
          <div className="text-center space-y-2">
            <h3 className="text-base font-semibold text-foreground group-hover:text-primary transition-colors leading-tight">
              {ad.title}
            </h3>
            {ad.subtitle && (
              <p className="text-sm text-muted-foreground leading-snug">
                {ad.subtitle}
              </p>
            )}
            
            {/* Admin analytics preview */}
            {isAdminMode && (
              <div className="grid grid-cols-2 gap-1 text-xs text-muted-foreground mt-2">
                <span className="bg-white/70 px-2 py-1 rounded text-center">Views: {ad.analytics.views}</span>
                <span className="bg-white/70 px-2 py-1 rounded text-center">Clicks: {ad.analytics.clicks}</span>
                <span className="bg-white/70 px-2 py-1 rounded text-center col-span-2">CTR: {ad.analytics.ctr.toFixed(1)}% • Priority: {ad.priority}</span>
              </div>
            )}
          </div>
          
          {/* CTA Button - Full width for better touch target */}
          <div className="w-full">
            <Button 
              onClick={handleClick}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-4 py-2 rounded-lg font-medium transition-all duration-200 transform hover:scale-105 shadow-lg text-sm"
            >
              {ad.ctaText}
              <ExternalLink className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
});

BannerAdDisplay.displayName = 'BannerAdDisplay';

// Main dynamic banner component
export const DynamicBannerAd = memo(({ 
  page, 
  showRotateButton = false, 
  className = '',
  isAdminMode = false
}: DynamicBannerAdProps) => {
  const {
    getCurrentBannerAd,
    rotateToNextAd,
    recordBannerView,
    recordBannerClick,
    getActiveBannerAds
  } = useBannerAds();

  const currentAd = getCurrentBannerAd(page);
  const activeAds = getActiveBannerAds(page);

  // Don't render if no active ads
  if (!currentAd || activeAds.length === 0) {
    return null;
  }

  const handleRotate = () => {
    rotateToNextAd(page);
  };

  return (
    <div className={`banner-ad-container ${className}`}>
      <BannerAdDisplay
        ad={currentAd}
        onView={recordBannerView}
        onClick={recordBannerClick}
        showRotateButton={showRotateButton && activeAds.length > 1}
        onRotate={handleRotate}
        isAdminMode={isAdminMode}
      />
      
      {/* Admin info panel */}
      {isAdminMode && (
        <div className="mt-2 p-2 bg-purple-50 dark:bg-purple-950/20 rounded text-xs text-muted-foreground">
          <div className="flex justify-between items-center">
            <span>Banner: {currentAd.name}</span>
            <span>{activeAds.length} active ad{activeAds.length !== 1 ? 's' : ''} on {page} page</span>
          </div>
          {activeAds.length > 1 && (
            <div className="mt-1 text-center">
              <span>Rotation available • {currentAd.targetPages.includes('all') ? 'Shown on all pages' : `Shown on: ${currentAd.targetPages.join(', ')}`}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
});

DynamicBannerAd.displayName = 'DynamicBannerAd';

// Helper component for manual banner rotation triggers
export const BannerRotationTrigger = memo(({ 
  page, 
  children 
}: { 
  page: 'dashboard' | 'events' | 'connections' | 'all';
  children: React.ReactNode;
}) => {
  const { rotateToNextAd, getActiveBannerAds } = useBannerAds();
  const activeAds = getActiveBannerAds(page);

  if (activeAds.length <= 1) {
    return <>{children}</>;
  }

  return (
    <div onClick={() => rotateToNextAd(page)}>
      {children}
    </div>
  );
});

BannerRotationTrigger.displayName = 'BannerRotationTrigger';

export default DynamicBannerAd;