import { NavLink, useLocation } from 'react-router-dom';
import { 
  Home, 
  Calendar, 
  Heart, 
  MessageCircle, 
  User, 
  Settings,
  CreditCard,
  Archive,
  LogOut
} from 'lucide-react';
import { Button } from './ui/button';
import { useState } from 'react';
// import { toast } from 'sonner@2.0.3';
// import budeLogo from 'figma:asset/3e43a07a7faa73f2f417a9074a180615c3828a87.png';

const primaryNavigation = [
  { name: 'Dashboard', href: '/dashboard', icon: Home },
  { name: 'Events', href: '/events', icon: Calendar },
  { name: 'Connections', href: '/connections', icon: Heart },
  { name: 'Messages', href: '/messenger', icon: MessageCircle },
  { name: 'Profile', href: '/profile/me', icon: User },
];

const secondaryNavigation = [
  { name: 'Settings', href: '/settings', icon: Settings },
  { name: 'Payment Portal', href: '/payment-portal', icon: CreditCard },
  { name: 'Content Archive', href: '/content-archive', icon: Archive },
];

interface SidebarProps {
  onLogout: () => void;
  userData: any;
}

export function Sidebar({ onLogout, userData }: SidebarProps) {
  const location = useLocation();
  const [isCollapsed, setIsCollapsed] = useState(false);

  const handleLogout = () => {
    console.log('Successfully logged out!');
    // toast.success('Successfully logged out!');
    onLogout();
  };

  return (
    // Desktop only sidebar - hidden on mobile/tablet
    <div className={`
      hidden md:flex fixed inset-y-0 left-0 z-40 bg-card border-r transition-all duration-300 ease-in-out flex-col
      ${isCollapsed ? 'w-16' : 'w-64'}
    `}>
      {/* Logo */}
      <div className="flex flex-col items-center px-6 py-4 border-b">
        <div className="h-20 w-20 bg-bude-green rounded-full flex items-center justify-center text-white font-bold text-xl">
          NB
        </div>
        {!isCollapsed && (
          <h1 className="text-lg font-semibold mt-2">Networking BudE</h1>
        )}
      </div>

      {/* Primary Navigation */}
      <nav className="flex-1 px-4 py-6 space-y-2">
        <div className="space-y-1">
          {primaryNavigation.map((item) => {
            const isActive = location.pathname === item.href || 
              (item.href === '/profile/me' && location.pathname.startsWith('/profile/'));
            return (
              <NavLink
                key={item.name}
                to={item.href}
                className={`
                  flex items-center px-3 py-2 rounded-lg group relative
                  ${isActive 
                    ? 'bg-bude-green-dark text-white hover:bg-bude-green-dark/90 shadow-sm border-3 border-bude-yellow' 
                    : 'text-muted-foreground hover:text-foreground hover:bg-accent transition-colors duration-150'
                  }
                `}
                title={isCollapsed ? item.name : undefined}
              >
                <item.icon className="h-5 w-5 flex-shrink-0" />
                {!isCollapsed && <span className="ml-3">{item.name}</span>}
              </NavLink>
            );
          })}
        </div>

        {/* Secondary Navigation */}
        {!isCollapsed && (
          <>
            <div className="pt-6">
              <h3 className="px-3 text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">
                Account
              </h3>
              <div className="space-y-1">
                {secondaryNavigation.map((item) => {
                  const isActive = location.pathname === item.href;
                  return (
                    <NavLink
                      key={item.name}
                      to={item.href}
                      className={`
                        flex items-center px-3 py-2 rounded-lg relative
                        ${isActive 
                          ? 'bg-bude-green-dark text-white hover:bg-bude-green-dark/90 shadow-sm border-3 border-bude-yellow' 
                          : 'text-muted-foreground hover:text-foreground hover:bg-accent transition-colors duration-150'
                        }
                      `}
                    >
                      <item.icon className="h-5 w-5 mr-3" />
                      {item.name}
                    </NavLink>
                  );
                })}
              </div>
            </div>
          </>
        )}
      </nav>

      {/* User info and controls */}
      <div className="px-4 py-4 border-t">
        {!isCollapsed && (
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
              <User className="h-5 w-5 text-primary-foreground" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium truncate">
                {userData?.name || 
                 (userData?.firstName && userData?.lastName ? `${userData.firstName} ${userData.lastName}` : '') ||
                 userData?.firstName || 
                 userData?.lastName || 
                 'User'}
              </p>
              <p className="text-sm text-muted-foreground truncate">
                {userData?.jobTitle || userData?.title || 'Professional'}
              </p>
            </div>
          </div>
        )}
        
        {/* Controls */}
        <div className="flex gap-2">
          {!isCollapsed ? (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="flex-1 justify-start text-muted-foreground hover:text-foreground hover:bg-accent"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          ) : (
            <Button
              variant="ghost"
              size="icon"
              onClick={handleLogout}
              className="w-full text-muted-foreground hover:text-foreground hover:bg-accent"
              title="Logout"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}