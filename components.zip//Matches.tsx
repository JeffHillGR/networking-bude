import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Heart, 
  X, 
  MessageCircle, 
  User, 
  MapPin, 
  Building, 
  Star,
  Users,
  Briefcase,
  Clock,
  UserPlus
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { toast } from 'sonner@2.0.3';
import { useConnectionAccess, useSubscription } from '../hooks/useSubscription';
import { UpgradePrompt } from './UpgradePrompt';
import { SuggestConnection } from './SuggestConnection';
import { DynamicBannerAd } from './DynamicBannerAd';

const RECOMMENDED_USERS = [
  {
    id: 1,
    name: 'Alex Chen',
    title: 'Senior Software Engineer',
    company: 'Google',
    location: 'San Francisco, CA',
    bio: 'Passionate about building scalable systems and leading engineering teams. Always interested in discussing the latest in cloud architecture and AI applications.',
    interests: ['Technology', 'AI/ML', 'Leadership', 'Startup'],
    commonInterests: ['Technology', 'AI/ML'],
    connectionScore: 95,
    avatar: 'AC',
    image: 'https://images.unsplash.com/photo-1746105625407-5d49d69a2a47?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBhc2lhbiUyMG1hbiUyMGhlYWRzaG90JTIwYnJpZ2h0JTIwbGlnaHRpbmclMjBidXNpbmVzcyUyMHBvcnRyYWl0fGVufDF8fHx8MTc1ODA1NDkyMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    experience: '8 years',
    education: 'Stanford University',
    isNew: true
  },
  {
    id: 2,
    name: 'Maria Rodriguez',
    title: 'Marketing Director',
    company: 'Spotify',
    location: 'Los Angeles, CA',
    bio: 'Creative marketing professional with expertise in digital campaigns and brand strategy. Love connecting with fellow marketers and entrepreneurs.',
    interests: ['Marketing', 'Media', 'Design', 'Music'],
    commonInterests: ['Marketing', 'Media'],
    connectionScore: 88,
    avatar: 'MR',
    image: 'https://images.unsplash.com/photo-1608875848903-06eec0bd71e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBsYXRpbmElMjB3b21hbiUyMGhlYWRzaG90JTIwYnVzaW5lc3N8ZW58MXx8fHwxNzU4MDUxNjYzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    experience: '10 years',
    education: 'UCLA',
    isNew: false
  },
  {
    id: 3,
    name: 'David Kim',
    title: 'Product Director',
    company: 'Meta',
    location: 'Menlo Park, CA',
    bio: 'Product leader focused on user experience and data-driven decision making. Interested in networking with other PMs and startup founders.',
    interests: ['Design', 'Data Science', 'Startup', 'Leadership'],
    commonInterests: ['Design', 'Leadership'],
    connectionScore: 92,
    avatar: 'DK',
    image: 'https://images.unsplash.com/photo-1755053757704-c5f9a09b7c8d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBrb3JlYW4lMjBtYW4lMjBoZWFkc2hvdCUyMGJ1c2luZXNzJTIwYnJpZ2h0JTIwc3R1ZGlvJTIwbGlnaHRpbmd8ZW58MXx8fHwxNzU4MDU0OTIzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    experience: '6 years',
    education: 'UC Berkeley',
    isNew: true
  },
  {
    id: 4,
    name: 'Jennifer Walsh',
    title: 'VP of Sales',
    company: 'Salesforce',
    location: 'San Francisco, CA',
    bio: 'Sales leader with a track record of building high-performing teams. Always looking to share insights and learn from other sales professionals.',
    interests: ['Sales', 'Leadership', 'Consulting', 'SaaS'],
    commonInterests: ['Sales', 'Leadership'],
    connectionScore: 85,
    avatar: 'JW',
    image: 'https://images.unsplash.com/photo-1652471949169-9c587e8898cd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBibGFjayUyMHdvbWFuJTIwaGVhZHNob3QlMjBidXNpbmVzc3xlbnwxfHx8fDE3NTgwNTE2NzN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    experience: '12 years',
    education: 'Northwestern',
    isNew: false
  }
];

const CONNECTED_USERS = [
  {
    id: 5,
    name: 'Sarah Thompson',
    title: 'UX Designer',
    company: 'Adobe',
    location: 'San Jose, CA',
    interests: ['Design', 'Technology', 'Art'],
    commonInterests: ['Design', 'Technology'],
    connectionScore: 90,
    avatar: 'ST',
    image: 'https://images.unsplash.com/photo-1740153204804-200310378f2f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBhc2lhbiUyMHdvbWFuJTIwaGVhZHNob3QlMjBidXNpbmVzc3xlbnwxfHx8fDE3NTgwNTE2NjN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    connectedDate: '2025-09-15',
    lastMessage: 'Looking forward to our coffee chat!',
    unreadCount: 2
  },
  {
    id: 6,
    name: 'Michael Brown',
    title: 'Data Scientist',
    company: 'Netflix',
    location: 'Los Gatos, CA',
    interests: ['Data Science', 'AI/ML', 'Statistics'],
    commonInterests: ['Data Science', 'AI/ML'],
    connectionScore: 87,
    avatar: 'MB',
    image: 'https://images.unsplash.com/photo-1633351577919-8b1567c1579e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBtaWRkbGUlMjBlYXN0ZXJuJTIwbWFuJTIwaGVhZHNob3QlMjBidXNpbmVzc3xlbnwxfHx8fDE3NTgwNTE2NzN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    connectedDate: '2025-09-12',
    lastMessage: 'Thanks for the ML resources!',
    unreadCount: 0
  },
  {
    id: 7,
    name: 'Lisa Wang',
    title: 'Startup Founder',
    company: 'HealthTech Solutions',
    location: 'Palo Alto, CA',
    interests: ['Startup', 'Healthcare', 'Leadership'],
    commonInterests: ['Startup', 'Leadership'],
    connectionScore: 93,
    avatar: 'LW',
    image: 'https://images.unsplash.com/photo-1704927768421-bc9549b5097d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBpbmRpYW4lMjB3b21hbiUyMGhlYWRzaG90JTIwYnVzaW5lc3N8ZW58MXx8fHwxNzU4MDUxNjczfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    connectedDate: '2025-09-10',
    lastMessage: 'Would love to discuss your product strategy...',
    unreadCount: 1
  }
];

export function Matches() {
  const [recommendedUsers, setRecommendedUsers] = useState(RECOMMENDED_USERS);
  const [currentRecommendationIndex, setCurrentRecommendationIndex] = useState(0);
  const [showUpgradePrompt, setShowUpgradePrompt] = useState(false);
  const [showSuggestDialog, setShowSuggestDialog] = useState(false);
  const [selectedUserToSuggest, setSelectedUserToSuggest] = useState<typeof CONNECTED_USERS[0] | null>(null);
  
  // Subscription hooks with enhanced debugging
  const { canConnect, requireConnectionUpgrade } = useConnectionAccess();
  const { isAdminBypass } = useSubscription();

  // Debug logging for development
  if (process.env.NODE_ENV === 'development') {
    console.log('🔍 Matches Component Debug:', {
      canConnect: canConnect(),
      isAdminBypass,
      showUpgradePrompt
    });
  }

  // Block all functionality for free users (but allow developer mode)
  if (!canConnect() && !isAdminBypass) {
    return (
      <div className="p-4 md:p-6 space-y-4 md:space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl md:text-3xl mb-2">Connections</h1>
          <p className="text-muted-foreground text-sm md:text-base">
            Discover and connect with professionals who share your interests
          </p>
        </div>

        {/* Premium Required Message */}
        <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-6">
            <Users className="h-8 w-8 text-primary" />
          </div>
          <h2 className="text-xl font-semibold mb-3">Premium Feature Required</h2>
          <p className="text-muted-foreground mb-6 max-w-md">
            Connect with professionals and discover meaningful networking opportunities. 
            Upgrade to unlock all connection features.
          </p>
          <Button 
            onClick={() => setShowUpgradePrompt(true)}
            className="bg-primary hover:bg-primary/90"
          >
            Upgrade to Premium - $9.99/month
          </Button>
        </div>

        {/* Upgrade Prompt Modal */}
        <UpgradePrompt
          isOpen={showUpgradePrompt}
          onClose={() => setShowUpgradePrompt(false)}
          feature="connections"
          context="to connect with other professionals"
        />
      </div>
    );
  }

  const handleLike = (userId: number) => {
    if (!canConnect()) {
      setShowUpgradePrompt(true);
      return;
    }
    
    setRecommendedUsers(prev => prev.filter(user => user.id !== userId));
    setCurrentRecommendationIndex(prev => 
      prev >= recommendedUsers.length - 1 ? 0 : prev
    );
    toast.success('Connection request sent! 🤝');
  };

  const handlePass = (userId: number) => {
    setRecommendedUsers(prev => prev.filter(user => user.id !== userId));
    setCurrentRecommendationIndex(prev => 
      prev >= recommendedUsers.length - 1 ? 0 : prev
    );
  };

  const handleMaybe = (userId: number) => {
    setRecommendedUsers(prev => prev.filter(user => user.id !== userId));
    setCurrentRecommendationIndex(prev => 
      prev >= recommendedUsers.length - 1 ? 0 : prev
    );
    toast.success('Saved for later! 🤔');
  };

  const handleSuggestConnection = (user: typeof CONNECTED_USERS[0]) => {
    setSelectedUserToSuggest(user);
    setShowSuggestDialog(true);
  };

  // Get available connections for suggestions (exclude the selected user)
  const getAvailableConnectionsForSuggestion = (excludeUserId: number) => {
    return CONNECTED_USERS.filter(user => user.id !== excludeUserId);
  };

  const currentUser = recommendedUsers[currentRecommendationIndex];

  return (
    <div className="p-4 md:p-6 space-y-4 md:space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl md:text-3xl mb-2">Connections</h1>
        <p className="text-muted-foreground text-sm md:text-base">
          Discover and connect with professionals who share your interests
        </p>
      </div>

      <Tabs defaultValue="recommended" className="space-y-4 md:space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="recommended">Recommended</TabsTrigger>
          <TabsTrigger value="matched">
            Current BudE's ({CONNECTED_USERS.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="recommended" className="space-y-4 md:space-y-6">
          {recommendedUsers.length > 0 ? (
            <div>
              <h2 className="text-lg md:text-xl mb-4">Recommended Connections</h2>
              <div className="space-y-3 md:space-y-4">
                {recommendedUsers.map((user) => (
                  <Card key={user.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-3 md:p-4">
                      <div className="flex items-start space-x-3 md:space-x-4">
                        <div className="relative flex-shrink-0">
                          <Avatar className="w-10 h-10 md:w-12 md:h-12">
                            <AvatarImage src={user.image} alt={user.name} />
                            <AvatarFallback className="text-sm">{user.avatar}</AvatarFallback>
                          </Avatar>
                          {user.isNew && (
                            <div className="absolute -top-1 -right-1 w-2.5 h-2.5 md:w-3 md:h-3 bg-green-500 rounded-full"></div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0 space-y-2">
                          <div className="flex items-start justify-between">
                            <div className="min-w-0 flex-1">
                              <h4 className="font-medium truncate text-sm md:text-base">{user.name}</h4>
                              <p className="text-xs md:text-sm text-muted-foreground truncate">{user.title} at {user.company}</p>
                            </div>
                            <div className="flex items-center space-x-1 flex-shrink-0 ml-2">
                              <Star className="h-3 w-3 text-yellow-500" />
                              <span className="text-xs text-muted-foreground">{user.connectionScore}%</span>
                            </div>
                          </div>
                          
                          <div className="flex flex-wrap gap-1">
                            {user.commonInterests.slice(0, 2).map((interest) => (
                              <Badge key={interest} variant="outline" className="text-xs px-2 py-0.5">
                                {interest}
                              </Badge>
                            ))}
                            {user.commonInterests.length > 2 && (
                              <Badge variant="outline" className="text-xs px-2 py-0.5">
                                +{user.commonInterests.length - 2}
                              </Badge>
                            )}
                          </div>
                          
                          {/* Mobile-Optimized Button Layout */}
                          <div className="flex gap-1.5">
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="flex-1 px-2 py-2 text-xs h-8 min-w-0 justify-center"
                              onClick={() => handlePass(user.id)}
                              title="No thanks"
                            >
                              <X className="h-3 w-3 flex-shrink-0 md:mr-1" />
                              <span className="hidden md:inline text-xs">No thanks</span>
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="flex-1 border-blue-200 text-blue-600 hover:bg-blue-50 px-2 py-2 text-xs h-8 min-w-0 justify-center"
                              onClick={() => handleMaybe(user.id)}
                              title="Perhaps"
                            >
                              <Clock className="h-3 w-3 flex-shrink-0 md:mr-1" />
                              <span className="hidden md:inline text-xs">Perhaps</span>
                            </Button>
                            <Button 
                              size="sm"
                              className="flex-1 bg-bude-green-dark text-white hover:bg-bude-green-dark/90 border-3 border-bude-yellow px-2 py-2 text-xs h-8 min-w-0 justify-center"
                              onClick={() => handleLike(user.id)}
                              title="Connect"
                            >
                              <Heart className="h-3 w-3 flex-shrink-0 md:mr-1" />
                              <span className="hidden md:inline text-xs">Connect</span>
                            </Button>
                            <Link to={`/profile/${user.id}`}>
                              <Button variant="ghost" size="sm" className="px-2 py-2 h-8 min-w-0 flex-shrink-0 justify-center" title="View Profile">
                                <User className="h-3 w-3" />
                              </Button>
                            </Link>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ) : (
            <Card>
              <CardContent className="p-8 md:p-12 text-center">
                <Users className="h-10 w-10 md:h-12 md:w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="font-semibold mb-2 text-sm md:text-base">No more recommendations</h3>
                <p className="text-muted-foreground text-xs md:text-sm">
                  You've seen all current recommendations. Check back later for new connections!
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="matched" className="space-y-4 md:space-y-6">
          <div>
            <h2 className="text-lg md:text-xl mb-4"></h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
              {CONNECTED_USERS.map((user) => (
                <Card key={user.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-3 md:p-4">
                    <div className="text-center space-y-2 md:space-y-3">
                      <div className="relative mx-auto w-fit">
                        <Avatar className="w-12 h-12 md:w-16 md:h-16">
                          <AvatarImage src={user.image} alt={user.name} />
                          <AvatarFallback className="text-sm md:text-lg">{user.avatar}</AvatarFallback>
                        </Avatar>
                        {user.unreadCount > 0 && (
                          <div className="absolute -top-1 -right-1 w-4 h-4 md:w-5 md:h-5 bg-primary rounded-full flex items-center justify-center text-xs text-primary-foreground">
                            {user.unreadCount}
                          </div>
                        )}
                      </div>
                      
                      <div>
                        <h4 className="font-medium text-sm md:text-base">{user.name}</h4>
                        <p className="text-xs md:text-sm text-muted-foreground">{user.title}</p>
                        <p className="text-xs md:text-sm text-muted-foreground">{user.company}</p>
                      </div>

                      <div className="flex items-center justify-center space-x-1">
                        <Star className="h-3 w-3 text-yellow-500" />
                        <span className="text-xs md:text-sm text-muted-foreground">{user.connectionScore}% connection</span>
                      </div>

                      <div className="flex flex-wrap justify-center gap-1">
                        {user.commonInterests.map((interest) => (
                          <Badge key={interest} variant="outline" className="text-xs px-2 py-0.5">
                            {interest}
                          </Badge>
                        ))}
                      </div>

                      {user.lastMessage && (
                        <div className="text-xs text-muted-foreground text-center border-t pt-2">
                          <p className="truncate">"{user.lastMessage}"</p>
                        </div>
                      )}

                      <div className="flex gap-1.5">
                        <Link to={`/messenger/${user.id}`} className="flex-1">
                          <Button variant="outline" size="sm" className="w-full text-xs h-auto py-1.5">
                            <MessageCircle className="h-3 w-3 mr-1" />
                            Message
                          </Button>
                        </Link>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="text-xs h-auto py-1.5 px-2 border-blue-200 text-blue-600 hover:bg-blue-50"
                          onClick={() => handleSuggestConnection(user)}
                          title="Suggest to other BudE users"
                        >
                          <UserPlus className="h-3 w-3 mr-1" />
                          <span className="hidden sm:inline">Suggest</span>
                        </Button>
                        <Link to={`/profile/${user.id}`}>
                          <Button variant="ghost" size="sm" className="h-auto py-1.5 px-2">
                            <User className="h-3 w-3" />
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {CONNECTED_USERS.length === 0 && (
              <Card>
                <CardContent className="p-8 md:p-12 text-center">
                  <Heart className="h-10 w-10 md:h-12 md:w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-semibold mb-2 text-sm md:text-base">No connections yet</h3>
                  <p className="text-muted-foreground text-xs md:text-sm">
                    Start liking profiles in the Recommended tab to find your first connection!
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Upgrade Prompt Modal */}
      <UpgradePrompt
        isOpen={showUpgradePrompt}
        onClose={() => setShowUpgradePrompt(false)}
        feature="connections"
        context="to connect with other professionals"
      />

      {/* Suggest Connection Modal */}
      {selectedUserToSuggest && (
        <SuggestConnection
          isOpen={showSuggestDialog}
          onClose={() => {
            setShowSuggestDialog(false);
            setSelectedUserToSuggest(null);
          }}
          suggestedUser={selectedUserToSuggest}
          availableConnections={getAvailableConnectionsForSuggestion(selectedUserToSuggest.id)}
        />
      )}
    </div>
  );
}