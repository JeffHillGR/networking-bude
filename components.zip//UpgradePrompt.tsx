import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { useNavigate } from 'react-router-dom';
import { 
  Check, 
  X, 
  Star, 
  Users, 
  Calendar, 
  MessageCircle, 
  Shield,
  Zap
} from 'lucide-react';

interface UpgradePromptProps {
  isOpen: boolean;
  onClose: () => void;
  feature?: string;
  context?: string;
}

export function UpgradePrompt({ isOpen, onClose, feature, context }: UpgradePromptProps) {
  const navigate = useNavigate();
  const [isClosing, setIsClosing] = useState(false);

  const handleUpgrade = () => {
    setIsClosing(true);
    navigate('/payment-portal');
    onClose();
  };

  const handleClose = () => {
    setIsClosing(true);
    setTimeout(() => {
      onClose();
      setIsClosing(false);
    }, 200);
  };

  const getFeatureContext = () => {
    switch (feature) {
      case 'events':
        return {
          title: 'Event Access',
          description: 'Access full event details, RSVP, and connect with attendees'
        };
      case 'connections':
        return {
          title: 'Professional Connections',
          description: 'Connect with other professionals and expand your network'
        };
      case 'messaging':
        return {
          title: 'Messaging',
          description: 'Send and receive messages with your professional connections'
        };
      default:
        return {
          title: 'Premium Features',
          description: 'Access all premium networking features'
        };
    }
  };

  const featureContext = getFeatureContext();

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className={`max-w-2xl ${isClosing ? 'opacity-50' : ''}`}>
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2 text-xl">
            <Star className="h-6 w-6 text-yellow-500" />
            <span>Upgrade to Premium</span>
          </DialogTitle>
          <DialogDescription>
            {context ? context : `Unlock ${featureContext.title.toLowerCase()} and all premium features`}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Feature highlight */}
          <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                {feature === 'events' && <Calendar className="h-5 w-5 text-primary" />}
                {feature === 'connections' && <Users className="h-5 w-5 text-primary" />}
                {feature === 'messaging' && <MessageCircle className="h-5 w-5 text-primary" />}
                {!feature && <Zap className="h-5 w-5 text-primary" />}
              </div>
              <div>
                <h3 className="font-medium">{featureContext.title}</h3>
                <p className="text-sm text-muted-foreground">{featureContext.description}</p>
              </div>
            </div>
          </div>

          {/* Pricing */}
          <Card className="border-primary/20">
            <CardHeader className="text-center pb-4">
              <CardTitle className="flex items-center justify-center space-x-2">
                <span>Networking BudE Premium</span>
                <Badge variant="default" className="bg-green-600">Most Popular</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <div className="text-3xl font-bold">$9.99</div>
                <div className="text-muted-foreground">per month</div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Check className="h-4 w-4 text-green-600" />
                  <span className="text-sm">Unlimited professional connections</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Check className="h-4 w-4 text-green-600" />
                  <span className="text-sm">Access to all local events</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Check className="h-4 w-4 text-green-600" />
                  <span className="text-sm">Direct messaging with connections</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Check className="h-4 w-4 text-green-600" />
                  <span className="text-sm">Advanced search and filtering</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Check className="h-4 w-4 text-green-600" />
                  <span className="text-sm">Priority customer support</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Shield className="h-4 w-4 text-green-600" />
                  <span className="text-sm">Verified professional badge</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Preview vs Premium comparison */}
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="font-medium mb-2 text-muted-foreground">Preview Mode</h4>
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <X className="h-3 w-3 text-red-500" />
                  <span className="text-muted-foreground">Limited browsing only</span>
                </div>
                <div className="flex items-center space-x-2">
                  <X className="h-3 w-3 text-red-500" />
                  <span className="text-muted-foreground">No connections</span>
                </div>
                <div className="flex items-center space-x-2">
                  <X className="h-3 w-3 text-red-500" />
                  <span className="text-muted-foreground">No messaging</span>
                </div>
                <div className="flex items-center space-x-2">
                  <X className="h-3 w-3 text-red-500" />
                  <span className="text-muted-foreground">No event access</span>
                </div>
              </div>
            </div>
            <div>
              <h4 className="font-medium mb-2 text-primary">Premium</h4>
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <Check className="h-3 w-3 text-green-600" />
                  <span>Full app access</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-3 w-3 text-green-600" />
                  <span>Unlimited connections</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-3 w-3 text-green-600" />
                  <span>Messaging & events</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-3 w-3 text-green-600" />
                  <span>Priority support</span>
                </div>
              </div>
            </div>
          </div>

          {/* Call to action */}
          <div className="flex space-x-3">
            <Button variant="outline" onClick={handleClose} className="flex-1">
              Continue Preview
            </Button>
            <Button onClick={handleUpgrade} className="flex-1 bg-green-600 hover:bg-green-700">
              Upgrade Now - $9.99/month
            </Button>
          </div>

          <p className="text-xs text-muted-foreground text-center">
            Cancel anytime. Terms and conditions apply.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}