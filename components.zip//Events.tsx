import { useState, useEffect, useMemo, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Textarea } from './ui/textarea';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  Users, 
  Search, 
  Filter,
  Star,
  ExternalLink,
  Plus,
  Send
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { Link } from 'react-router-dom';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { EventSkeleton, ListSkeleton } from './LoadingSkeleton';
import { useMobileOptimizations } from '../hooks/useMobileOptimizations';
import { useAccessibility } from '../hooks/useAccessibility';
import { usePerformance } from '../hooks/usePerformance';
import { useEventAccess } from '../hooks/useSubscription';
import { UpgradePrompt } from './UpgradePrompt';
import { DynamicBannerAd } from './DynamicBannerAd';
import eventsBanner from 'figma:asset/bedbf83afb3c300489a4b4f0b1b7a97a29d64d9b.png';

const EVENTS = [
  {
    id: 1,
    title: 'Creative Mornings Design Session',
    description: 'Inspiring morning session with local designers and creative professionals. Coffee and networking included.',
    date: '2025-09-20',
    time: '8:00 AM - 10:00 AM',
    location: 'Bamboo Grand Rapids',
    address: 'Downtown Grand Rapids, MI',
    attendees: 45,
    maxAttendees: 60,
    type: 'In-Person',
    category: 'Creative',
    price: 0,
    image: 'https://images.unsplash.com/photo-1571645163064-77faa9676a46?w=400&h=300&fit=crop',
    organizer: 'Creative Mornings GR',
    featured: true
  },
  {
    id: 2,
    title: 'BNI Weekly Business Exchange',
    description: 'Structured referral networking meeting focused on business development. Members only.',
    date: '2025-09-22',
    time: '7:00 AM - 8:30 AM',
    location: 'GR Chamber of Commerce',
    address: '111 Pearl St NW, Grand Rapids, MI',
    attendees: 35,
    maxAttendees: 40,
    type: 'In-Person',
    category: 'Business Referrals',
    price: 0,
    image: 'https://images.unsplash.com/photo-1556742044-3c52d6e88c62?w=400&h=300&fit=crop',
    organizer: 'BNI',
    featured: false
  },
  {
    id: 3,
    title: 'StartGarden Entrepreneur Pitch',
    description: 'Local startups pitch to investors while networking with entrepreneurs and VCs.',
    date: '2025-09-25',
    time: '6:30 PM - 9:00 PM',
    location: 'StartGarden',
    address: '123 Ionia Ave SW, Grand Rapids, MI',
    attendees: 80,
    maxAttendees: 100,
    type: 'In-Person',
    category: 'Startup',
    price: 15,
    image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=400&h=300&fit=crop',
    organizer: 'StartGarden',
    featured: true
  },
  {
    id: 4,
    title: 'Athena Leadership Workshop',
    description: 'Empowering professional women through networking, mentorship, and skill development.',
    date: '2025-09-28',
    time: '9:00 AM - 5:00 PM',
    location: 'Grand Rapids Art Museum',
    address: '101 Monroe Center St NW, Grand Rapids, MI',
    attendees: 150,
    maxAttendees: 200,
    type: 'In-Person',
    category: 'Leadership',
    price: 75,
    image: 'https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?w=400&h=300&fit=crop',
    organizer: 'Athena',
    featured: true
  },
  {
    id: 5,
    title: 'Tech Council Innovation Mixer',
    description: 'Connect with West Michigan tech leaders and engineers in a casual networking environment.',
    date: '2025-10-02',
    time: '5:30 PM - 8:00 PM',
    location: 'The Factory',
    address: '19 E Fulton St, Grand Rapids, MI',
    attendees: 65,
    maxAttendees: 80,
    type: 'In-Person',
    category: 'Technology',
    price: 20,
    image: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=400&h=300&fit=crop',
    organizer: 'Tech Council',
    featured: false
  },
  {
    id: 6,
    title: 'Hello West Michigan Coffee Chat',
    description: 'Monthly virtual networking connecting West Michigan professionals across industries.',
    date: '2025-10-05',
    time: '12:00 PM - 1:00 PM',
    location: 'Zoom',
    address: 'Online Event',
    attendees: 95,
    maxAttendees: 150,
    type: 'Virtual',
    category: 'General Networking',
    price: 0,
    image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400&h=300&fit=crop',
    organizer: 'Hello West Michigan',
    featured: false
  },
  {
    id: 7,
    title: 'Economics Club Policy Breakfast',
    description: 'Regional business leaders discuss economic policy and its impact on West Michigan.',
    date: '2025-10-08',
    time: '8:00 AM - 9:30 AM',
    location: 'DeVos Place',
    address: '303 Monroe Ave NW, Grand Rapids, MI',
    attendees: 120,
    maxAttendees: 150,
    type: 'In-Person',
    category: 'Economics',
    price: 45,
    image: 'https://images.unsplash.com/photo-1634326080825-985cfc816db6?w=400&h=300&fit=crop',
    organizer: 'Economics Club',
    featured: false
  },
  {
    id: 8,
    title: 'PRSA Communications Workshop',
    description: 'Professional development covering digital marketing trends and strategic communications.',
    date: '2025-10-12',
    time: '6:00 PM - 8:00 PM',
    location: 'Aquinas College',
    address: '1700 Fulton St E, Grand Rapids, MI',
    attendees: 40,
    maxAttendees: 60,
    type: 'In-Person',
    category: 'Marketing',
    price: 30,
    image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=300&fit=crop',
    organizer: 'PRSA',
    featured: false
  }
];

export function Events() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterOrganization, setFilterOrganization] = useState('all');
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitDialogOpen, setIsSubmitDialogOpen] = useState(false);
  const [submitMessage, setSubmitMessage] = useState('');
  const [showUpgradePrompt, setShowUpgradePrompt] = useState(false);

  // Optimization and subscription hooks
  const { canAccessEvent, requireEventUpgrade } = useEventAccess();
  const { measureRoute, logMetric } = usePerformance({
    enableLogging: process.env.NODE_ENV === 'development',
    enableAnalytics: process.env.NODE_ENV === 'production',
    sampleRate: 0.1
  });
  const { triggerHapticFeedback } = useMobileOptimizations({
    enableHapticFeedback: true,
    enablePullToRefresh: false,
    pullToRefreshThreshold: 100
  });
  const { announceToScreenReader, manageFocus } = useAccessibility({
    enableKeyboardNavigation: true,
    enableFocusManagement: true,
    enableScreenReaderSupport: true
  });

  // Enhanced page initialization with performance tracking
  useEffect(() => {
    const stopMeasuring = measureRoute('events-page');
    
    // Simulate data loading
    const loadEvents = async () => {
      try {
        // Announce page load to screen readers
        announceToScreenReader('Events page loaded. Use search and filters to find networking events.');
        
        // Scroll to top of page
        window.scrollTo({ top: 0, behavior: 'smooth' });
        
        // Simulate loading time for realistic performance
        await new Promise(resolve => setTimeout(resolve, 300));
        
        setIsLoading(false);
        logMetric('Events data loaded', performance.now());
        
      } catch (error) {
        console.error('Failed to load events:', error);
        announceToScreenReader('Error loading events. Please try again.', 'assertive');
      } finally {
        stopMeasuring();
      }
    };
    
    loadEvents();
  }, [measureRoute, logMetric, announceToScreenReader]);

  // Optimized filtering with memoization
  const filteredEvents = useMemo(() => {
    return EVENTS.filter(event => {
      const matchesSearch = event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           event.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesType = filterType === 'all' || event.type.toLowerCase() === filterType;
      const matchesCategory = filterCategory === 'all' || event.category.toLowerCase() === filterCategory;
      const matchesOrganization = filterOrganization === 'all' || event.organizer.toLowerCase() === filterOrganization.toLowerCase();
      
      return matchesSearch && matchesType && matchesCategory && matchesOrganization;
    });
  }, [searchTerm, filterType, filterCategory, filterOrganization]);

  // Memoized organization list
  const uniqueOrganizations = useMemo(() => {
    return [...new Set(EVENTS.map(event => event.organizer))].sort();
  }, []);

  // Memoized event categorization
  const { featuredEvents, regularEvents } = useMemo(() => {
    const featured = filteredEvents.filter(event => event.featured);
    const regular = filteredEvents.filter(event => !event.featured);
    return { featuredEvents: featured, regularEvents: regular };
  }, [filteredEvents]);

  // Enhanced search handler with debouncing and haptic feedback
  const handleSearchChange = useCallback((value: string) => {
    setSearchTerm(value);
    triggerHapticFeedback('light');
    
    if (value.length > 0) {
      announceToScreenReader(`Searching for events containing: ${value}`);
    }
  }, [triggerHapticFeedback, announceToScreenReader]);

  // Enhanced filter handlers
  const handleFilterChange = useCallback((filterName: string, value: string) => {
    triggerHapticFeedback('light');
    
    switch (filterName) {
      case 'type':
        setFilterType(value);
        announceToScreenReader(`Filter changed to ${value === 'all' ? 'all event types' : value + ' events'}`);
        break;
      case 'category':
        setFilterCategory(value);
        announceToScreenReader(`Filter changed to ${value === 'all' ? 'all categories' : value + ' category'}`);
        break;
      case 'organization':
        setFilterOrganization(value);
        announceToScreenReader(`Filter changed to ${value === 'all' ? 'all organizations' : value + ' events'}`);
        break;
    }
  }, [triggerHapticFeedback, announceToScreenReader]);

  // Handle event submission
  const handleSubmitEvent = useCallback(() => {
    if (!submitMessage.trim()) {
      toast.error('Please enter a message before submitting');
      return;
    }

    // Simulate sending message to admin
    triggerHapticFeedback('medium');
    announceToScreenReader('Event suggestion submitted successfully');
    
    toast.success('Event suggestion sent to admin! We\'ll review your recommendation and get back to you.');
    
    // Reset form and close dialog
    setSubmitMessage('');
    setIsSubmitDialogOpen(false);
  }, [submitMessage, triggerHapticFeedback, announceToScreenReader]);

  // Handle event detail clicks
  const handleEventDetailsClick = useCallback((e: React.MouseEvent, eventId: number) => {
    if (!canAccessEvent(eventId.toString())) {
      e.preventDefault();
      requireEventUpgrade();
      return;
    }
  }, [canAccessEvent, requireEventUpgrade]);

  // Show loading skeleton while data loads
  if (isLoading) {
    return (
      <div className="space-y-6 p-6" role="main" aria-label="Loading events">
        <div className="h-32 md:h-40 bg-muted rounded-lg animate-pulse shimmer"></div>
        <div className="h-24 bg-muted rounded-lg animate-pulse shimmer"></div>
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <EventSkeleton key={i} />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6" role="main" aria-label="Events page">
      {/* Events Banner with enhanced accessibility */}
      <div className="relative h-32 md:h-40 rounded-lg overflow-hidden mb-6">
        <img 
          src={eventsBanner} 
          alt="Professional networking conference with business people connecting and collaborating"
          className="w-full h-full object-cover"
          loading="eager"
          role="img"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
        <div className="absolute bottom-4 left-6 right-6 text-white">
          <h1 className="text-lg md:text-xl mb-1 flex items-center space-x-2">
            <Calendar className="h-4 w-4" aria-hidden="true" />
            <span>Discover. Connect. Grow.</span>
          </h1>
          <p className="text-xs md:text-sm opacity-90">
            Join professionals at meaningful networking events
          </p>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Search and Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col gap-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Search events..."
                  value={searchTerm}
                  onChange={(e) => handleSearchChange(e.target.value)}
                  className="pl-9"
                  aria-label="Search networking events"
                  role="searchbox"
                />
              </div>
              <Select value={filterType} onValueChange={(value) => handleFilterChange('type', value)}>
                <SelectTrigger className="w-full md:w-40" aria-label="Filter by event type">
                  <SelectValue placeholder="Event Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="in-person">In-Person</SelectItem>
                  <SelectItem value="virtual">Virtual</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterCategory} onValueChange={(value) => handleFilterChange('category', value)}>
                <SelectTrigger className="w-full md:w-40" aria-label="Filter by category">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="technology">Technology</SelectItem>
                  <SelectItem value="startup">Startup</SelectItem>
                  <SelectItem value="leadership">Leadership</SelectItem>
                  <SelectItem value="product management">Product Management</SelectItem>
                  <SelectItem value="ai/ml">AI/ML</SelectItem>
                  <SelectItem value="remote work">Remote Work</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col md:flex-row gap-4">
              <Select value={filterOrganization} onValueChange={(value) => handleFilterChange('organization', value)}>
                <SelectTrigger className="w-full md:w-64" aria-label="Filter by organization">
                  <SelectValue placeholder="Search by Organization" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Organizations</SelectItem>
                  {uniqueOrganizations.map((org) => (
                    <SelectItem key={org} value={org}>
                      {org}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Featured Events */}
      {featuredEvents.length > 0 && (
        <div>
          <h2 className="text-xl mb-4 flex items-center">
            <Star className="h-5 w-5 text-yellow-500 mr-2" />
            Featured Events
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {featuredEvents.map((event) => (
              <Card key={event.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-video relative overflow-hidden">
                  <img 
                    src={event.image} 
                    alt={event.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 left-4">
                    <Badge variant={event.type === 'Virtual' ? 'secondary' : 'default'}>
                      {event.type}
                    </Badge>
                  </div>
                  {event.price === 0 && (
                    <div className="absolute top-4 right-4">
                      <Badge variant="outline" className="bg-white">Free</Badge>
                    </div>
                  )}
                </div>
                <CardHeader className="pb-4">
                  <CardTitle className="line-clamp-2 mb-2">{event.title}</CardTitle>
                  <CardDescription className="line-clamp-2">
                    {event.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm text-muted-foreground mb-4">
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4" />
                      <span>{new Date(event.date).toLocaleDateString()} • {event.time}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <MapPin className="h-4 w-4" />
                      <span>{event.location}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Users className="h-4 w-4" />
                      <span>{event.attendees}/{event.maxAttendees} attending</span>
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pt-2">
                    <div className="flex-shrink-0">
                      {event.price > 0 ? (
                        <span className="font-semibold">${event.price}</span>
                      ) : (
                        <span className="font-semibold text-green-600">Free</span>
                      )}
                    </div>
                    <Link to={`/events/${event.id}`} className="flex-shrink-0" onClick={(e) => handleEventDetailsClick(e, event.id)}>
                      <Button size="sm" className="w-full sm:w-auto">View Details</Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
            
            {/* Sponsored Event - 4th Featured Event Container */}
            <Card className="overflow-hidden hover:shadow-lg transition-shadow relative border-2 border-yellow-200 dark:border-yellow-800">
              {/* Sponsored Badge */}
              <div className="absolute top-4 left-4 z-10">
                <Badge className="bg-yellow-500 text-black font-medium">
                  Sponsored
                </Badge>
              </div>
              <div className="aspect-video relative overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=400&h=300&fit=crop" 
                  alt="West Michigan Manufacturing Network Industry Connect"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 right-4">
                  <Badge variant="default">
                    In-Person
                  </Badge>
                </div>
                <div className="absolute bottom-4 right-4">
                  <Badge variant="outline" className="bg-white">$25</Badge>
                </div>
              </div>
              <CardHeader className="pb-4">
                <CardTitle className="line-clamp-2 mb-2">West Michigan Manufacturing Network Industry Connect</CardTitle>
                <CardDescription className="line-clamp-2">
                  Exclusive networking event connecting manufacturing professionals across West Michigan. Tours, demonstrations, and strategic partnerships.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4" />
                    <span>October 15, 2025 • 2:00 PM - 6:00 PM</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-4 w-4" />
                    <span>DeVos Place Convention Center</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Users className="h-4 w-4" />
                    <span>127/200 attending</span>
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pt-2">
                  <div className="flex items-center space-x-3">
                    <span className="text-sm text-muted-foreground">by West Michigan Manufacturing Association</span>
                    <span className="font-semibold">$25</span>
                  </div>
                  <Link to="/events/sponsored-manufacturing" className="flex-shrink-0" onClick={(e) => handleEventDetailsClick(e, 999)}>
                    <Button size="sm" className="w-full sm:w-auto bg-yellow-600 hover:bg-yellow-700">
                      View Details
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Submit Events to BudE Button */}
      <div className="flex justify-center">
        <Dialog open={isSubmitDialogOpen} onOpenChange={setIsSubmitDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              className="flex items-center space-x-2 bg-yellow-500 hover:bg-yellow-600 text-black transition-colors"
              onClick={() => triggerHapticFeedback('light')}
            >
              <Plus className="h-4 w-4" />
              <span>Submit Events to BudE</span>
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Suggest an Event</DialogTitle>
              <DialogDescription>
                Know of a great networking event in Grand Rapids? Send us your suggestion and we'll consider adding it to our platform.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <Textarea
                placeholder="Tell us about the networking event you'd like us to add and include details like the event name, organization, location and contact info and we'll review it!"
                value={submitMessage}
                onChange={(e) => setSubmitMessage(e.target.value)}
                className="min-h-[120px] resize-none"
                aria-label="Event suggestion message"
              />
              <div className="flex space-x-3">
                <Button 
                  onClick={handleSubmitEvent}
                  className="flex-1 flex items-center justify-center space-x-2"
                  disabled={!submitMessage.trim()}
                >
                  <Send className="h-4 w-4" />
                  <span>Send Suggestion</span>
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setIsSubmitDialogOpen(false);
                    setSubmitMessage('');
                  }}
                >
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* All Events and Banner Ads */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* All Events - Takes up 3 columns */}
        <div className="lg:col-span-3">
          <h2 className="text-xl mb-4">
            {featuredEvents.length > 0 ? 'More Events' : 'All Events'}
          </h2>
          <div className="space-y-4">
            {regularEvents.map((event) => (
              <Card key={event.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {/* Header with title, badges, and image */}
                    <div className="flex flex-col sm:flex-row sm:items-start gap-4">
                      <div className="w-full sm:w-32 h-24 sm:h-20 rounded-lg overflow-hidden flex-shrink-0">
                        <img 
                          src={event.image} 
                          alt={event.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 space-y-2">
                        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2">
                          <h3 className="font-semibold text-lg">{event.title}</h3>
                          <div className="flex space-x-2 flex-shrink-0">
                            <Badge variant={event.type === 'Virtual' ? 'secondary' : 'default'}>
                              {event.type}
                            </Badge>
                            {event.price === 0 && (
                              <Badge variant="outline">Free</Badge>
                            )}
                          </div>
                        </div>
                        <p className="text-muted-foreground line-clamp-2">{event.description}</p>
                      </div>
                    </div>
                    
                    {/* Event details */}
                    <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted-foreground">
                      <div className="flex items-center space-x-1">
                        <Calendar className="h-4 w-4" />
                        <span>{new Date(event.date).toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="h-4 w-4" />
                        <span>{event.time}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <MapPin className="h-4 w-4" />
                        <span>{event.location}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Users className="h-4 w-4" />
                        <span>{event.attendees} attending</span>
                      </div>
                    </div>
                    
                    {/* Bottom row with organizer, price, and button */}
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pt-2 border-t border-border/50">
                      <div className="flex items-center space-x-3">
                        <span className="text-sm text-muted-foreground">by {event.organizer}</span>
                        {event.price > 0 && (
                          <span className="font-semibold">${event.price}</span>
                        )}
                      </div>
                      <Link to={`/events/${event.id}`} onClick={(e) => handleEventDetailsClick(e, event.id)}>
                        <Button size="sm" variant="outline">View Details</Button>
                      </Link>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
        
        {/* Sidebar Banner Ads - Takes up 1 column */}
        <div className="lg:col-span-1">
          <div className="sticky top-6 space-y-6">
            {/* First Sidebar Ad */}
            <div>
              <DynamicBannerAd 
                page="events" 
                showRotateButton={true}
                className="w-full"
              />
            </div>
            
            {/* Second Sidebar Ad */}
            <div>
              <DynamicBannerAd 
                page="events" 
                showRotateButton={true}
                className="w-full"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Banner Ad */}
      <div className="mt-8">
        <DynamicBannerAd 
          page="events" 
          showRotateButton={false}
          className="w-full"
        />
      </div>
      </div>
    </div>
  );
}