import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { 
  CreditCard, 
  ArrowLeft, 
  Plus, 
  Trash2, 
  Shield, 
  CheckCircle,
  Calendar,
  Lock,
  Crown,
  Star,
  Zap,
  Download,
  Receipt,
  Settings,
  Users,
  BarChart3,
  Sparkles,
  X,
  Tag,
  Edit,
  Copy,
  Eye,
  EyeOff,
  Percent,
  DollarSign
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { TermsAndConditions } from './TermsAndConditions';
import { useSubscription } from '../hooks/useSubscription';
import { PromoCodeAdminTab } from './PaymentPortalPromoCodeAdmin';
import { BannerAdAdmin } from './BannerAdAdmin';
import budeFavicon from 'figma:asset/ae84c71c2e47b0ec7988c21ec262430a2ea0c320.png';
import budePlusFavicon from 'figma:asset/4c851da8b9f1d17e66ebdf644bf3b311a0b5bef8.png';

interface PaymentMethod {
  id: string;
  type: 'visa' | 'mastercard' | 'amex' | 'discover';
  last4: string;
  expiryMonth: string;
  expiryYear: string;
  isDefault: boolean;
  holderName: string;
}

interface SubscriptionPlan {
  id: string;
  name: string;
  description: string;
  price: number;
  yearlyPrice?: number;
  features: string[];
  popular?: boolean;
  enterprise?: boolean;
  icon: React.ComponentType<{ className?: string }>;
  limits: {
    connections: string;
    events: string;
    messaging: string;
    analytics: boolean;
    support: string;
  };
}

interface BillingHistory {
  id: string;
  date: string;
  amount: number;
  description: string;
  status: 'paid' | 'pending' | 'failed';
  invoiceUrl?: string;
  plan: string;
}

interface UserSubscription {
  planId: string;
  status: 'active' | 'canceled' | 'past_due' | 'trialing';
  currentPeriodStart: string;
  currentPeriodEnd: string;
  cancelAtPeriodEnd: boolean;
  isYearly: boolean;
  trialEnd?: string;
}

interface PromoCode {
  id: string;
  code: string;
  discountType: 'percentage' | 'dollar';
  discountValue: number;
  description: string;
  expirationDate?: string;
  usageLimit?: number;
  usedCount: number;
  isActive: boolean;
  createdDate: string;
  applicablePlans?: string[]; // specific plans this promo applies to
  minimumAmount?: number; // minimum order amount for promo to apply
}

interface PromoCodeFormData {
  code: string;
  discountType: 'percentage' | 'dollar';
  discountValue: number;
  description: string;
  expirationDate: string;
  usageLimit: number;
  isActive: boolean;
  applicablePlans: string[];
  minimumAmount: number;
}

// Subscription Plans Configuration
const SUBSCRIPTION_PLANS: SubscriptionPlan[] = [
  {
    id: 'free',
    name: 'Free',
    description: 'Perfect for getting started with networking',
    price: 0,
    icon: Users,
    features: [
      'Dashboard preview',
      'Connections preview',
      'Events preview',
      'Profile creation'
    ],
    limits: {
      connections: 'Preview only',
      events: 'Preview only',
      messaging: 'Basic',
      analytics: false,
      support: 'Community'
    }
  },
  {
    id: 'professional',
    name: 'BudE Plan',
    description: 'For active networkers building meaningful connections',
    price: 9.99,
    yearlyPrice: 99.99,
    popular: true,
    icon: Star,
    features: [
      'Unlimited connections',
      'Unlimited event access',
      'Connection insights and analytics',
      'Messaging between BudE\'s',
      'Event notifications (weekly)',
      'New content notifications (weekly)',
      'Profile verification'
    ],
    limits: {
      connections: 'Unlimited',
      events: 'Unlimited',
      messaging: 'Advanced',
      analytics: true,
      support: 'Email'
    }
  },
  {
    id: 'enterprise',
    name: 'BudE+',
    description: 'Premium networking with exclusive perks and groups',
    price: 19.99,
    yearlyPrice: 199.00,
    enterprise: true,
    icon: Crown,
    features: [
      'Everything in BudE Plan',
      'Discounts on banner ads',
      'Ability to create BudE groups of networking connections',
      'Access to BudE merchandise including BudE lapel pins to wear to events'
    ],
    limits: {
      connections: 'Unlimited',
      events: 'Unlimited + Groups',
      messaging: 'Advanced + Groups',
      analytics: true,
      support: 'Priority'
    }
  }
];

const mockPaymentMethods: PaymentMethod[] = [
  {
    id: '1',
    type: 'visa',
    last4: '4242',
    expiryMonth: '12',
    expiryYear: '2026',
    isDefault: true,
    holderName: 'Sarah Johnson'
  },
  {
    id: '2',
    type: 'mastercard',
    last4: '8888',
    expiryMonth: '09',
    expiryYear: '2025',
    isDefault: false,
    holderName: 'Sarah Johnson'
  }
];

const mockBillingHistory: BillingHistory[] = [
  {
    id: 'inv_001',
    date: '2025-01-15',
    amount: 9.99,
    description: 'BudE Plan - Monthly',
    status: 'paid',
    invoiceUrl: '#',
    plan: 'BudE Plan'
  },
  {
    id: 'inv_002',
    date: '2024-12-15',
    amount: 9.99,
    description: 'BudE Plan - Monthly',
    status: 'paid',
    invoiceUrl: '#',
    plan: 'BudE Plan'
  },
  {
    id: 'inv_003',
    date: '2024-11-15',
    amount: 9.99,
    description: 'BudE Plan - Monthly',
    status: 'paid',
    invoiceUrl: '#',
    plan: 'BudE Plan'
  },
  {
    id: 'inv_004',
    date: '2024-10-15',
    amount: 0,
    description: 'BudE Plan - Free Trial',
    status: 'paid',
    invoiceUrl: '#',
    plan: 'BudE Plan Trial'
  }
];

const mockUserSubscription: UserSubscription = {
  planId: 'free',
  status: 'active',
  currentPeriodStart: '2025-01-15',
  currentPeriodEnd: '2025-02-15',
  cancelAtPeriodEnd: false,
  isYearly: false
};

// Mock promo codes data - in real app this would come from backend
const INITIAL_PROMO_CODES: PromoCode[] = [
  {
    id: '1',
    code: 'WELCOME20',
    discountType: 'percentage',
    discountValue: 20,
    description: '20% off first 3 months',
    expirationDate: '2025-12-31',
    usageLimit: 1000,
    usedCount: 47,
    isActive: true,
    createdDate: '2025-01-01',
    applicablePlans: ['professional', 'enterprise'],
    minimumAmount: 0
  },
  {
    id: '2',
    code: 'STUDENT50',
    discountType: 'percentage',
    discountValue: 50,
    description: '50% off for students',
    expirationDate: '2025-08-31',
    usageLimit: 500,
    usedCount: 123,
    isActive: true,
    createdDate: '2025-01-15',
    applicablePlans: ['professional'],
    minimumAmount: 0
  },
  {
    id: '3',
    code: 'ANNUAL25',
    discountType: 'percentage',
    discountValue: 25,
    description: '25% off annual subscription',
    expirationDate: '2025-06-30',
    usageLimit: 200,
    usedCount: 89,
    isActive: true,
    createdDate: '2025-02-01',
    applicablePlans: ['professional', 'enterprise'],
    minimumAmount: 99
  },
  {
    id: '4',
    code: 'FRIEND15',
    discountType: 'percentage',
    discountValue: 15,
    description: '15% off referral discount',
    usageLimit: 0, // unlimited
    usedCount: 234,
    isActive: true,
    createdDate: '2025-01-01',
    applicablePlans: ['professional', 'enterprise'],
    minimumAmount: 0
  },
  {
    id: '5',
    code: 'SAVE5',
    discountType: 'dollar',
    discountValue: 5,
    description: '$5 off any subscription',
    expirationDate: '2025-04-30',
    usageLimit: 100,
    usedCount: 23,
    isActive: true,
    createdDate: '2025-03-01',
    applicablePlans: ['professional', 'enterprise'],
    minimumAmount: 9.99
  }
];

export function PaymentPortal() {
  const navigate = useNavigate();
  const { subscription, acceptTerms, activateSubscription } = useSubscription();
  const [activeTab, setActiveTab] = useState('plans'); // Start on plans tab
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>(mockPaymentMethods);
  const [showAddForm, setShowAddForm] = useState(false);
  const [promoCode, setPromoCode] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<PromoCode | null>(null);
  const [billingHistory] = useState<BillingHistory[]>(mockBillingHistory);
  const [currentSubscription, setCurrentSubscription] = useState<UserSubscription>(mockUserSubscription);
  const [isYearlyBilling, setIsYearlyBilling] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [showTerms, setShowTerms] = useState(false);
  const [pendingPlanId, setPendingPlanId] = useState<string | null>(null);
  const [newCard, setNewCard] = useState({
    cardNumber: '',
    expiryMonth: '',
    expiryYear: '',
    cvv: '',
    holderName: '',
    isDefault: false
  });

  // Admin Promo Code Management State
  const [promoCodes, setPromoCodes] = useState<PromoCode[]>(INITIAL_PROMO_CODES);
  const [showPromoForm, setShowPromoForm] = useState(false);
  const [editingPromo, setEditingPromo] = useState<PromoCode | null>(null);
  const [isAdminMode, setIsAdminMode] = useState(false); // Toggle for admin features
  const [promoFormData, setPromoFormData] = useState<PromoCodeFormData>({
    code: '',
    discountType: 'percentage',
    discountValue: 0,
    description: '',
    expirationDate: '',
    usageLimit: 0,
    isActive: true,
    applicablePlans: [],
    minimumAmount: 0
  });

  const getCardIcon = (type: string) => {
    const icons = {
      visa: '💳',
      mastercard: '💳',
      amex: '💳',
      discover: '💳'
    };
    return icons[type as keyof typeof icons] || '💳';
  };

  const getCardType = (cardNumber: string): 'visa' | 'mastercard' | 'amex' | 'discover' => {
    if (cardNumber.startsWith('4')) return 'visa';
    if (cardNumber.startsWith('5') || cardNumber.startsWith('2')) return 'mastercard';
    if (cardNumber.startsWith('3')) return 'amex';
    if (cardNumber.startsWith('6')) return 'discover';
    return 'visa';
  };

  const formatCardNumber = (value: string) => {
    // Remove all non-digits
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    // Limit to 16 digits
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    if (parts.length) {
      return parts.join(' ');
    } else {
      return v;
    }
  };

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCardNumber(e.target.value);
    setNewCard(prev => ({ ...prev, cardNumber: formatted }));
  };

  const handleAddCard = () => {
    if (!newCard.cardNumber || !newCard.expiryMonth || !newCard.expiryYear || !newCard.cvv || !newCard.holderName) {
      toast.error('Please fill in all required fields');
      return;
    }

    const cardNumber = newCard.cardNumber.replace(/\s/g, '');
    if (cardNumber.length < 13 || cardNumber.length > 19) {
      toast.error('Please enter a valid card number');
      return;
    }

    const newPaymentMethod: PaymentMethod = {
      id: Date.now().toString(),
      type: getCardType(cardNumber),
      last4: cardNumber.slice(-4),
      expiryMonth: newCard.expiryMonth,
      expiryYear: newCard.expiryYear,
      isDefault: newCard.isDefault,
      holderName: newCard.holderName
    };

    // If this is set as default, make all others non-default
    if (newCard.isDefault) {
      setPaymentMethods(prev => prev.map(pm => ({ ...pm, isDefault: false })));
    }

    setPaymentMethods(prev => [...prev, newPaymentMethod]);
    setNewCard({
      cardNumber: '',
      expiryMonth: '',
      expiryYear: '',
      cvv: '',
      holderName: '',
      isDefault: false
    });
    setShowAddForm(false);
    toast.success('Payment method added successfully!');
  };

  const handleSetDefault = (id: string) => {
    setPaymentMethods(prev => 
      prev.map(pm => ({ ...pm, isDefault: pm.id === id }))
    );
    toast.success('Default payment method updated!');
  };

  const handleRemoveCard = (id: string) => {
    const cardToRemove = paymentMethods.find(pm => pm.id === id);
    if (cardToRemove?.isDefault && paymentMethods.length > 1) {
      toast.error('Cannot remove the default payment method. Please set another card as default first.');
      return;
    }
    
    setPaymentMethods(prev => prev.filter(pm => pm.id !== id));
    toast.success('Payment method removed successfully!');
  };

  const handleApplyPromoCode = () => {
    const trimmedCode = promoCode.trim().toUpperCase();
    
    if (!trimmedCode) {
      toast.error('Please enter a promo code');
      return;
    }

    // Find the promo code in our database
    const validPromo = promoCodes.find(promo => 
      promo.code.toUpperCase() === trimmedCode && 
      promo.isActive
    );
    
    if (!validPromo) {
      toast.error('Invalid promo code. Please check and try again.');
      return;
    }

    // Check if promo code has expired
    if (validPromo.expirationDate) {
      const expirationDate = new Date(validPromo.expirationDate);
      const currentDate = new Date();
      if (currentDate > expirationDate) {
        toast.error('This promo code has expired.');
        return;
      }
    }

    // Check usage limit
    if (validPromo.usageLimit && validPromo.usageLimit > 0 && validPromo.usedCount >= validPromo.usageLimit) {
      toast.error('This promo code has reached its usage limit.');
      return;
    }

    // Check if plan is applicable
    if (validPromo.applicablePlans && validPromo.applicablePlans.length > 0) {
      if (!selectedPlan || !validPromo.applicablePlans.includes(selectedPlan)) {
        toast.error('This promo code is not applicable to the selected plan.');
        return;
      }
    }

    // Check minimum amount requirement
    const currentPlan = SUBSCRIPTION_PLANS.find(p => p.id === selectedPlan);
    if (currentPlan && validPromo.minimumAmount) {
      const planPrice = isYearlyBilling && currentPlan.yearlyPrice ? currentPlan.yearlyPrice : currentPlan.price;
      if (planPrice < validPromo.minimumAmount) {
        toast.error(`This promo code requires a minimum order of ${formatCurrency(validPromo.minimumAmount)}.`);
        return;
      }
    }

    setAppliedPromo(validPromo);
    toast.success(`Promo code applied! ${validPromo.description}`);
  };

  const handleRemovePromoCode = () => {
    setAppliedPromo(null);
    setPromoCode('');
    toast.success('Promo code removed');
  };

  const calculateDiscountedPrice = (basePrice: number) => {
    if (!appliedPromo) return basePrice;
    
    if (appliedPromo.discountType === 'percentage') {
      return basePrice * (1 - appliedPromo.discountValue / 100);
    } else {
      // Dollar amount discount
      return Math.max(0, basePrice - appliedPromo.discountValue);
    }
  };

  // Admin Promo Code Management Functions
  const handleCreatePromoCode = () => {
    // Validate form data
    if (!promoFormData.code.trim()) {
      toast.error('Please enter a promo code');
      return;
    }

    if (promoFormData.discountValue <= 0) {
      toast.error('Please enter a valid discount value');
      return;
    }

    if (promoFormData.discountType === 'percentage' && promoFormData.discountValue > 100) {
      toast.error('Percentage discount cannot exceed 100%');
      return;
    }

    if (!promoFormData.description.trim()) {
      toast.error('Please enter a description');
      return;
    }

    // Check if promo code already exists
    const existingPromo = promoCodes.find(promo => 
      promo.code.toUpperCase() === promoFormData.code.trim().toUpperCase()
    );

    if (existingPromo && !editingPromo) {
      toast.error('A promo code with this name already exists');
      return;
    }

    const newPromoCode: PromoCode = {
      id: editingPromo ? editingPromo.id : Date.now().toString(),
      code: promoFormData.code.trim().toUpperCase(),
      discountType: promoFormData.discountType,
      discountValue: promoFormData.discountValue,
      description: promoFormData.description.trim(),
      expirationDate: promoFormData.expirationDate || undefined,
      usageLimit: promoFormData.usageLimit || undefined,
      usedCount: editingPromo ? editingPromo.usedCount : 0,
      isActive: promoFormData.isActive,
      createdDate: editingPromo ? editingPromo.createdDate : new Date().toISOString().split('T')[0],
      applicablePlans: promoFormData.applicablePlans.length > 0 ? promoFormData.applicablePlans : undefined,
      minimumAmount: promoFormData.minimumAmount || undefined
    };

    if (editingPromo) {
      // Update existing promo code
      setPromoCodes(prev => prev.map(promo => 
        promo.id === editingPromo.id ? newPromoCode : promo
      ));
      toast.success('Promo code updated successfully!');
      setEditingPromo(null);
    } else {
      // Add new promo code
      setPromoCodes(prev => [...prev, newPromoCode]);
      toast.success('Promo code created successfully!');
    }

    // Reset form
    setPromoFormData({
      code: '',
      discountType: 'percentage',
      discountValue: 0,
      description: '',
      expirationDate: '',
      usageLimit: 0,
      isActive: true,
      applicablePlans: [],
      minimumAmount: 0
    });
    setShowPromoForm(false);
  };

  const handleEditPromoCode = (promo: PromoCode) => {
    setEditingPromo(promo);
    setPromoFormData({
      code: promo.code,
      discountType: promo.discountType,
      discountValue: promo.discountValue,
      description: promo.description,
      expirationDate: promo.expirationDate || '',
      usageLimit: promo.usageLimit || 0,
      isActive: promo.isActive,
      applicablePlans: promo.applicablePlans || [],
      minimumAmount: promo.minimumAmount || 0
    });
    setShowPromoForm(true);
  };

  const handleDeletePromoCode = (promoId: string) => {
    setPromoCodes(prev => prev.filter(promo => promo.id !== promoId));
    toast.success('Promo code deleted successfully!');
  };

  const handleTogglePromoStatus = (promoId: string) => {
    setPromoCodes(prev => prev.map(promo => 
      promo.id === promoId ? { ...promo, isActive: !promo.isActive } : promo
    ));
    const promo = promoCodes.find(p => p.id === promoId);
    toast.success(`Promo code ${promo?.isActive ? 'deactivated' : 'activated'} successfully!`);
  };

  const copyPromoCodeToClipboard = (code: string) => {
    navigator.clipboard.writeText(code);
    toast.success('Promo code copied to clipboard!');
  };

  const formatDiscountValue = (promo: PromoCode) => {
    if (promo.discountType === 'percentage') {
      return `${promo.discountValue}%`;
    } else {
      return formatCurrency(promo.discountValue);
    }
  };

  const getPromoCodeStatus = (promo: PromoCode) => {
    if (!promo.isActive) return 'inactive';
    
    if (promo.expirationDate) {
      const expirationDate = new Date(promo.expirationDate);
      const currentDate = new Date();
      if (currentDate > expirationDate) return 'expired';
    }

    if (promo.usageLimit && promo.usageLimit > 0 && promo.usedCount >= promo.usageLimit) {
      return 'limit-reached';
    }

    return 'active';
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'active': return 'default';
      case 'inactive': return 'secondary';
      case 'expired': return 'destructive';
      case 'limit-reached': return 'outline';
      default: return 'default';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active': return 'Active';
      case 'inactive': return 'Inactive';
      case 'expired': return 'Expired';
      case 'limit-reached': return 'Limit Reached';
      default: return 'Unknown';
    }
  };

  const getCurrentPlan = () => {
    return SUBSCRIPTION_PLANS.find(plan => plan.id === currentSubscription.planId) || SUBSCRIPTION_PLANS[0];
  };

  const handlePlanSelection = (planId: string) => {
    if (planId === currentSubscription.planId) return;
    setSelectedPlan(planId);
    setActiveTab('payment');
  };

  const handleSubscriptionUpgrade = async (planId: string) => {
    // Check if terms need to be accepted first
    if (!subscription.termsAccepted) {
      setPendingPlanId(planId);
      setShowTerms(true);
      return;
    }

    setIsProcessingPayment(true);
    
    try {
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock successful upgrade
      const newPlan = SUBSCRIPTION_PLANS.find(p => p.id === planId);
      if (newPlan) {
        // Use the subscription hook to activate the subscription
        const billingCycle = isYearlyBilling ? 'annual' : 'monthly';
        const price = isYearlyBilling && newPlan.yearlyPrice ? newPlan.yearlyPrice : newPlan.price;
        
        activateSubscription(newPlan.name, price, billingCycle);
        
        setCurrentSubscription(prev => ({
          ...prev,
          planId,
          isYearly: isYearlyBilling,
          status: 'active',
          currentPeriodStart: new Date().toISOString().split('T')[0],
          currentPeriodEnd: new Date(Date.now() + (isYearlyBilling ? 365 : 30) * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
        }));
        
        setSelectedPlan(null);
        setActiveTab('overview');
        
        // Navigate back to dashboard after successful upgrade
        setTimeout(() => {
          navigate('/dashboard');
        }, 2000);
      }
    } catch (error) {
      toast.error('Payment failed. Please try again.');
    } finally {
      setIsProcessingPayment(false);
    }
  };

  const handleTermsAccept = () => {
    acceptTerms();
    setShowTerms(false);
    
    // Continue with the subscription upgrade
    if (pendingPlanId) {
      handleSubscriptionUpgrade(pendingPlanId);
      setPendingPlanId(null);
    }
  };

  const handleTermsDecline = () => {
    setShowTerms(false);
    setPendingPlanId(null);
    toast.error('You must accept the Terms of Service to continue with your subscription');
  };

  const handleCancelSubscription = async () => {
    try {
      // Here you would call your API to cancel the subscription
      setCurrentSubscription(prev => ({
        ...prev,
        cancelAtPeriodEnd: true
      }));
      toast.success('Subscription will be canceled at the end of your billing period.');
    } catch (error) {
      toast.error('Failed to cancel subscription. Please contact support.');
    }
  };

  const handleReactivateSubscription = async () => {
    try {
      // Here you would call your API to reactivate the subscription
      setCurrentSubscription(prev => ({
        ...prev,
        cancelAtPeriodEnd: false
      }));
      toast.success('Subscription reactivated successfully!');
    } catch (error) {
      toast.error('Failed to reactivate subscription. Please contact support.');
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      active: { label: 'Active', variant: 'default' as const },
      canceled: { label: 'Canceled', variant: 'secondary' as const },
      past_due: { label: 'Past Due', variant: 'destructive' as const },
      trialing: { label: 'Trial', variant: 'outline' as const },
      paid: { label: 'Paid', variant: 'default' as const },
      pending: { label: 'Pending', variant: 'outline' as const },
      failed: { label: 'Failed', variant: 'destructive' as const }
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.active;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 20 }, (_, i) => currentYear + i);
  const months = Array.from({ length: 12 }, (_, i) => {
    const month = i + 1;
    return { value: month.toString().padStart(2, '0'), label: month.toString().padStart(2, '0') };
  });

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => navigate('/settings')}
          className="p-2"
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-3xl mb-2">Subscription & Billing</h1>
          <p className="text-muted-foreground">
            Manage your subscription, payment methods, and billing
          </p>
        </div>
      </div>

      {/* Subscription Status Alert */}
      {currentSubscription.cancelAtPeriodEnd && (
        <Card className="border-orange-200 bg-orange-50 dark:bg-orange-950 dark:border-orange-800">
          <CardContent className="pt-4">
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-3">
                <Calendar className="h-5 w-5 text-orange-600 dark:text-orange-400 mt-0.5" />
                <div>
                  <h4 className="font-medium text-orange-800 dark:text-orange-200">Subscription Ending</h4>
                  <p className="text-sm text-orange-600 dark:text-orange-300 mt-1">
                    Your subscription will end on {formatDate(currentSubscription.currentPeriodEnd)}. You'll lose access to premium features.
                  </p>
                </div>
              </div>
              <Button onClick={handleReactivateSubscription} size="sm" className="bg-orange-600 hover:bg-orange-700">
                Reactivate
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Security Notice */}
      <Card className="border-green-200 bg-green-50 dark:bg-green-950 dark:border-green-800">
        <CardContent className="pt-4">
          <div className="flex items-start space-x-3">
            <Shield className="h-5 w-5 text-green-600 dark:text-green-400 mt-0.5" />
            <div>
              <h4 className="font-medium text-green-800 dark:text-green-200">Enterprise-Grade Security</h4>
              <p className="text-sm text-green-600 dark:text-green-300 mt-1">
                Powered by Stripe. Your payment data is encrypted with bank-level security. We never store your card details.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Admin Toggle */}
      <Card className="border-purple-200 bg-purple-50 dark:bg-purple-950 dark:border-purple-800">
        <CardContent className="pt-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Settings className="h-5 w-5 text-purple-600 dark:text-purple-400" />
              <div>
                <h4 className="font-medium text-purple-800 dark:text-purple-200">Admin Mode</h4>
                <p className="text-sm text-purple-600 dark:text-purple-300">
                  Enable admin features including promo code management
                </p>
              </div>
            </div>
            <Button
              onClick={() => setIsAdminMode(!isAdminMode)}
              variant={isAdminMode ? "default" : "outline"}
              className={isAdminMode ? "bg-purple-600 hover:bg-purple-700" : ""}
            >
              {isAdminMode ? <EyeOff className="h-4 w-4 mr-2" /> : <Eye className="h-4 w-4 mr-2" />}
              {isAdminMode ? 'Disable Admin' : 'Enable Admin'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className={`grid w-full ${isAdminMode ? 'grid-cols-6' : 'grid-cols-4'}`}>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="plans">Plans</TabsTrigger>
          <TabsTrigger value="payment">Payment</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
          {isAdminMode && (
            <TabsTrigger value="promos" className="bg-purple-100 data-[state=active]:bg-purple-200">
              <Tag className="h-4 w-4 mr-2" />
              Promo Codes
            </TabsTrigger>
          )}
          {isAdminMode && (
            <TabsTrigger value="banners" className="bg-blue-100 data-[state=active]:bg-blue-200">
              <BarChart3 className="h-4 w-4 mr-2" />
              Banner Ads
            </TabsTrigger>
          )}
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          {/* Current Subscription */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                {React.createElement(getCurrentPlan().icon, { className: "h-5 w-5" })}
                <span>Current Subscription</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-lg">{getCurrentPlan().name} Plan</h3>
                  <p className="text-muted-foreground">{getCurrentPlan().description}</p>
                </div>
                {getStatusBadge(currentSubscription.status)}
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Next billing date:</span>
                    <span className="font-medium">{formatDate(currentSubscription.currentPeriodEnd)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Billing cycle:</span>
                    <span className="font-medium">{currentSubscription.isYearly ? 'Yearly' : 'Monthly'}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Amount:</span>
                    <span className="font-medium">
                      {formatCurrency(currentSubscription.isYearly && getCurrentPlan().yearlyPrice 
                        ? getCurrentPlan().yearlyPrice! 
                        : getCurrentPlan().price
                      )}
                      /{currentSubscription.isYearly ? 'year' : 'month'}
                    </span>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-medium">Usage This Month</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Connections</span>
                      <span>47/{getCurrentPlan().limits.connections}</span>
                    </div>
                    <Progress value={getCurrentPlan().id === 'free' ? 94 : 47} className="h-2" />
                    
                    <div className="flex justify-between text-sm">
                      <span>Events Attended</span>
                      <span>3/{getCurrentPlan().limits.events}</span>
                    </div>
                    <Progress value={getCurrentPlan().id === 'free' ? 100 : 15} className="h-2" />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="flex justify-between items-center">
                <div className="text-sm text-muted-foreground">
                  Want to change your plan or need help?
                </div>
                <div className="space-x-2">
                  {getCurrentPlan().id !== 'enterprise' && (
                    <Button onClick={() => setActiveTab('plans')}>
                      <Sparkles className="h-4 w-4 mr-2" />
                      Upgrade Plan
                    </Button>
                  )}
                  {getCurrentPlan().id !== 'free' && !currentSubscription.cancelAtPeriodEnd && (
                    <Button variant="outline" onClick={handleCancelSubscription}>
                      Cancel Subscription
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center space-x-2">
                  <Users className="h-8 w-8 text-blue-600" />
                  <div>
                    <p className="text-2xl font-semibold">147</p>
                    <p className="text-sm text-muted-foreground">Total Connections</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center space-x-2">
                  <Calendar className="h-8 w-8 text-green-600" />
                  <div>
                    <p className="text-2xl font-semibold">23</p>
                    <p className="text-sm text-muted-foreground">Events Attended</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center space-x-2">
                  <BarChart3 className="h-8 w-8 text-purple-600" />
                  <div>
                    <p className="text-2xl font-semibold">94%</p>
                    <p className="text-sm text-muted-foreground">Profile Strength</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Plans Tab */}
        <TabsContent value="plans" className="space-y-6">
          {/* Billing Selection */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-center space-x-2">
                <button
                  onClick={() => setIsYearlyBilling(false)}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    !isYearlyBilling 
                      ? 'bg-primary text-primary-foreground' 
                      : 'bg-muted text-muted-foreground hover:bg-muted/80'
                  }`}
                >
                  Monthly
                </button>
                <button
                  onClick={() => setIsYearlyBilling(true)}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2 ${
                    isYearlyBilling 
                      ? 'bg-primary text-primary-foreground' 
                      : 'bg-muted text-muted-foreground hover:bg-muted/80'
                  }`}
                >
                  <span>Yearly</span>
                  <Badge variant="secondary" className="bg-white text-primary">Save 17%</Badge>
                </button>
              </div>
            </CardContent>
          </Card>

          {/* Pricing Plans */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {SUBSCRIPTION_PLANS.map((plan) => {
              const isCurrentPlan = currentSubscription.planId === plan.id;
              const isFreePlan = plan.id === 'free';
              const isProfessionalPlan = plan.id === 'professional';
              const isUserOnFreePlan = currentSubscription.planId === 'free';
              
              // For free users: current plan gets border, $9.99 plan keeps "most popular"
              let cardBorderClass = '';
              let badgeContent = null;
              
              if (isUserOnFreePlan) {
                if (isCurrentPlan) {
                  // Free plan gets border when user is on free plan
                  cardBorderClass = 'border-primary shadow-md';
                } else if (isProfessionalPlan) {
                  // $9.99 plan keeps "most popular" border
                  cardBorderClass = 'border-primary shadow-md';
                  badgeContent = (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-primary text-primary-foreground">Most Popular</Badge>
                    </div>
                  );
                }
              } else {
                // For paid users, use original logic
                if (plan.popular) {
                  cardBorderClass = 'border-primary shadow-md';
                  badgeContent = (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-primary text-primary-foreground">Most Popular</Badge>
                    </div>
                  );
                }
                if (isCurrentPlan) {
                  cardBorderClass += ' ring-2 ring-primary';
                }
              }
              
              return (
                <Card key={plan.id} className={`relative ${cardBorderClass}`}>
                  {badgeContent}
                  
                  <CardHeader className="text-center">
                    <div className="mx-auto mb-6 w-fit">
                      {plan.id === 'professional' ? (
                        <img src={budeFavicon} alt="BudE Plan" className="h-16 w-16" />
                      ) : plan.id === 'enterprise' ? (
                        <img src={budePlusFavicon} alt="BudE+ Plan" className="h-16 w-16" />
                      ) : (
                        React.createElement(plan.icon, { className: "h-14 w-14 mt-2" })
                      )}
                    </div>
                    <CardTitle>
                      {plan.price === 0 ? 'Preview' : plan.price === 9.99 ? 'BudE' : 'BudE+'}
                    </CardTitle>
                    <div className="text-3xl font-bold">
                      {plan.price === 0 ? 'Free' : (
                        isYearlyBilling && plan.yearlyPrice ? (
                          <>
                            {formatCurrency(plan.yearlyPrice)}
                            <span className="text-lg text-muted-foreground">/year</span>
                          </>
                        ) : (
                          <>
                            {formatCurrency(plan.price)}
                            <span className="text-lg text-muted-foreground">/month</span>
                          </>
                        )
                      )}
                    </div>
                    {isYearlyBilling && plan.yearlyPrice && (
                      <div className="text-sm text-muted-foreground">
                        Save {formatCurrency((plan.price * 12) - plan.yearlyPrice)} per year
                      </div>
                    )}
                  </CardHeader>
                  
                  <CardContent className="space-y-6">
                    <ul className="space-y-3">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-start space-x-3 text-sm">
                          <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                    
                    {/* Only show Usage Limits for free plan */}
                    {plan.id === 'free' && (
                      <>
                        <Separator />
                        
                        <div className="space-y-3">
                          <h4 className="font-medium text-sm">Usage Limits</h4>
                          <div className="grid grid-cols-2 gap-3 text-sm">
                            <div>
                              <span className="text-muted-foreground">Connections:</span>
                              <p className="font-medium">{plan.limits.connections}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Events:</span>
                              <p className="font-medium">{plan.limits.events}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Messaging:</span>
                              <p className="font-medium">{plan.limits.messaging}</p>
                            </div>

                          </div>
                        </div>
                      </>
                    )}
                    
                    <div className="pt-4">
                      {isCurrentPlan ? (
                        <div className="text-center">
                          <Badge variant="outline" className="w-full py-2">
                            Current Plan
                          </Badge>
                        </div>
                      ) : (
                        <Button 
                          className="w-full" 
                          onClick={() => handlePlanSelection(plan.id)}
                          disabled={isProcessingPayment}
                        >
                          {isProcessingPayment && selectedPlan === plan.id ? (
                            <>
                              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                              Processing...
                            </>
                          ) : (
                            'Select Plan'
                          )}
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        {/* Payment Tab */}
        <TabsContent value="payment" className="space-y-6">
          {selectedPlan && (
            <>
              {/* Order Summary */}
              <Card>
                <CardHeader>
                  <CardTitle>Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {(() => {
                    const plan = SUBSCRIPTION_PLANS.find(p => p.id === selectedPlan);
                    if (!plan) return null;
                    
                    const basePrice = isYearlyBilling && plan.yearlyPrice ? plan.yearlyPrice : plan.price;
                    const discountedPrice = calculateDiscountedPrice(basePrice);
                    const savings = basePrice - discountedPrice;
                    
                    return (
                      <>
                        <div className="flex justify-between items-center">
                          <span>{plan.name} ({isYearlyBilling ? 'Yearly' : 'Monthly'})</span>
                          <span>{formatCurrency(basePrice)}</span>
                        </div>
                        
                        {appliedPromo && (
                          <div className="flex justify-between items-center text-green-600">
                            <span>Discount ({appliedPromo.code})</span>
                            <span>-{formatCurrency(savings)}</span>
                          </div>
                        )}
                        
                        <Separator />
                        
                        <div className="flex justify-between items-center font-semibold text-lg">
                          <span>Total</span>
                          <span>{formatCurrency(discountedPrice)}</span>
                        </div>
                        
                        {isYearlyBilling && plan.yearlyPrice && (
                          <p className="text-sm text-muted-foreground">
                            Save {formatCurrency((plan.price * 12) - plan.yearlyPrice)} compared to monthly billing
                          </p>
                        )}
                      </>
                    );
                  })()}
                </CardContent>
              </Card>

              {/* Promo Code Section */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Tag className="h-5 w-5" />
                    <span>Promo Code</span>
                  </CardTitle>
                  <CardDescription>
                    Have a promo code? Enter it below to apply your discount.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {!appliedPromo ? (
                    <div className="flex space-x-2">
                      <Input
                        placeholder="Enter promo code"
                        value={promoCode}
                        onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
                        className="flex-1"
                        maxLength={20}
                      />
                      <Button 
                        onClick={handleApplyPromoCode}
                        disabled={!promoCode.trim()}
                        className="flex items-center space-x-2"
                      >
                        <Percent className="h-4 w-4" />
                        <span>Apply</span>
                      </Button>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between bg-green-50 dark:bg-green-950/20 p-3 rounded-lg">
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="h-5 w-5 text-green-600" />
                        <div>
                          <p className="font-medium text-green-800 dark:text-green-200">
                            {appliedPromo.code} Applied
                          </p>
                          <p className="text-sm text-green-600 dark:text-green-300">
                            {appliedPromo.description}
                          </p>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={handleRemovePromoCode}
                        className="text-green-600 hover:text-green-700"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Payment Method */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <CreditCard className="h-5 w-5" />
                    <span>Payment Information</span>
                  </CardTitle>
                  <CardDescription>
                    Secure payment processing powered by Stripe
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Card Number */}
                  <div className="space-y-2">
                    <Label htmlFor="cardNumber">Card Number</Label>
                    <Input
                      id="cardNumber"
                      placeholder="1234 5678 9012 3456"
                      value={newCard.cardNumber}
                      onChange={handleCardNumberChange}
                      maxLength={19}
                    />
                  </div>

                  {/* Expiry and CVV */}
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="expiryMonth">Month</Label>
                      <select
                        id="expiryMonth"
                        value={newCard.expiryMonth}
                        onChange={(e) => setNewCard(prev => ({ ...prev, expiryMonth: e.target.value }))}
                        className="w-full p-2 border border-input bg-background rounded-md"
                      >
                        <option value="">MM</option>
                        {months.map(month => (
                          <option key={month.value} value={month.value}>
                            {month.label}
                          </option>
                        ))}
                      </select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="expiryYear">Year</Label>
                      <select
                        id="expiryYear"
                        value={newCard.expiryYear}
                        onChange={(e) => setNewCard(prev => ({ ...prev, expiryYear: e.target.value }))}
                        className="w-full p-2 border border-input bg-background rounded-md"
                      >
                        <option value="">YYYY</option>
                        {years.map(year => (
                          <option key={year} value={year}>
                            {year}
                          </option>
                        ))}
                      </select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="cvv">CVV</Label>
                      <Input
                        id="cvv"
                        placeholder="123"
                        value={newCard.cvv}
                        onChange={(e) => setNewCard(prev => ({ ...prev, cvv: e.target.value.replace(/\D/g, '').slice(0, 4) }))}
                        maxLength={4}
                      />
                    </div>
                  </div>

                  {/* Cardholder Name */}
                  <div className="space-y-2">
                    <Label htmlFor="holderName">Cardholder Name</Label>
                    <Input
                      id="holderName"
                      placeholder="John Doe"
                      value={newCard.holderName}
                      onChange={(e) => setNewCard(prev => ({ ...prev, holderName: e.target.value }))}
                    />
                  </div>

                  {/* Security Notice */}
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground bg-muted/50 p-3 rounded-lg">
                    <Shield className="h-4 w-4" />
                    <span>Your payment information is encrypted and secure</span>
                  </div>

                  {/* Subscribe Button */}
                  <Button
                    className="w-full"
                    size="lg"
                    onClick={() => handleSubscriptionUpgrade(selectedPlan)}
                    disabled={isProcessingPayment || !newCard.cardNumber || !newCard.expiryMonth || !newCard.expiryYear || !newCard.cvv || !newCard.holderName}
                  >
                    {isProcessingPayment ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Processing Payment...
                      </>
                    ) : (
                      <>
                        <Lock className="h-4 w-4 mr-2" />
                        Complete Subscription
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </>
          )}
          
          {!selectedPlan && (
            <Card>
              <CardContent className="pt-6 text-center">
                <p className="text-muted-foreground mb-4">
                  Please select a plan from the Plans tab to continue with payment.
                </p>
                <Button onClick={() => setActiveTab('plans')}>
                  View Plans
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* History Tab */}
        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Billing History</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">Billing history would be displayed here.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Terms and Conditions Modal */}
      {showTerms && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-900 rounded-lg max-w-2xl w-full max-h-[80vh] overflow-hidden">
            <div className="p-6 border-b">
              <h2 className="text-2xl font-semibold">Terms and Conditions</h2>
            </div>
            <div className="p-6 overflow-y-auto max-h-96">
              <TermsAndConditions />
            </div>
            <div className="p-6 border-t flex justify-end space-x-4">
              <Button variant="outline" onClick={handleTermsDecline}>
                Decline
              </Button>
              <Button onClick={handleTermsAccept}>
                Accept & Continue
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}