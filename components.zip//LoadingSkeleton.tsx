// Enhanced loading skeleton components with accessibility
import { memo } from 'react';
import { cn } from './ui/utils';

interface SkeletonProps {
  className?: string;
  children?: React.ReactNode;
}

const Skeleton = memo(({ className, children, ...props }: SkeletonProps) => (
  <div
    className={cn(
      "animate-pulse rounded-md bg-muted",
      className
    )}
    role="status"
    aria-label="Loading content"
    {...props}
  >
    {children}
  </div>
));

Skeleton.displayName = 'Skeleton';

// Card skeleton for dashboard and list items
export const CardSkeleton = memo(() => (
  <div className="mobile-card bg-card border space-y-3" role="status" aria-label="Loading card">
    <div className="flex items-start space-x-3">
      <Skeleton className="h-12 w-12 rounded-full" />
      <div className="space-y-2 flex-1">
        <Skeleton className="h-4 w-3/4" />
        <Skeleton className="h-3 w-1/2" />
      </div>
    </div>
    <div className="space-y-2">
      <Skeleton className="h-3 w-full" />
      <Skeleton className="h-3 w-5/6" />
    </div>
    <div className="flex space-x-2">
      <Skeleton className="h-6 w-16 rounded-full" />
      <Skeleton className="h-6 w-20 rounded-full" />
    </div>
  </div>
));

CardSkeleton.displayName = 'CardSkeleton';

// Event skeleton for events page
export const EventSkeleton = memo(() => (
  <div className="mobile-card bg-card border space-y-4" role="status" aria-label="Loading event">
    <div className="flex items-start justify-between">
      <div className="space-y-2 flex-1">
        <Skeleton className="h-5 w-3/4" />
        <div className="flex items-center space-x-2">
          <Skeleton className="h-4 w-4" />
          <Skeleton className="h-3 w-32" />
        </div>
        <div className="flex items-center space-x-2">
          <Skeleton className="h-4 w-4" />
          <Skeleton className="h-3 w-24" />
        </div>
      </div>
      <Skeleton className="h-16 w-16 rounded-lg" />
    </div>
    <Skeleton className="h-3 w-full" />
    <div className="flex items-center justify-between">
      <div className="flex items-center space-x-2">
        <Skeleton className="h-5 w-5 rounded-full" />
        <Skeleton className="h-3 w-16" />
      </div>
      <Skeleton className="h-8 w-20 rounded-md" />
    </div>
  </div>
));

EventSkeleton.displayName = 'EventSkeleton';

// Profile skeleton for user profiles
export const ProfileSkeleton = memo(() => (
  <div className="space-y-6" role="status" aria-label="Loading profile">
    {/* Header */}
    <div className="mobile-card bg-card border">
      <div className="flex items-start space-x-4">
        <Skeleton className="h-20 w-20 rounded-full" />
        <div className="space-y-2 flex-1">
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-4 w-40" />
          <div className="flex space-x-2 mt-3">
            <Skeleton className="h-8 w-24 rounded-md" />
            <Skeleton className="h-8 w-20 rounded-md" />
          </div>
        </div>
      </div>
    </div>
    
    {/* Bio */}
    <div className="mobile-card bg-card border space-y-3">
      <Skeleton className="h-5 w-24" />
      <div className="space-y-2">
        <Skeleton className="h-3 w-full" />
        <Skeleton className="h-3 w-5/6" />
        <Skeleton className="h-3 w-4/5" />
      </div>
    </div>
    
    {/* Skills */}
    <div className="mobile-card bg-card border space-y-3">
      <Skeleton className="h-5 w-16" />
      <div className="flex flex-wrap gap-2">
        {[...Array(6)].map((_, i) => (
          <Skeleton key={i} className="h-6 w-20 rounded-full" />
        ))}
      </div>
    </div>
  </div>
));

ProfileSkeleton.displayName = 'ProfileSkeleton';

// Message skeleton for messenger
export const MessageSkeleton = memo(() => (
  <div className="space-y-4" role="status" aria-label="Loading messages">
    {[...Array(5)].map((_, i) => (
      <div key={i} className={`flex ${i % 2 === 0 ? 'justify-start' : 'justify-end'}`}>
        <div className={`flex space-x-2 max-w-xs ${i % 2 === 0 ? '' : 'flex-row-reverse space-x-reverse'}`}>
          <Skeleton className="h-8 w-8 rounded-full flex-shrink-0" />
          <div className="space-y-1">
            <Skeleton className="h-8 w-40 rounded-2xl" />
            <Skeleton className="h-3 w-16" />
          </div>
        </div>
      </div>
    ))}
  </div>
));

MessageSkeleton.displayName = 'MessageSkeleton';

// List skeleton for generic lists
export const ListSkeleton = memo(({ items = 5 }: { items?: number }) => (
  <div className="space-y-3" role="status" aria-label="Loading list">
    {[...Array(items)].map((_, i) => (
      <div key={i} className="flex items-center space-x-3 p-3 bg-card border rounded-lg">
        <Skeleton className="h-10 w-10 rounded-full" />
        <div className="space-y-2 flex-1">
          <Skeleton className="h-4 w-3/4" />
          <Skeleton className="h-3 w-1/2" />
        </div>
        <Skeleton className="h-6 w-16 rounded-md" />
      </div>
    ))}
  </div>
));

ListSkeleton.displayName = 'ListSkeleton';

// Dashboard skeleton
export const DashboardSkeleton = memo(() => (
  <div className="space-y-6 p-4" role="status" aria-label="Loading dashboard">
    {/* Header */}
    <div className="space-y-2">
      <Skeleton className="h-8 w-64" />
      <Skeleton className="h-4 w-48" />
    </div>
    
    {/* Stats Grid */}
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {[...Array(4)].map((_, i) => (
        <div key={i} className="mobile-card bg-card border text-center space-y-2">
          <Skeleton className="h-8 w-16 mx-auto" />
          <Skeleton className="h-4 w-20 mx-auto" />
        </div>
      ))}
    </div>
    
    {/* Content Cards */}
    <div className="grid gap-6 md:grid-cols-2">
      <div className="mobile-card bg-card border space-y-4">
        <Skeleton className="h-6 w-32" />
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      </div>
      
      <div className="mobile-card bg-card border space-y-4">
        <Skeleton className="h-6 w-28" />
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <EventSkeleton key={i} />
          ))}
        </div>
      </div>
    </div>
  </div>
));

DashboardSkeleton.displayName = 'DashboardSkeleton';

// Text skeleton for varying content lengths
export const TextSkeleton = memo(({ lines = 3, className }: { lines?: number; className?: string }) => (
  <div className={cn("space-y-2", className)} role="status" aria-label="Loading text">
    {[...Array(lines)].map((_, i) => (
      <Skeleton 
        key={i} 
        className={cn(
          "h-3",
          i === lines - 1 ? "w-3/4" : "w-full"
        )} 
      />
    ))}
  </div>
));

TextSkeleton.displayName = 'TextSkeleton';

// Image skeleton with aspect ratio
export const ImageSkeleton = memo(({ aspectRatio = "16/9", className }: { aspectRatio?: string; className?: string }) => (
  <Skeleton 
    className={cn("w-full", className)} 
    style={{ aspectRatio }}
    aria-label="Loading image"
  />
));

ImageSkeleton.displayName = 'ImageSkeleton';

export { Skeleton };