import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Calendar } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Upload, X, MapPin, Calendar as CalendarIcon, Plane, Linkedin } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { format } from 'date-fns';
import budeLogo from 'figma:asset/3e43a07a7faa73f2f417a9074a180615c3828a87.png';
import phoneImage from 'figma:asset/221384bd887c9cb3071fb8bf5ae94cb16152d5ef.png';
import networkingImage from 'figma:asset/2d7709d2ea02ddad61763aa90c5fd81814a70b79.png';
import meetingImage from 'figma:asset/6c80cbd0a00b5a01a0b64817f9334c6250b87308.png';
import happyNetworkingImage from 'figma:asset/d433f70f458e8b69ec8a75463563def832ecd7f5.png';

const INTERESTS = [
  'Technology', 'Marketing', 'Finance', 'Design', 'Sales', 'HR',
  'Data Science', 'Engineering', 'Consulting',
  'Healthcare', 'Education', 'Real Estate', 'Legal', 'Media',
  'Startup', 'AI/ML', 'Blockchain', 'Sustainability', 'Leadership'
];

const INDUSTRIES = [
  'Technology & Software', 'Healthcare & Medical', 'Financial Services', 'Education',
  'Manufacturing', 'Retail & E-commerce', 'Consulting', 'Real Estate',
  'Media & Entertainment', 'Non-profit', 'Government', 'Energy & Utilities',
  'Transportation & Logistics', 'Hospitality & Tourism', 'Legal Services',
  'Construction', 'Agriculture', 'Telecommunications', 'Automotive', 'Other'
];

const GENDER_PREFERENCES = [
  'No preference', 'Women', 'Men', 'Non-binary', 'Prefer not to say'
];

const RADIUS_OPTIONS = [
  { value: 'under25', label: 'Less than 25 miles' },
  { value: '25', label: '25 miles' },
  { value: '50', label: '50 miles' },
  { value: '100', label: '100 miles' },
  { value: 'anywhere', label: 'Anywhere in my state/region' }
];

const POPULAR_ASSOCIATIONS = [
  'Toastmasters International', 'Grand Rapids Chamber of Commerce', 'Rotary Club', 'Kiwanis Club',
  'Economics Club', 'PRSA', 'Inforum', 'Create Great Leaders', 'CREW', 'Athena',
  'Right Place', 'CARWM', 'GRAR', 'WIM West Michigan', 'GRYP', 'Grand Rapids Social Club',
  'StartGarden', 'Bamboo', 'Creative Mornings GR', 'BNI', 'Tech Council', 'Hello West Michigan'
];

const EVENT_TYPES = [
  'Networking Events', 'Industry Conferences', 'Trade Shows', 'Professional Workshops',
  'Business Mixers', 'Startup Events', 'Tech Meetups', 'Leadership Summits',
  'Women in Business Events', 'Young Professional Events', 'Alumni Gatherings',
  'Chamber of Commerce Events', 'Association Meetings', 'Career Fairs',
  'Educational Seminars', 'Awards Ceremonies'
];

interface OnboardingProps {
  onComplete: (data: any) => void;
}

export function Onboarding({ onComplete }: OnboardingProps) {
  const [step, setStep] = useState(1);
  const [showLogin, setShowLogin] = useState(false);
  const [isLinkedInImporting, setIsLinkedInImporting] = useState(false);
  const [loginData, setLoginData] = useState({
    username: '',
    password: '',
    confirmPassword: ''
  });
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    preferredUsername: '',
    email: '',
    password: '',
    jobTitle: '',
    bio: '',
    interests: [] as string[],
    image: null as File | null,
    industry: '',
    sameIndustryPreference: '',
    genderPreference: '',
    zipCode: '',
    radius: '',
    tempZipCode: '',
    tempStartDate: undefined as Date | undefined,
    tempEndDate: undefined as Date | undefined,
    associations: [] as string[],
    interestedAssociations: [] as string[],
    networkingGoals: '',
    spareTimeActivities: ''
  });

  const handleInterestToggle = (interest: string) => {
    setFormData(prev => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest]
    }));
  };

  const handleAssociationToggle = (association: string) => {
    setFormData(prev => ({
      ...prev,
      associations: prev.associations.includes(association)
        ? prev.associations.filter(a => a !== association)
        : [...prev.associations, association]
    }));
  };

  const handleInterestedAssociationToggle = (association: string) => {
    setFormData(prev => ({
      ...prev,
      interestedAssociations: prev.interestedAssociations.includes(association)
        ? prev.interestedAssociations.filter(a => a !== association)
        : [...prev.interestedAssociations, association]
    }));
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setFormData(prev => ({ ...prev, image: file }));
    }
  };

  const handleSubmit = () => {
    // Temporarily disabled required field validation for development
    // if (!formData.firstName || !formData.lastName || !formData.preferredUsername || !formData.email || !formData.password) {
    //   toast.error('Please fill in all required fields');
    //   return;
    // }
    toast.success('Welcome to Networking BudE!');
    // Combine first and last name for backward compatibility
    const submissionData = {
      ...formData,
      name: `${formData.firstName} ${formData.lastName}`
    };
    onComplete(submissionData);
  };

  const handleLinkedInImport = async () => {
    setIsLinkedInImporting(true);
    
    try {
      // Simulate LinkedIn API call - in production, this would be actual LinkedIn API
      await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate API delay
      
      // Mock LinkedIn data - replace with actual LinkedIn API response
      const mockLinkedInData = {
        firstName: 'Sarah',
        lastName: 'Johnson', 
        email: 'sarah.johnson@email.com',
        jobTitle: 'Marketing Director',
        bio: 'Experienced marketing professional with 8+ years in digital marketing, brand strategy, and team leadership. Passionate about data-driven marketing campaigns and building meaningful customer relationships.',
        industry: 'Marketing & Advertising',
        profilePicture: null // Would be URL in real implementation
      };
      
      // Pre-fill form with LinkedIn data
      setFormData(prev => ({
        ...prev,
        firstName: mockLinkedInData.firstName,
        lastName: mockLinkedInData.lastName,
        email: mockLinkedInData.email,
        jobTitle: mockLinkedInData.jobTitle,
        bio: mockLinkedInData.bio,
        industry: mockLinkedInData.industry,
        // Auto-generate username suggestion
        preferredUsername: `${mockLinkedInData.firstName.toLowerCase()}${mockLinkedInData.lastName.toLowerCase()}`,
      }));
      
      toast.success('LinkedIn profile imported! Please review and complete remaining fields.');
      
    } catch (error) {
      toast.error('Failed to import LinkedIn profile. Please fill out manually.');
    } finally {
      setIsLinkedInImporting(false);
    }
  };

  const handleLogin = () => {
    if (!loginData.username || !loginData.password) {
      toast.error('Please enter both username and password');
      return;
    }
    if (loginData.password !== loginData.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    toast.success('Welcome back to Networking BudE!');
    // Simulate login by creating basic user data
    onComplete({
      firstName: loginData.username.split(' ')[0] || loginData.username,
      lastName: loginData.username.split(' ')[1] || '',
      name: loginData.username,
      jobTitle: 'Professional', // Default job title for existing users
      email: `${loginData.username}@example.com`,
      password: loginData.password,
      isExistingUser: true
    });
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName">First Name</Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
                  placeholder="Enter your first name"
                />
              </div>
              <div>
                <Label htmlFor="lastName">Last Name</Label>
                <Input
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) => setFormData(prev => ({ ...prev, lastName: e.target.value }))}
                  placeholder="Enter your last name"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="preferredUsername">Preferred Username</Label>
              <Input
                id="preferredUsername"
                value={formData.preferredUsername}
                onChange={(e) => setFormData(prev => ({ ...prev, preferredUsername: e.target.value }))}
                placeholder="Choose a unique username"
              />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                placeholder="Enter your email"
              />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={formData.password}
                onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                placeholder="Create a password"
              />
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
            <div>
              <Label htmlFor="jobTitle">Job Title (or what are you better known for)</Label>
              <Input
                id="jobTitle"
                value={formData.jobTitle}
                onChange={(e) => setFormData(prev => ({ ...prev, jobTitle: e.target.value }))}
                placeholder="e.g., Entrepreneur, Consultant, Guru..."
              />
            </div>
            <div>
              <Label htmlFor="bio">Professional Bio</Label>
              <Textarea
                id="bio"
                value={formData.bio}
                onChange={(e) => setFormData(prev => ({ ...prev, bio: e.target.value }))}
                placeholder="Tell us about your professional background..."
                className="min-h-24"
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Industry</Label>
                <Select value={formData.industry} onValueChange={(value) => setFormData(prev => ({ ...prev, industry: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select your industry" />
                  </SelectTrigger>
                  <SelectContent>
                    {INDUSTRIES.map((industry) => (
                      <SelectItem key={industry} value={industry}>
                        {industry}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Industry Connect?</Label>
                <Select value={formData.sameIndustryPreference} onValueChange={(value) => setFormData(prev => ({ ...prev, sameIndustryPreference: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose preference" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="same">Yes - connect with same industry</SelectItem>
                    <SelectItem value="open">No - open to other industries</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground mt-1">
                  Do you wish to connect with someone in the same industry?
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Gender Preference for Connections</Label>
                <Select value={formData.genderPreference} onValueChange={(value) => setFormData(prev => ({ ...prev, genderPreference: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select preference" />
                  </SelectTrigger>
                  <SelectContent>
                    {GENDER_PREFERENCES.map((preference) => (
                      <SelectItem key={preference} value={preference}>
                        {preference}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="zipCode">
                  <MapPin className="h-4 w-4 inline mr-1" />
                  Zip Code
                </Label>
                <Input
                  id="zipCode"
                  value={formData.zipCode}
                  onChange={(e) => setFormData(prev => ({ ...prev, zipCode: e.target.value }))}
                  placeholder="Enter zip code"
                  maxLength={5}
                />
              </div>

              <div>
                <Label>Networking Radius</Label>
                <Select value={formData.radius} onValueChange={(value) => setFormData(prev => ({ ...prev, radius: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="How far do you typically go" />
                  </SelectTrigger>
                  <SelectContent>
                    {RADIUS_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Temporary Travel Location Section */}
            <div className="border rounded-lg p-4 bg-accent/20">
              <div className="flex items-center gap-2 mb-3">
                <Plane className="h-4 w-4 text-primary" />
                <Label className="text-primary">Traveling for work soon? Set a temporary networking destination</Label>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Optionally set a temporary location where you'd like to network during business travel and possibly connect with someone out there
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="tempZipCode">Travel Zip Code</Label>
                  <Input
                    id="tempZipCode"
                    value={formData.tempZipCode}
                    onChange={(e) => setFormData(prev => ({ ...prev, tempZipCode: e.target.value }))}
                    placeholder="Travel destination zip"
                    maxLength={5} className="text-[13px]"
                  />
                </div>

                <div>
                  <Label>Start Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-center"
                      >
                        <CalendarIcon className="h-4 w-4" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={formData.tempStartDate}
                        onSelect={(date) => setFormData(prev => ({ ...prev, tempStartDate: date }))}
                        disabled={(date) => date < new Date()}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div>
                  <Label>End Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-center"
                      >
                        <CalendarIcon className="h-4 w-4" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={formData.tempEndDate}
                        onSelect={(date) => setFormData(prev => ({ ...prev, tempEndDate: date }))}
                        disabled={(date) => {
                          const today = new Date();
                          const startDate = formData.tempStartDate;
                          return date < today || (startDate && date < startDate);
                        }}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              {formData.tempZipCode && formData.tempStartDate && formData.tempEndDate && (
                <div className="mt-3 p-2 bg-primary/10 rounded text-sm">
                  <strong>Travel Plan:</strong> Looking to network in {formData.tempZipCode} from {format(formData.tempStartDate, "MMM d")} to {format(formData.tempEndDate, "MMM d, yyyy")}
                </div>
              )}
            </div>

            <div>
              <Label>Associations I Belong To</Label>
              <p className="text-sm text-muted-foreground mb-2">
                Select associations you're currently a member of (optional)
              </p>
              <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
                {POPULAR_ASSOCIATIONS.map((association) => (
                  <Badge
                    key={association}
                    variant={formData.associations.includes(association) ? "default" : "outline"}
                    className="cursor-pointer hover:bg-primary hover:text-primary-foreground text-xs"
                    onClick={() => handleAssociationToggle(association)}
                  >
                    {association}
                    {formData.associations.includes(association) && (
                      <X className="h-3 w-3 ml-1" />
                    )}
                  </Badge>
                ))}
              </div>
              {formData.associations.length > 0 && (
                <p className="text-sm text-muted-foreground mt-1">
                  Selected: {formData.associations.length} associations
                </p>
              )}
            </div>

            <div>
              <Label>Associations that I'm interested in checking out</Label>
              <p className="text-sm text-muted-foreground mb-2">
                Select associations you'd like to learn more about or possibly join (optional)
              </p>
              <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
                {POPULAR_ASSOCIATIONS.map((association) => (
                  <Badge
                    key={association}
                    variant={formData.interestedAssociations.includes(association) ? "default" : "outline"}
                    className="cursor-pointer hover:bg-primary hover:text-primary-foreground text-xs"
                    onClick={() => handleInterestedAssociationToggle(association)}
                  >
                    {association}
                    {formData.interestedAssociations.includes(association) && (
                      <X className="h-3 w-3 ml-1" />
                    )}
                  </Badge>
                ))}
              </div>
              {formData.interestedAssociations.length > 0 && (
                <p className="text-sm text-muted-foreground mt-1">
                  Selected: {formData.interestedAssociations.length} associations
                </p>
              )}
            </div>

            <div>
              <Label>Profile Picture</Label>
              <div className="mt-2 flex items-center space-x-4">
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center">
                  {formData.image ? (
                    <img 
                      src={URL.createObjectURL(formData.image)} 
                      alt="Profile" 
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    <Upload className="h-6 w-6 text-muted-foreground" />
                  )}
                </div>
                <div>
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                    id="image-upload"
                  />
                  <Label htmlFor="image-upload" className="cursor-pointer">
                    <Button variant="outline" type="button">
                      Upload Photo
                    </Button>
                  </Label>
                </div>
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6 max-h-96 overflow-y-auto pr-2">
            <div>
              <Label>Professional Interests</Label>
              <p className="text-sm text-muted-foreground mb-4">
                Select topics that interest you professionally (choose as many as you like)
              </p>
              <div className="flex flex-wrap gap-2">
                {INTERESTS.map((interest) => (
                  <Badge
                    key={interest}
                    variant={formData.interests.includes(interest) ? "default" : "outline"}
                    className="cursor-pointer hover:bg-primary hover:text-primary-foreground"
                    onClick={() => handleInterestToggle(interest)}
                  >
                    {interest}
                    {formData.interests.includes(interest) && (
                      <X className="h-3 w-3 ml-1" />
                    )}
                  </Badge>
                ))}
                <Badge
                  key="Other"
                  variant={formData.interests.includes("Other") ? "default" : "outline"}
                  className="cursor-pointer hover:bg-primary hover:text-primary-foreground"
                  onClick={() => handleInterestToggle("Other")}
                >
                  Other
                  {formData.interests.includes("Other") && (
                    <X className="h-3 w-3 ml-1" />
                  )}
                </Badge>
              </div>
              {formData.interests.length > 0 && (
                <p className="text-sm text-muted-foreground mt-2">
                  Selected: {formData.interests.length} interests
                </p>
              )}
            </div>

            <div>
              <Label htmlFor="networkingGoals">Goals: What do you want to get out of networking that you're not feeling now?</Label>
              <Textarea
                id="networkingGoals"
                value={formData.networkingGoals}
                onChange={(e) => setFormData(prev => ({ ...prev, networkingGoals: e.target.value }))}
                placeholder="Describe what you hope to achieve through networking... (e.g., finding mentors, expanding my industry knowledge, building confidence in professional settings, finding collaborators, etc.)"
                className="min-h-24 mt-2"
              />
            </div>

            <div>
              <Label htmlFor="spareTimeActivities">What keeps you busy in your spare time?</Label>
              <Textarea
                id="spareTimeActivities"
                value={formData.spareTimeActivities}
                onChange={(e) => setFormData(prev => ({ ...prev, spareTimeActivities: e.target.value }))}
                placeholder="Tell us about your hobbies, interests, and activities outside of work"
                className="min-h-24 mt-2"
              />
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const getStepImage = () => {
    switch (step) {
      case 1:
        return phoneImage;
      case 2:
        return meetingImage;
      case 3:
        return networkingImage;
      default:
        return phoneImage;
    }
  };

  const getStepImageAlt = () => {
    switch (step) {
      case 1:
        return "Networking BudE app on mobile device";
      case 2:
        return "Professional networking meeting";
      case 3:
        return "Professionals networking at business event";
      default:
        return "Networking BudE";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/10">
      <div className="w-full max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8 items-start min-h-screen">
        {/* Image Section */}
        <div className="hidden lg:block lg:sticky lg:top-0 lg:h-screen lg:flex lg:items-start lg:pt-8">
          <div className="relative w-full">
            {/* Main Step Image */}
            <img 
              src={getStepImage()} 
              alt={getStepImageAlt()}
              className="w-full h-auto rounded-2xl shadow-2xl object-cover max-h-[600px]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-2xl"></div>
            
            {/* Collage - Only show on step 1 */}
            {step === 1 && (
              <div className="absolute bottom-4 right-4 flex flex-col space-y-2">
                <img 
                  src={networkingImage} 
                  alt="Networking event" 
                  className="w-32 h-32 rounded-lg object-cover shadow-lg border-2 border-white"
                />
                <img 
                  src={meetingImage} 
                  alt="Business meeting" 
                  className="w-32 h-32 rounded-lg object-cover shadow-lg border-2 border-white"
                />
                <img 
                  src={happyNetworkingImage} 
                  alt="Happy networking conversation" 
                  className="w-32 h-32 rounded-lg object-cover shadow-lg border-2 border-white"
                />
              </div>
            )}
          </div>
        </div>

        {/* Form Section */}
        <div className="flex flex-col justify-start lg:py-8">
          <Card className="w-full max-w-lg mx-auto lg:mx-0">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4">
                <img src={budeLogo} alt="Networking BudE" className="h-16 mx-auto" />
              </div>
              <CardTitle className="text-3xl font-bold font-normal">Welcome to Networking BudE</CardTitle>
              <CardDescription>
                {step === 2 && "Tell us about yourself"}
                {step === 3 && "What are your professional interests?"}
              </CardDescription>
              
              {/* What's this all about section - only show on step 1 */}
              {step === 1 && (
                <div className="mt-6 text-left bg-accent/30 rounded-lg p-4">
                  <h3 className="text-lg font-semibold mb-3 text-center">What's this all about?</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Networking BudE offers the ability to connect with others and attend events with people who share your networking goals:
                  </p>
                  <ul className="text-sm text-muted-foreground space-y-1 mb-4">
                    <li>• Make new meaningful connections based on a multitude of preferences and goals</li>
                    <li>• Find new events to attend with others</li>
                    <li>• Improve your connections dramatically (we think you will)</li>

                    <li>• Possibly make a new friend! (or two or three)</li>
                  </ul>
                  <blockquote className="text-sm italic text-center text-muted-foreground mb-3">
                    "I no longer feel awkward at events alone anymore. Thanks BudE!" - Meghan a Satisfied BudE User
                  </blockquote>
                  <p className="text-center font-semibold text-primary">
                    Ready to jump in? Let's go!
                  </p>
                </div>
              )}
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Progress indicator */}
                <div className="flex space-x-2">
                  {[1, 2, 3].map((num) => (
                    <div
                      key={num}
                      className={`flex-1 h-2 rounded-full ${
                        num <= step ? 'bg-primary' : 'bg-muted'
                      }`}
                    />
                  ))}
                </div>

                {/* Mobile Image (visible on small screens) */}
                <div className="lg:hidden mb-6">
                  <div className="relative">
                    <img 
                      src={getStepImage()} 
                      alt={getStepImageAlt()}
                      className="w-full h-48 rounded-lg object-cover shadow-lg"
                    />
                    {/* Mobile Collage - Only show on step 1 */}
                    {step === 1 && (
                      <div className="absolute bottom-2 right-2 flex flex-col space-y-1">
                        <img 
                          src={networkingImage} 
                          alt="Networking event" 
                          className="w-20 h-20 rounded object-cover shadow-md border border-white"
                        />
                        <img 
                          src={meetingImage} 
                          alt="Business meeting" 
                          className="w-20 h-20 rounded object-cover shadow-md border border-white"
                        />
                        <img 
                          src={happyNetworkingImage} 
                          alt="Happy networking conversation" 
                          className="w-20 h-20 rounded object-cover shadow-md border border-white"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Step Content */}
                {renderStep()}

                {/* Navigation */}
                <div className="flex justify-between pt-4">
                  {step > 1 ? (
                    <Button variant="outline" onClick={() => setStep(step - 1)}>
                      Previous
                    </Button>
                  ) : (
                    <div className="flex space-x-2">
                      <Button variant="outline" onClick={() => setShowLogin(!showLogin)}>
                        {showLogin ? 'New User?' : 'Existing User?'}
                      </Button>
                    </div>
                  )}

                  {showLogin ? (
                    <div className="flex space-x-2">
                      <Button onClick={handleLogin}>
                        Login
                      </Button>
                    </div>
                  ) : (
                    <div className="flex space-x-2">
                      {step < 3 ? (
                        <Button onClick={() => setStep(step + 1)}>
                          Next
                        </Button>
                      ) : (
                        <Button onClick={handleSubmit}>
                          Complete Setup
                        </Button>
                      )}
                    </div>
                  )}
                </div>

                {/* Login Form */}
                {showLogin && (
                  <div className="space-y-4 border-t pt-4">
                    <h3 className="text-lg font-semibold text-center">Login to Existing Account</h3>
                    <div>
                      <Label htmlFor="login-username">Username or Email</Label>
                      <Input
                        id="login-username"
                        value={loginData.username}
                        onChange={(e) => setLoginData(prev => ({ ...prev, username: e.target.value }))}
                        placeholder="Enter your username or email"
                      />
                    </div>
                    <div>
                      <Label htmlFor="login-password">Password</Label>
                      <Input
                        id="login-password"
                        type="password"
                        value={loginData.password}
                        onChange={(e) => setLoginData(prev => ({ ...prev, password: e.target.value }))}
                        placeholder="Enter your password"
                      />
                    </div>
                    <div>
                      <Label htmlFor="login-confirm-password">Confirm Password</Label>
                      <Input
                        id="login-confirm-password"
                        type="password"
                        value={loginData.confirmPassword}
                        onChange={(e) => setLoginData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                        placeholder="Confirm your password"
                      />
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}