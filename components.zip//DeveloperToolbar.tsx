// Simplified Developer Toolbar - Single mode for full access with minimize functionality
import { memo, useCallback, startTransition, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMobilePreview } from '../hooks/useMobilePreview';
import { useSubscription } from '../hooks/useSubscription';

interface DeveloperToolbarProps {
  isOnboarded: boolean;
  onClearSession?: () => void;
  onHapticFeedback?: (type: 'light' | 'medium' | 'heavy') => void;
  onAnnounce?: (message: string, priority?: 'polite' | 'assertive') => void;
}

export const DeveloperToolbar = memo<DeveloperToolbarProps>(({
  isOnboarded,
  onClearSession,
  onHapticFeedback,
  onAnnounce
}) => {
  const navigate = useNavigate();
  const { forceMobileView, toggleMobilePreview } = useMobilePreview();
  const { isAdminBypass, enableDeveloperMode, disableDeveloperMode, emergencyDeveloperAccess } = useSubscription();
  const [isMinimized, setIsMinimized] = useState(false);

  const handleHapticFeedback = useCallback((type: 'light' | 'medium' | 'heavy') => {
    onHapticFeedback?.(type);
  }, [onHapticFeedback]);

  const handleAnnounce = useCallback((message: string, priority: 'polite' | 'assertive' = 'polite') => {
    onAnnounce?.(message, priority);
  }, [onAnnounce]);
  
  // Emergency developer access keyboard shortcut (Ctrl+Shift+D)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'D') {
        e.preventDefault();
        if (!isAdminBypass) {
          emergencyDeveloperAccess();
          handleAnnounce('Emergency developer access activated!');
          console.log('🚨 Emergency developer access activated via keyboard shortcut');
        }
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isAdminBypass, emergencyDeveloperAccess, handleAnnounce]);

  const handleMobilePreviewToggle = useCallback(() => {
    toggleMobilePreview();
    handleHapticFeedback('light');
    handleAnnounce('Mobile preview mode toggled');
  }, [toggleMobilePreview, handleHapticFeedback, handleAnnounce]);

  const handleEnterDevMode = useCallback(() => {
    enableDeveloperMode();
    setIsMinimized(true); // Auto-minimize when dev mode is activated
    handleHapticFeedback('medium');
    handleAnnounce('Developer mode activated with full access');
  }, [enableDeveloperMode, handleHapticFeedback, handleAnnounce]);

  const handleExitDevMode = useCallback(() => {
    disableDeveloperMode();
    setIsMinimized(false); // Reset minimized state when exiting
    handleHapticFeedback('light');
    handleAnnounce('Developer mode disabled');
  }, [disableDeveloperMode, handleHapticFeedback, handleAnnounce]);

  const handleToggleMinimized = useCallback(() => {
    setIsMinimized(!isMinimized);
    handleHapticFeedback('light');
    handleAnnounce(isMinimized ? 'Developer toolbar expanded' : 'Developer toolbar minimized');
  }, [isMinimized, handleHapticFeedback, handleAnnounce]);

  const handleNavigation = useCallback((path: string, label: string) => {
    if (window.location.pathname !== path) {
      startTransition(() => navigate(path));
      handleHapticFeedback('light');
      handleAnnounce(`Navigating to ${label}`);
    }
  }, [navigate, handleHapticFeedback, handleAnnounce]);

  const handleTestOnboarding = useCallback(() => {
    onClearSession?.();
    handleHapticFeedback('medium');
    handleAnnounce('Resetting to onboarding');
  }, [onClearSession, handleHapticFeedback, handleAnnounce]);

  const navigationItems = [
    { path: '/dashboard', label: 'Dashboard' },
    { path: '/events', label: 'Events' },
    { path: '/connections', label: 'Connections' },
    { path: '/messenger', label: 'Messenger' },
    { path: '/profile/current', label: 'Profile' },
    { path: '/settings', label: 'Settings' }
  ];

  // Simple view when not in developer mode
  if (!isAdminBypass && !forceMobileView) {
    return (
      <div className="hidden lg:block fixed top-4 right-4 z-50">
        <button
          onClick={handleMobilePreviewToggle}
          className="bg-primary text-primary-foreground px-3 py-2 rounded-lg text-sm font-medium shadow-lg hover:bg-primary/90 transition-colors touch-target"
          aria-label="Toggle mobile preview"
        >
          📱 Mobile Preview
        </button>
      </div>
    );
  }

  return (
    <div className="fixed top-4 right-4 z-50 space-y-2">
      {/* Mobile Preview Toggle */}
      {!forceMobileView && (
        <button
          onClick={handleMobilePreviewToggle}
          className="bg-primary text-primary-foreground px-3 py-2 rounded-lg text-sm font-medium shadow-lg hover:bg-primary/90 transition-colors touch-target block touch-active"
          aria-label="Toggle mobile preview"
        >
          📱 Mobile Preview
        </button>
      )}
      
      {/* Developer Mode Panel */}
      <div className="hidden lg:block">
        {!isAdminBypass ? (
          <button
            onClick={handleEnterDevMode}
            className="bg-blue-600 text-white px-3 py-2 rounded-lg text-sm font-medium shadow-lg hover:bg-blue-700 transition-colors touch-target block w-full touch-active"
            aria-label="Enter developer mode"
          >
            🔧 Dev Mode
          </button>
        ) : isMinimized ? (
          // Minimized developer mode - compact floating indicator
          <div 
            className="bg-green-600 text-white rounded-full shadow-lg hover:bg-green-700 transition-colors cursor-pointer"
            onClick={handleToggleMinimized}
            role="button"
            aria-label="Expand developer toolbar"
            tabIndex={0}
            onKeyDown={(e) => e.key === 'Enter' && handleToggleMinimized()}
          >
            <div className="p-2 flex items-center space-x-1">
              <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
              <span className="text-xs font-medium">DEV</span>
              <span className="text-xs">⬆</span>
            </div>
          </div>
        ) : (
          <div className="bg-white dark:bg-card border border-border rounded-lg shadow-lg p-3 space-y-2 min-w-48">
            {/* Header */}
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-green-600">
                🔧 Developer Mode (Full Access)
              </span>
              <div className="flex items-center space-x-1">
                <button
                  onClick={handleToggleMinimized}
                  className="text-xs text-muted-foreground hover:text-foreground transition-colors p-1"
                  aria-label="Minimize developer toolbar"
                  title="Minimize"
                >
                  ⬇
                </button>
                <button
                  onClick={handleExitDevMode}
                  className="text-xs text-muted-foreground hover:text-foreground transition-colors p-1"
                  aria-label="Exit developer mode"
                  title="Exit Dev Mode"
                >
                  ✕
                </button>
              </div>
            </div>
            
            {/* Access Status */}
            <div className="bg-green-50 dark:bg-green-950 text-green-700 dark:text-green-300 p-2 text-xs rounded">
              <div className="flex items-center justify-between">
                <span>🔓 Full Access Enabled</span>
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              </div>
              <div className="text-xs opacity-75 mt-1">
                All premium features unlocked
              </div>
            </div>
            
            {/* Quick Navigation */}
            <div className="grid grid-cols-2 gap-1 text-xs">
              {navigationItems.map(({ path, label }) => (
                <button
                  key={path}
                  onClick={() => handleNavigation(path, label)}
                  className="p-2 rounded text-left hover:bg-accent focus:bg-accent focus:outline-none focus:ring-2 focus:ring-primary transition-colors touch-active"
                  aria-label={`Navigate to ${label.toLowerCase()}`}
                >
                  {label}
                </button>
              ))}
            </div>
            
            {/* Test Onboarding Button */}
            {!isOnboarded && (
              <button
                onClick={handleTestOnboarding}
                className="w-full p-2 text-xs bg-blue-50 dark:bg-blue-950 hover:bg-blue-100 dark:hover:bg-blue-900 rounded text-blue-700 dark:text-blue-300 transition-colors"
              >
                🔄 Reset to Onboarding
              </button>
            )}
            
            {/* Permanent Developer Access Button */}
            <button
              onClick={() => {
                localStorage.setItem('networking_bude_permanent_dev', 'true');
                handleAnnounce('Permanent developer access enabled!');
                console.log('🔒 Permanent developer access enabled');
              }}
              className="w-full p-2 text-xs bg-purple-50 dark:bg-purple-950 hover:bg-purple-100 dark:hover:bg-purple-900 rounded text-purple-700 dark:text-purple-300 transition-colors"
              title="Enable permanent developer access (survives page reloads)"
            >
              🔒 Make Permanent
            </button>
          </div>
        )}
      </div>
    </div>
  );
});

DeveloperToolbar.displayName = 'DeveloperToolbar';