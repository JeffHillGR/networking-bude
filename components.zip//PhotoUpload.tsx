import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Upload } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import profilePhoto from 'figma:asset/91425afcd66a5742af24e0793ffdcaad9c358559.png';

interface PhotoUploadProps {
  currentImage?: File | null;
  currentImageDataUrl?: string;
  onImageSelect: (file: File | null, dataUrl: string) => void;
  buttonText?: string;
  showPreview?: boolean;
}

export function PhotoUpload({
  currentImage,
  currentImageDataUrl,
  onImageSelect,
  buttonText = "Upload Photo",
  showPreview = true
}: PhotoUploadProps) {
  const [showPhotoPicker, setShowPhotoPicker] = useState(false);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Convert to data URL for storage
      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUrl = e.target?.result as string;
        onImageSelect(file, dataUrl);
      };
      reader.readAsDataURL(file);
      setShowPhotoPicker(false);
      toast.success('Photo uploaded successfully!', {
        duration: 2500
      });
    }
  };

  const handlePresetImageSelect = (imageUrl: string) => {
    onImageSelect(null, imageUrl); // Clear file since we're using preset
    setShowPhotoPicker(false);
    toast.success('Profile photo selected!', {
      duration: 2500
    });
  };

  return (
    <div className="space-y-2">
      {showPreview && (
        <div className="mt-2 flex items-center space-x-4">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center">
            {currentImageDataUrl ? (
              <img 
                src={currentImage ? URL.createObjectURL(currentImage) : currentImageDataUrl} 
                alt="Profile" 
                className="w-full h-full rounded-full object-cover"
              />
            ) : (
              <Upload className="h-6 w-6 text-muted-foreground" />
            )}
          </div>
          <div>
            <Dialog open={showPhotoPicker} onOpenChange={setShowPhotoPicker}>
              <DialogTrigger asChild>
                <Button variant="outline" type="button">
                  {buttonText}
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Upload Profile Photo</DialogTitle>
                  <DialogDescription>
                    Choose a professional photo that represents you well. This will be visible to other networking contacts.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>Upload your own photo</Label>
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      id="image-upload"
                    />
                  </div>
                  
                  <div className="relative my-4">
                    <div className="absolute inset-0 flex items-center">
                      <span className="w-full border-t" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-background px-2 text-muted-foreground">Or choose a demo photo</span>
                    </div>
                  </div>
                  
                  <div>
                    <Label className="mb-3 block">Demo Photos</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <div 
                        className="relative cursor-pointer rounded-lg border-2 border-dashed border-muted-foreground/25 p-4 hover:border-primary transition-colors"
                        onClick={() => handlePresetImageSelect(profilePhoto)}
                      >
                        <img 
                          src={profilePhoto} 
                          alt="Demo profile" 
                          className="w-full h-20 object-cover rounded-md"
                        />
                        <p className="text-xs text-center mt-2 text-muted-foreground">Professional Demo</p>
                      </div>
                    </div>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      )}
      
      {!showPreview && (
        <Dialog open={showPhotoPicker} onOpenChange={setShowPhotoPicker}>
          <DialogTrigger asChild>
            <Button variant="outline" type="button" className="w-full">
              {buttonText}
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Upload Profile Photo</DialogTitle>
              <DialogDescription>
                Choose a professional photo that represents you well. This will be visible to other networking contacts.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Upload your own photo</Label>
                <Input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  id="image-upload"
                />
              </div>
              
              <div className="relative my-4">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-background px-2 text-muted-foreground">Or choose a demo photo</span>
                </div>
              </div>
              
              <div>
                <Label className="mb-3 block">Demo Photos</Label>
                <div className="grid grid-cols-2 gap-3">
                  <div 
                    className="relative cursor-pointer rounded-lg border-2 border-dashed border-muted-foreground/25 p-4 hover:border-primary transition-colors"
                    onClick={() => handlePresetImageSelect(profilePhoto)}
                  >
                    <img 
                      src={profilePhoto} 
                      alt="Demo profile" 
                      className="w-full h-20 object-cover rounded-md"
                    />
                    <p className="text-xs text-center mt-2 text-muted-foreground">Professional Demo</p>
                  </div>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}