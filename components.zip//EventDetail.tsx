import { useParams, Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  Users, 
  ArrowLeft,
  Share2,
  Heart,
  ExternalLink,
  User,
  CheckCircle,
  UserPlus,
  MessageCircle,
  TrendingUp
} from 'lucide-react';
import { useState, useEffect } from 'react';
import { toast } from 'sonner@2.0.3';
import { DynamicBannerAd } from './DynamicBannerAd';

// Mock event data - in a real app this would come from an API
const EVENT_DATA = {
  1: {
    id: 1,
    title: 'Creative Mornings Design Session',
    description: 'Inspiring morning session with local designers and creative professionals. Coffee and networking included.',
    fullDescription: `Join fellow creatives for an inspiring morning session featuring local designers and creative professionals working across Grand Rapids' thriving creative scene. This monthly gathering brings together graphic designers, web developers, photographers, illustrators, and other creative minds to share ideas, build connections, and get inspired.

Each session features a brief presentation from a local creative professional followed by open networking time. We'll discuss topics like:

• Current design trends and creative techniques
• Building a creative career in West Michigan
• Collaborative opportunities across creative disciplines
• Showcase of local creative work and projects
• Tips for freelancers and agency professionals

The format is relaxed and designed for meaningful conversations. Whether you're just starting your creative career or are an established professional, you'll find valuable connections and fresh perspectives.

Coffee, pastries, and light breakfast items will be provided throughout the morning. This is a perfect opportunity to start your day with inspiration and connect with Grand Rapids' vibrant creative community.

Bamboo Grand Rapids is a new co-working space opening soon in the heart of downtown, designed specifically to support creative entrepreneurs and small businesses in West Michigan.`,
    date: '2025-09-20',
    time: '8:00 AM - 10:00 AM',
    location: 'Bamboo Grand Rapids',
    address: 'Downtown Grand Rapids, MI',
    type: 'In-Person',
    category: 'Creative',
    price: 0,
    image: 'https://images.unsplash.com/photo-1571645163064-77faa9676a46?w=400&h=300&fit=crop',
    organizer: 'Creative Mornings GR',
    organizerDescription: 'Creative Mornings GR is part of the global Creative Mornings network, bringing together Grand Rapids creative professionals for monthly breakfast lectures and networking.',
    registrationUrl: 'https://creativemornings.com/cities/grand-rapids',
    tags: ['Networking', 'Design', 'Creative', 'Breakfast', 'Community'],
    agenda: [
      { time: '8:00 AM', item: 'Registration & Welcome Coffee' },
      { time: '8:15 AM', item: 'Welcome & Community Updates' },
      { time: '8:30 AM', item: 'Featured Presentation by Local Creative' },
      { time: '9:00 AM', item: 'Open Networking & Breakfast' },
      { time: '9:30 AM', item: 'Creative Showcase & Portfolio Sharing' },
      { time: '9:50 AM', item: 'Wrap-up & Next Month Preview' },
      { time: '10:00 AM', item: 'Event Ends' }
    ],
    recommendedMatches: [
      {
        id: 1,
        name: 'Sarah Johnson',
        title: 'Graphic Designer',
        company: 'Creative Mornings GR',
        bio: 'Visual storyteller passionate about branding and community-driven design projects.',
        avatar: 'SJ',
        image: 'https://images.unsplash.com/photo-1608875848903-06eec0bd71e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBsYXRpbmElMjB3b21hbiUyMGhlYWRzaG90JTIwYnVzaW5lc3N8ZW58MXx8fHwxNzU4MDUxNjYzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        matchReason: 'Creative Mornings organizer',
        interests: ['Graphic Design', 'Branding', 'Community'],
        connectionStatus: 'not_connected'
      },
      {
        id: 2,
        name: 'Mike Chen',
        title: 'Web Developer',
        company: 'Local Design Studio',
        bio: 'Full-stack developer creating digital experiences for West Michigan businesses.',
        avatar: 'MC',
        image: 'https://images.unsplash.com/photo-1740153204804-200310378f2f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBhc2lhbiUyMHdvbWFuJTIwaGVhZHNob3QlMjBidXNpbmVzc3xlbnwxfHx8fDE3NTgwNTE2NjN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        matchReason: 'Creative technology focus',
        interests: ['Web Development', 'UI/UX', 'Creative Tech'],
        connectionStatus: 'not_connected'
      },
      {
        id: 3,
        name: 'Jordan Williams',
        title: 'Creative Director',
        company: 'Bamboo Grand Rapids',
        bio: 'Leading creative strategy and community building at Grand Rapids newest co-working space.',
        avatar: 'JW',
        image: 'https://images.unsplash.com/photo-1652471943570-f3590a4e52ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBibGFjayUyMG1hbiUyMGhlYWRzaG90JTIwYnVzaW5lc3N8ZW58MXx8fHwxNzU4MDUxNjYyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        matchReason: 'Event venue connection',
        interests: ['Creative Direction', 'Community Building', 'Entrepreneurship'],
        connectionStatus: 'pending'
      },
      {
        id: 4,
        name: 'Maya Patel',
        title: 'Photographer',
        company: 'Freelance',
        bio: 'Documentary and portrait photographer capturing Grand Rapids creative community.',
        avatar: 'MP',
        image: 'https://images.unsplash.com/photo-1704927768421-bc9549b5097d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBpbmRpYW4lMjB3b21hbiUyMGhlYWRzaG90JTIwYnVzaW5lc3N8ZW58MXx8fHwxNzU4MDUxNjczfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        matchReason: 'Creative community member',
        interests: ['Photography', 'Visual Arts', 'Storytelling'],
        connectionStatus: 'not_connected'
      }
    ]
  },
  3: {
    id: 3,
    title: 'StartGarden Entrepreneur Pitch',
    description: 'Local startups pitch to investors while networking with entrepreneurs and VCs.',
    fullDescription: `Join us for an exciting evening where promising West Michigan startups pitch their innovative ideas to local investors and the entrepreneurial community. This quarterly showcase features 4-5 carefully selected startups presenting their businesses in a supportive, collaborative environment.

Each startup will have 10 minutes to present followed by 5 minutes of Q&A from our panel of local investors, successful entrepreneurs, and business leaders. After the presentations, enjoy networking with:

• Startup founders and teams
• Angel investors and VCs
• Successful entrepreneurs and mentors
• Business development professionals
• Economic development leaders

Featured sectors often include:
• Technology and software
• Healthcare innovation
• Sustainable business solutions
• Consumer products and services
• B2B solutions for growing companies

StartGarden has been a cornerstone of Grand Rapids entrepreneurial ecosystem since 2011, providing funding, mentorship, and community support to early-stage startups. This event is perfect for anyone interested in entrepreneurship, investing, or supporting the local startup community.

Light appetizers and beverages will be provided during networking time. Come ready to be inspired by local innovation and connect with West Michigan's entrepreneurial leaders.`,
    date: '2025-09-25',
    time: '6:30 PM - 9:00 PM',
    location: 'StartGarden',
    address: '123 Ionia Ave SW, Grand Rapids, MI',
    type: 'In-Person',
    category: 'Startup',
    price: 15,
    image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=400&h=300&fit=crop',
    organizer: 'StartGarden',
    organizerDescription: 'StartGarden is Grand Rapids premier startup accelerator and investment fund, supporting early-stage entrepreneurs across West Michigan since 2011.',
    registrationUrl: 'https://startgarden.com/events',
    tags: ['Startup', 'Entrepreneurship', 'Investing', 'Innovation', 'Pitching'],
    agenda: [
      { time: '6:30 PM', item: 'Registration & Welcome Reception' },
      { time: '7:00 PM', item: 'Welcome & StartGarden Updates' },
      { time: '7:15 PM', item: 'Startup Pitch Presentations (4-5 companies)' },
      { time: '8:15 PM', item: 'Q&A with Investor Panel' },
      { time: '8:30 PM', item: 'Networking Reception & One-on-One Meetings' },
      { time: '8:50 PM', item: 'Closing Remarks & Next Steps' },
      { time: '9:00 PM', item: 'Event Ends' }
    ],
    recommendedMatches: [
      {
        id: 5,
        name: 'Rick DeVos',
        title: 'Managing Partner',
        company: 'StartGarden',
        bio: 'Leading StartGarden investment strategy and mentoring West Michigan entrepreneurs.',
        avatar: 'RD',
        image: 'https://images.unsplash.com/photo-1608875848903-06eec0bd71e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBsYXRpbmElMjB3b21hbiUyMGhlYWRzaG90JTIwYnVzaW5lc3N8ZW58MXx8fHwxNzU4MDUxNjYzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        matchReason: 'StartGarden leadership',
        interests: ['Venture Capital', 'Entrepreneurship', 'Mentorship'],
        connectionStatus: 'not_connected'
      },
      {
        id: 6,
        name: 'Amanda Rodriguez',
        title: 'Startup Founder',
        company: 'TechFlow Solutions',
        bio: 'Building B2B software solutions and part of StartGarden current cohort.',
        avatar: 'AR',
        image: 'https://images.unsplash.com/photo-1740153204804-200310378f2f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBhc2lhbiUyMHdvbWFuJTIwaGVhZHNob3QlMjBidXNpbmVzc3xlbnwxfHx8fDE3NTgwNTE2NjN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        matchReason: 'StartGarden entrepreneur',
        interests: ['B2B Software', 'Startup', 'Technology'],
        connectionStatus: 'not_connected'
      },
      {
        id: 7,
        name: 'David Kim',
        title: 'Angel Investor',
        company: 'West Michigan Angels',
        bio: 'Active angel investor focused on early-stage technology and healthcare startups.',
        avatar: 'DK',
        image: 'https://images.unsplash.com/photo-1652471943570-f3590a4e52ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBibGFjayUyMG1hbiUyMGhlYWRzaG90JTIwYnVzaW5lc3N8ZW58MXx8fHwxNzU4MDUxNjYyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        matchReason: 'Local investor network',
        interests: ['Angel Investing', 'Healthcare', 'Technology'],
        connectionStatus: 'pending'
      },
      {
        id: 8,
        name: 'Lisa Thompson',
        title: 'Business Development',
        company: 'The Right Place Inc',
        bio: 'Supporting economic development and startup growth in West Michigan.',
        avatar: 'LT',
        image: 'https://images.unsplash.com/photo-1704927768421-bc9549b5097d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBpbmRpYW4lMjB3b21hbiUyMGhlYWRzaG90JTIwYnVzaW5lc3N8ZW58MXx8fHwxNzU4MDUxNjczfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        matchReason: 'Economic development focus',
        interests: ['Business Development', 'Economic Development', 'Entrepreneurship'],
        connectionStatus: 'not_connected'
      }
    ]
  },
  4: {
    id: 4,
    title: 'Athena Leadership Workshop',
    description: 'Empowering professional women through networking, mentorship, and skill development.',
    fullDescription: `Join professional women across West Michigan for a full-day leadership development workshop designed to build skills, create connections, and advance careers. This comprehensive program combines interactive workshops, peer networking, and mentorship opportunities.

The day includes multiple workshop tracks allowing participants to customize their experience based on career goals and interests:

• Executive Leadership & Strategy
• Negotiation and Communication Skills
• Building and Leading High-Performance Teams
• Personal Branding & Professional Visibility
• Financial Leadership and Business Acumen
• Work-Life Integration and Resilience

Each track features experienced facilitators who are leaders in their respective fields across Grand Rapids business community. Between workshop sessions, enjoy structured networking activities and mentorship speed-dating to build meaningful professional relationships.

Athena Grand Rapids has been connecting and advancing professional women in West Michigan for over 15 years. Our members include executives, entrepreneurs, professionals, and emerging leaders across all industries.

The event includes breakfast, lunch, and afternoon refreshments. All participants receive a comprehensive resource guide and access to Athena online community for continued networking and support.

This workshop is designed for women at all career stages who are committed to professional growth and building meaningful connections in West Michigan business community.`,
    date: '2025-09-28',
    time: '9:00 AM - 5:00 PM',
    location: 'Grand Rapids Art Museum',
    address: '101 Monroe Center St NW, Grand Rapids, MI',
    type: 'In-Person',
    category: 'Leadership',
    price: 75,
    image: 'https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?w=400&h=300&fit=crop',
    organizer: 'Athena',
    organizerDescription: 'Athena Grand Rapids connects and advances professional women through networking, leadership development, and mentorship programs across West Michigan.',
    registrationUrl: 'https://athenagreatergrandrapids.org/events',
    tags: ['Leadership', 'Women in Business', 'Professional Development', 'Mentorship', 'Networking'],
    agenda: [
      { time: '9:00 AM', item: 'Registration & Welcome Breakfast' },
      { time: '9:30 AM', item: 'Opening Keynote & Workshop Track Overview' },
      { time: '10:00 AM', item: 'Morning Workshop Sessions (Track A & B)' },
      { time: '11:30 AM', item: 'Networking Break' },
      { time: '12:00 PM', item: 'Leadership Panel & Lunch' },
      { time: '1:30 PM', item: 'Afternoon Workshop Sessions (Track C & D)' },
      { time: '3:00 PM', item: 'Mentorship Speed Networking' },
      { time: '4:00 PM', item: 'Resource Sharing & Action Planning' },
      { time: '4:45 PM', item: 'Closing Remarks & Next Steps' },
      { time: '5:00 PM', item: 'Reception & Continued Networking' }
    ],
    recommendedMatches: [
      {
        id: 9,
        name: 'Jennifer Martinez',
        title: 'Executive Director',
        company: 'Athena Grand Rapids',
        bio: 'Leading Athena mission to advance professional women through education and networking.',
        avatar: 'JM',
        image: 'https://images.unsplash.com/photo-1608875848903-06eec0bd71e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBsYXRpbmElMjB3b21hbiUyMGhlYWRzaG90JTIwYnVzaW5lc3N8ZW58MXx8fHwxNzU4MDUxNjYzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        matchReason: 'Athena leadership',
        interests: ['Leadership Development', 'Women in Business', 'Mentorship'],
        connectionStatus: 'not_connected'
      },
      {
        id: 10,
        name: 'Sarah Chen',
        title: 'VP Marketing',
        company: 'Steelcase',
        bio: 'Marketing executive and Athena member passionate about developing future female leaders.',
        avatar: 'SC',
        image: 'https://images.unsplash.com/photo-1740153204804-200310378f2f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBhc2lhbiUyMHdvbWFuJTIwaGVhZHNob3QlMjBidXNpbmVzc3xlbnwxfHx8fDE3NTgwNTE2NjN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        matchReason: 'Athena member and mentor',
        interests: ['Marketing', 'Leadership', 'Professional Development'],
        connectionStatus: 'not_connected'
      },
      {
        id: 11,
        name: 'Rachel Johnson',
        title: 'Managing Partner',
        company: 'Johnson Law Group',
        bio: 'Attorney and business owner focused on supporting women entrepreneurs.',
        avatar: 'RJ',
        image: 'https://images.unsplash.com/photo-1652471943570-f3590a4e52ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBibGFjayUyMG1hbiUyMGhlYWRzaG90JTIwYnVzaW5lc3N8ZW58MXx8fHwxNzU4MDUxNjYyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        matchReason: 'Women entrepreneur advocate',
        interests: ['Law', 'Entrepreneurship', 'Business Ownership'],
        connectionStatus: 'pending'
      },
      {
        id: 12,
        name: 'Michelle Davis',
        title: 'Finance Director',
        company: 'Spectrum Health',
        bio: 'Healthcare finance leader and mentor for emerging women professionals.',
        avatar: 'MD',
        image: 'https://images.unsplash.com/photo-1704927768421-bc9549b5097d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBpbmRpYW4lMjB3b21hbiUyMGhlYWRzaG90JTIwYnVzaW5lc3N8ZW58MXx8fHwxNzU4MDUxNjczfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        matchReason: 'Healthcare leadership experience',
        interests: ['Healthcare', 'Finance', 'Mentorship'],
        connectionStatus: 'not_connected'
      }
    ]
  }
};

export function EventDetail() {
  const { id } = useParams();

  const [isSaved, setIsSaved] = useState(false);
  const [connectionStates, setConnectionStates] = useState<{[key: number]: string}>({});
  
  const event = EVENT_DATA[id as keyof typeof EVENT_DATA];

  // Scroll to top when component mounts or event ID changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [id]);

  if (!event) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="p-12 text-center">
            <h2 className="text-xl font-semibold mb-2">Event not found</h2>
            <p className="text-muted-foreground mb-4">
              The event you're looking for doesn't exist or has been removed.
            </p>
            <Link to="/events">
              <Button>Back to Events</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleRegister = () => {
    window.open(event.registrationUrl, '_blank');
    toast.success('Opening event organizer registration page...');
  };

  const handleSave = () => {
    setIsSaved(!isSaved);
    toast.success(isSaved ? 'Event removed from saved' : 'Event saved!');
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success('Event link copied to clipboard!');
  };

  const handleConnect = (matchId: number, matchName: string) => {
    setConnectionStates(prev => ({ ...prev, [matchId]: 'pending' }));
    toast.success(`Connection request sent to ${matchName}!`);
  };

  const handleMessage = (matchName: string) => {
    toast.success(`Opening conversation with ${matchName}...`);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Link to="/events">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl font-semibold">Event Details</h1>
          <p className="text-muted-foreground">
            Everything you need to know about this event
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Hero Image */}
          <Card className="overflow-hidden">
            <div className="aspect-video relative">
              <img 
                src={event.image} 
                alt={event.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 left-4">
                <Badge variant={event.type === 'Virtual' ? 'secondary' : 'default'}>
                  {event.type}
                </Badge>
              </div>
              {event.price === 0 && (
                <div className="absolute top-4 right-4">
                  <Badge variant="outline" className="bg-white">Free</Badge>
                </div>
              )}
            </div>
          </Card>

          {/* Event Info */}
          <Card>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-2xl">{event.title}</CardTitle>
                  <CardDescription className="text-base mt-2">
                    {event.description}
                  </CardDescription>
                </div>
                <div className="flex space-x-2">
                  <Button variant="ghost" size="icon" onClick={handleSave}>
                    <Heart className={`h-4 w-4 ${isSaved ? 'fill-current text-red-500' : ''}`} />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={handleShare}>
                    <Share2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  {event.tags.map((tag) => (
                    <Badge key={tag} variant="outline">{tag}</Badge>
                  ))}
                </div>
                
                <div className="prose max-w-none">
                  <p className="whitespace-pre-line text-sm">{event.fullDescription}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Event Agenda */}
          {event.agenda && (
            <Card>
              <CardHeader>
                <CardTitle>Event Agenda</CardTitle>
                <CardDescription>
                  Schedule and timeline for the event
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {event.agenda.map((item, index) => (
                    <div key={index} className="flex items-start space-x-3 p-3 rounded-lg bg-muted/50">
                      <div className="flex-shrink-0 w-20 text-sm font-medium text-muted-foreground">
                        {item.time}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm">{item.item}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Recommended Matches */}
          {event.recommendedMatches && event.recommendedMatches.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5" />
                  <span>Recommended Connections</span>
                </CardTitle>
                <CardDescription>
                  Connect with professionals from {event.organizer} and related organizations
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {event.recommendedMatches.map((match) => {
                    const currentStatus = connectionStates[match.id] || match.connectionStatus;
                    
                    return (
                      <div key={match.id} className="p-4 rounded-lg border hover:border-primary/50 transition-colors">
                        <div className="flex items-start space-x-3">
                          <Link to={`/profile/${match.id}`}>
                            <Avatar className="w-12 h-12 cursor-pointer hover:ring-2 hover:ring-primary/50 flex-shrink-0">
                              <AvatarImage src={match.image} alt={match.name} />
                              <AvatarFallback>{match.avatar}</AvatarFallback>
                            </Avatar>
                          </Link>
                          <div className="flex-1 min-w-0">
                            <Link to={`/profile/${match.id}`} className="hover:text-primary">
                              <h4 className="font-medium">{match.name}</h4>
                            </Link>
                            <p className="text-sm text-muted-foreground">{match.title}</p>
                            <p className="text-sm text-muted-foreground">{match.company}</p>
                            
                            <div className="flex items-center gap-1 mt-2">
                              <Badge 
                                variant="outline" 
                                className="text-xs"
                              >
                                {match.matchReason}
                              </Badge>
                            </div>
                            
                            <p className="text-sm text-muted-foreground mt-2 line-clamp-2">{match.bio}</p>
                            
                            <div className="flex flex-wrap gap-1 mt-2">
                              {match.interests.slice(0, 3).map((interest) => (
                                <Badge key={interest} variant="secondary" className="text-xs">
                                  {interest}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex justify-end mt-4 pt-3 border-t">
                          {currentStatus === 'not_connected' && (
                            <Button 
                              size="sm" 
                              onClick={() => handleConnect(match.id, match.name)}
                              className="w-24"
                            >
                              <UserPlus className="h-3 w-3 mr-1" />
                              Connect
                            </Button>
                          )}
                          
                          {currentStatus === 'pending' && (
                            <Button 
                              size="sm" 
                              variant="outline" 
                              disabled
                              className="w-24"
                            >
                              <Clock className="h-3 w-3 mr-1" />
                              Pending
                            </Button>
                          )}
                          
                          {currentStatus === 'connected' && (
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => handleMessage(match.name)}
                              className="w-24"
                            >
                              <MessageCircle className="h-3 w-3 mr-1" />
                              Message
                            </Button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
                
                <div className="mt-4 pt-4 border-t">
                  <Link to="/connections">
                    <Button variant="outline" className="w-full">
                      <Users className="h-4 w-4 mr-2" />
                      View All Connections
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Registration Card */}
          <Card>
            <CardHeader>
              <CardTitle>Registration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                {event.price > 0 ? (
                  <div>
                    <span className="text-3xl font-bold">${event.price}</span>
                    <p className="text-sm text-muted-foreground">per person</p>
                  </div>
                ) : (
                  <div>
                    <span className="text-3xl font-bold text-green-600">Free</span>
                    <p className="text-sm text-muted-foreground">registration required</p>
                  </div>
                )}
              </div>
              
              <Button onClick={handleRegister} className="w-full" size="lg">
                <ExternalLink className="h-4 w-4 mr-2" />
                Register Now
              </Button>
              
              <div className="text-xs text-muted-foreground text-center">
                You'll be redirected to the event organizer's registration page
              </div>
            </CardContent>
          </Card>

          {/* Event Details Card */}
          <Card>
            <CardHeader>
              <CardTitle>Event Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <Calendar className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-medium">
                      {new Date(event.date).toLocaleDateString('en-US', {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </p>
                    <p className="text-sm text-muted-foreground">{event.time}</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-medium">{event.location}</p>
                    <p className="text-sm text-muted-foreground">{event.address}</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <User className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-medium">{event.organizer}</p>
                    <p className="text-sm text-muted-foreground">{event.organizerDescription}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Bottom Banner Ad */}
      <div className="mt-8">
        <DynamicBannerAd 
          page="events" 
          showRotateButton={false}
          className="w-full"
        />
      </div>
    </div>
  );
}