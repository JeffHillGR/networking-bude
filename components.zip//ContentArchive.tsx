import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Play,
  ExternalLink,
  ArrowLeft,
  Calendar,
  Clock,
  BookOpen,
  Video,
  Headphones
} from 'lucide-react';
import { Link } from 'react-router-dom';

const FEATURED_CONTENT = [
  {
    id: 1,
    type: 'podcast',
    title: 'Building Meaningful Professional Networks',
    author: 'Career Growth Podcast',
    duration: '32 min',
    thumbnail: 'https://images.unsplash.com/photo-1478737270239-2f02b77fc618?w=400&h=300&fit=crop',
    description: 'Learn strategies for authentic networking that leads to lasting professional relationships.',
    publishedDate: '2025-09-15'
  },
  {
    id: 2,
    type: 'video',
    title: '5 Networking Mistakes That Kill Your Career',
    author: 'LinkedIn Learning',
    duration: '8 min',
    thumbnail: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=400&h=300&fit=crop',
    description: 'Avoid these common networking pitfalls and accelerate your professional growth.',
    publishedDate: '2025-09-14'
  },
  {
    id: 3,
    type: 'article',
    title: 'The Future of Remote Networking',
    author: 'Harvard Business Review',
    duration: '5 min read',
    thumbnail: 'https://images.unsplash.com/photo-1521737711867-e3b97375f902?w=400&h=300&fit=crop',
    description: 'How virtual networking is reshaping professional relationships in the digital age.',
    publishedDate: '2025-09-13'
  },
  {
    id: 4,
    type: 'podcast',
    title: 'Mastering Digital First Impressions',
    author: 'Professional Development Today',
    duration: '24 min',
    thumbnail: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400&h=300&fit=crop',
    description: 'How to make powerful connections in virtual environments and stand out online.',
    publishedDate: '2025-09-12'
  },
  {
    id: 5,
    type: 'video',
    title: 'Body Language for Virtual Meetings',
    author: 'Communication Skills Pro',
    duration: '12 min',
    thumbnail: 'https://images.unsplash.com/photo-1551836022-deb4988cc6c0?w=400&h=300&fit=crop',
    description: 'Master non-verbal communication in video calls and online networking events.',
    publishedDate: '2025-09-11'
  },
  {
    id: 6,
    type: 'article',
    title: 'Building Your Personal Brand Through Networking',
    author: 'Entrepreneur Magazine',
    duration: '7 min read',
    thumbnail: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=400&h=300&fit=crop',
    description: 'Strategies for developing and communicating your unique professional identity.',
    publishedDate: '2025-09-10'
  }
];

const getContentTypeIcon = (type: string) => {
  switch (type) {
    case 'podcast':
      return <Headphones className="h-4 w-4" />;
    case 'video':
      return <Video className="h-4 w-4" />;
    case 'article':
      return <BookOpen className="h-4 w-4" />;
    default:
      return <Play className="h-4 w-4" />;
  }
};

const getContentTypeBadgeVariant = (type: string) => {
  switch (type) {
    case 'podcast':
      return 'secondary';
    case 'video':
      return 'default';
    case 'article':
      return 'outline';
    default:
      return 'default';
  }
};

export function ContentArchive() {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Link to="/dashboard">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl mb-2">Content Archive</h1>
          <p className="text-muted-foreground">
            Browse all featured content from our professional development library
          </p>
        </div>
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {FEATURED_CONTENT.map((content) => (
          <Card key={content.id} className="cursor-pointer hover:shadow-md transition-shadow">
            <CardContent className="p-0">
              <div className="relative">
                <img 
                  src={content.thumbnail} 
                  alt={content.title}
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                    <Play className="h-6 w-6 text-primary-foreground fill-current" />
                  </div>
                </div>
                <div className="absolute top-3 left-3">
                  <Badge variant={getContentTypeBadgeVariant(content.type)} className="flex items-center space-x-1">
                    {getContentTypeIcon(content.type)}
                    <span className="capitalize">{content.type}</span>
                  </Badge>
                </div>
                <div className="absolute top-3 right-3">
                  <Button variant="secondary" size="icon" className="h-8 w-8">
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div className="p-4 space-y-3">
                <h3 className="font-medium leading-tight">{content.title}</h3>
                <p className="text-sm text-muted-foreground line-clamp-2">{content.description}</p>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <span>{content.author}</span>
                    <div className="flex items-center space-x-1">
                      <Clock className="h-3 w-3" />
                      <span>{content.duration}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                    <Calendar className="h-3 w-3" />
                    <span>Published {new Date(content.publishedDate).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Load More */}
      <div className="flex justify-center">
        <Button variant="outline">
          Load More Content
        </Button>
      </div>
    </div>
  );
}