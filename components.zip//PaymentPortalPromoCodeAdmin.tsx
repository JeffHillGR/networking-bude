// Admin Promo Code Tab Content for PaymentPortal
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { 
  Plus, 
  Edit, 
  Trash2, 
  Copy, 
  Percent, 
  DollarSign,
  Calendar,
  Users,
  BarChart3,
  Eye,
  EyeOff
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface PromoCode {
  id: string;
  code: string;
  discountType: 'percentage' | 'dollar';
  discountValue: number;
  description: string;
  expirationDate?: string;
  usageLimit?: number;
  usedCount: number;
  isActive: boolean;
  createdDate: string;
  applicablePlans?: string[];
  minimumAmount?: number;
}

interface PromoCodeFormData {
  code: string;
  discountType: 'percentage' | 'dollar';
  discountValue: number;
  description: string;
  expirationDate: string;
  usageLimit: number;
  isActive: boolean;
  applicablePlans: string[];
  minimumAmount: number;
}

interface PromoCodeAdminTabProps {
  promoCodes: PromoCode[];
  promoFormData: PromoCodeFormData;
  setPromoFormData: React.Dispatch<React.SetStateAction<PromoCodeFormData>>;
  showPromoForm: boolean;
  setShowPromoForm: React.Dispatch<React.SetStateAction<boolean>>;
  editingPromo: PromoCode | null;
  setEditingPromo: React.Dispatch<React.SetStateAction<PromoCode | null>>;
  handleCreatePromoCode: () => void;
  handleEditPromoCode: (promo: PromoCode) => void;
  handleDeletePromoCode: (promoId: string) => void;
  handleTogglePromoStatus: (promoId: string) => void;
  copyPromoCodeToClipboard: (code: string) => void;
  formatCurrency: (amount: number) => string;
  formatDate: (dateString: string) => string;
  formatDiscountValue: (promo: PromoCode) => string;
  getPromoCodeStatus: (promo: PromoCode) => string;
  getStatusBadgeVariant: (status: string) => any;
  getStatusLabel: (status: string) => string;
}

const SUBSCRIPTION_PLAN_OPTIONS = [
  { id: 'professional', name: 'BudE Plan' },
  { id: 'enterprise', name: 'BudE+' }
];

export function PromoCodeAdminTab({
  promoCodes,
  promoFormData,
  setPromoFormData,
  showPromoForm,
  setShowPromoForm,
  editingPromo,
  setEditingPromo,
  handleCreatePromoCode,
  handleEditPromoCode,
  handleDeletePromoCode,
  handleTogglePromoStatus,
  copyPromoCodeToClipboard,
  formatCurrency,
  formatDate,
  formatDiscountValue,
  getPromoCodeStatus,
  getStatusBadgeVariant,
  getStatusLabel
}: PromoCodeAdminTabProps) {

  const handleFormCancel = () => {
    setShowPromoForm(false);
    setEditingPromo(null);
    setPromoFormData({
      code: '',
      discountType: 'percentage',
      discountValue: 0,
      description: '',
      expirationDate: '',
      usageLimit: 0,
      isActive: true,
      applicablePlans: [],
      minimumAmount: 0
    });
  };

  const handlePlanToggle = (planId: string) => {
    setPromoFormData(prev => ({
      ...prev,
      applicablePlans: prev.applicablePlans.includes(planId)
        ? prev.applicablePlans.filter(id => id !== planId)
        : [...prev.applicablePlans, planId]
    }));
  };

  return (
    <div className="space-y-6">
      {/* Promo Code Management Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold">Promo Code Management</h2>
          <p className="text-muted-foreground">
            Create and manage discount codes for BudE subscriptions
          </p>
        </div>
        <Button
          onClick={() => setShowPromoForm(true)}
          className="bg-purple-600 hover:bg-purple-700"
        >
          <Plus className="h-4 w-4 mr-2" />
          Create Promo Code
        </Button>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <BarChart3 className="h-8 w-8 text-purple-600" />
              <div>
                <p className="text-2xl font-semibold">{promoCodes.length}</p>
                <p className="text-sm text-muted-foreground">Total Codes</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <Eye className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-2xl font-semibold">
                  {promoCodes.filter(p => p.isActive && getPromoCodeStatus(p) === 'active').length}
                </p>
                <p className="text-sm text-muted-foreground">Active Codes</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <Users className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-2xl font-semibold">
                  {promoCodes.reduce((total, promo) => total + promo.usedCount, 0)}
                </p>
                <p className="text-sm text-muted-foreground">Total Uses</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <Calendar className="h-8 w-8 text-orange-600" />
              <div>
                <p className="text-2xl font-semibold">
                  {promoCodes.filter(p => {
                    if (!p.expirationDate) return false;
                    const expDate = new Date(p.expirationDate);
                    const now = new Date();
                    const daysUntilExpiry = Math.ceil((expDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
                    return daysUntilExpiry <= 7 && daysUntilExpiry > 0;
                  }).length}
                </p>
                <p className="text-sm text-muted-foreground">Expiring Soon</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Create/Edit Promo Code Form */}
      {showPromoForm && (
        <Card className="border-purple-200">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Plus className="h-5 w-5" />
              <span>{editingPromo ? 'Edit Promo Code' : 'Create New Promo Code'}</span>
            </CardTitle>
            <CardDescription>
              {editingPromo ? 'Modify the existing promo code details' : 'Set up a new discount code for BudE subscriptions'}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Promo Code */}
              <div className="space-y-2">
                <Label htmlFor="promoCode">Promo Code *</Label>
                <Input
                  id="promoCode"
                  value={promoFormData.code}
                  onChange={(e) => setPromoFormData(prev => ({ ...prev, code: e.target.value.toUpperCase() }))}
                  placeholder="e.g., WELCOME20"
                  className="font-mono"
                />
              </div>

              {/* Discount Type */}
              <div className="space-y-2">
                <Label>Discount Type *</Label>
                <div className="flex space-x-2">
                  <Button
                    type="button"
                    variant={promoFormData.discountType === 'percentage' ? 'default' : 'outline'}
                    onClick={() => setPromoFormData(prev => ({ ...prev, discountType: 'percentage' }))}
                    className="flex-1"
                  >
                    <Percent className="h-4 w-4 mr-2" />
                    Percentage
                  </Button>
                  <Button
                    type="button"
                    variant={promoFormData.discountType === 'dollar' ? 'default' : 'outline'}
                    onClick={() => setPromoFormData(prev => ({ ...prev, discountType: 'dollar' }))}
                    className="flex-1"
                  >
                    <DollarSign className="h-4 w-4 mr-2" />
                    Dollar Amount
                  </Button>
                </div>
              </div>

              {/* Discount Value */}
              <div className="space-y-2">
                <Label htmlFor="discountValue">
                  Discount Value * {promoFormData.discountType === 'percentage' ? '(%)' : '($)'}
                </Label>
                <Input
                  id="discountValue"
                  type="number"
                  value={promoFormData.discountValue}
                  onChange={(e) => setPromoFormData(prev => ({ ...prev, discountValue: parseFloat(e.target.value) || 0 }))}
                  placeholder={promoFormData.discountType === 'percentage' ? '20' : '5.00'}
                  min="0"
                  max={promoFormData.discountType === 'percentage' ? '100' : undefined}
                  step={promoFormData.discountType === 'percentage' ? '1' : '0.01'}
                />
              </div>

              {/* Expiration Date */}
              <div className="space-y-2">
                <Label htmlFor="expirationDate">Expiration Date (Optional)</Label>
                <Input
                  id="expirationDate"
                  type="date"
                  value={promoFormData.expirationDate}
                  onChange={(e) => setPromoFormData(prev => ({ ...prev, expirationDate: e.target.value }))}
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>

              {/* Usage Limit */}
              <div className="space-y-2">
                <Label htmlFor="usageLimit">Usage Limit (0 = Unlimited)</Label>
                <Input
                  id="usageLimit"
                  type="number"
                  value={promoFormData.usageLimit}
                  onChange={(e) => setPromoFormData(prev => ({ ...prev, usageLimit: parseInt(e.target.value) || 0 }))}
                  placeholder="100"
                  min="0"
                />
              </div>

              {/* Minimum Amount */}
              <div className="space-y-2">
                <Label htmlFor="minimumAmount">Minimum Order Amount ($)</Label>
                <Input
                  id="minimumAmount"
                  type="number"
                  value={promoFormData.minimumAmount}
                  onChange={(e) => setPromoFormData(prev => ({ ...prev, minimumAmount: parseFloat(e.target.value) || 0 }))}
                  placeholder="0.00"
                  min="0"
                  step="0.01"
                />
              </div>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Input
                id="description"
                value={promoFormData.description}
                onChange={(e) => setPromoFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="e.g., 20% off first 3 months"
              />
            </div>

            {/* Applicable Plans */}
            <div className="space-y-2">
              <Label>Applicable Plans (Leave empty for all plans)</Label>
              <div className="flex flex-wrap gap-2">
                {SUBSCRIPTION_PLAN_OPTIONS.map((plan) => (
                  <Button
                    key={plan.id}
                    type="button"
                    variant={promoFormData.applicablePlans.includes(plan.id) ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => handlePlanToggle(plan.id)}
                  >
                    {plan.name}
                  </Button>
                ))}
              </div>
            </div>

            {/* Status Toggle */}
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="isActive"
                checked={promoFormData.isActive}
                onChange={(e) => setPromoFormData(prev => ({ ...prev, isActive: e.target.checked }))}
                className="rounded border-gray-300"
              />
              <Label htmlFor="isActive">Active (users can apply this code)</Label>
            </div>

            <Separator />

            {/* Form Actions */}
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={handleFormCancel}>
                Cancel
              </Button>
              <Button onClick={handleCreatePromoCode} className="bg-purple-600 hover:bg-purple-700">
                {editingPromo ? 'Update Code' : 'Create Code'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Existing Promo Codes */}
      <Card>
        <CardHeader>
          <CardTitle>Existing Promo Codes</CardTitle>
          <CardDescription>
            Manage all discount codes and view their performance
          </CardDescription>
        </CardHeader>
        <CardContent>
          {promoCodes.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No promo codes created yet.</p>
              <Button
                onClick={() => setShowPromoForm(true)}
                className="mt-4 bg-purple-600 hover:bg-purple-700"
              >
                Create Your First Promo Code
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {promoCodes.map((promo) => {
                const status = getPromoCodeStatus(promo);
                return (
                  <Card key={promo.id} className="border">
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center space-x-3">
                            <code className="bg-muted px-2 py-1 rounded text-sm font-mono">
                              {promo.code}
                            </code>
                            <Badge variant={getStatusBadgeVariant(status)}>
                              {getStatusLabel(status)}
                            </Badge>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => copyPromoCodeToClipboard(promo.code)}
                              className="h-6 w-6 p-0"
                            >
                              <Copy className="h-3 w-3" />
                            </Button>
                          </div>
                          
                          <p className="text-sm font-medium">{promo.description}</p>
                          
                          <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                            <span>Discount: {formatDiscountValue(promo)}</span>
                            {promo.expirationDate && (
                              <span>Expires: {formatDate(promo.expirationDate)}</span>
                            )}
                            {promo.usageLimit && promo.usageLimit > 0 && (
                              <span>
                                Usage: {promo.usedCount}/{promo.usageLimit}
                              </span>
                            )}
                            {!promo.usageLimit || promo.usageLimit === 0 && (
                              <span>Usage: {promo.usedCount} (unlimited)</span>
                            )}
                            {promo.minimumAmount && promo.minimumAmount > 0 && (
                              <span>Min: {formatCurrency(promo.minimumAmount)}</span>
                            )}
                          </div>

                          {promo.applicablePlans && promo.applicablePlans.length > 0 && (
                            <div className="flex items-center space-x-2">
                              <span className="text-xs text-muted-foreground">Plans:</span>
                              <div className="flex space-x-1">
                                {promo.applicablePlans.map((planId) => {
                                  const plan = SUBSCRIPTION_PLAN_OPTIONS.find(p => p.id === planId);
                                  return (
                                    <Badge key={planId} variant="outline" className="text-xs">
                                      {plan?.name || planId}
                                    </Badge>
                                  );
                                })}
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="flex items-center space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleTogglePromoStatus(promo.id)}
                            className={promo.isActive ? "text-orange-600" : "text-green-600"}
                          >
                            {promo.isActive ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditPromoCode(promo)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeletePromoCode(promo.id)}
                            className="text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}