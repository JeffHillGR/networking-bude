import { MapPin, Building2 } from 'lucide-react';

export function GrandRapidsBanner() {
  return (
    <div className="relative h-40 md:h-56 rounded-lg overflow-hidden mb-6">
      <img 
        src="https://images.unsplash.com/photo-1660147163624-807c63373773?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxHcmFuZCUyMFJhcGlkcyUyME1pY2hpZ2FuJTIwZG93bnRvd24lMjBza3lsaW5lfGVufDF8fHx8MTc1ODA0OTY3Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral" 
        alt="Downtown Grand Rapids, Michigan skyline"
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent"></div>
      <div className="absolute bottom-6 left-6 right-6 text-white">
        <div className="flex items-center space-x-2 mb-2">
          <MapPin className="h-5 w-5" />
          <span className="text-sm opacity-90">Your networking hub</span>
        </div>
        <h2 className="text-2xl md:text-3xl mb-2">
          Welcome to Grand Rapids
        </h2>
        <div className="flex items-center space-x-2 mb-2">
          <Building2 className="h-4 w-4 opacity-90" />
          <span className="text-sm opacity-90">Michigan's second-largest city</span>
        </div>
        <p className="text-sm opacity-90">
          Discover professional connections in West Michigan's business hub
        </p>
      </div>
    </div>
  );
}