import { NavLink, useLocation } from 'react-router-dom';
import { 
  Home, 
  Calendar, 
  Heart, 
  MessageCircle, 
  User,
  Smartphone
} from 'lucide-react';

const primaryNavigation = [
  { name: 'Dashboard', href: '/dashboard', icon: Home, label: 'Home' },
  { name: 'Events', href: '/events', icon: Calendar, label: 'Events' },
  { name: 'Connections', href: '/connections', icon: Heart, label: 'Connections' },
  { name: 'Messages', href: '/messenger', icon: MessageCircle, label: 'Messages' },
  { name: 'Profile', href: '/profile/current', icon: User, label: 'Profile' },
];

interface MobileBottomNavProps {
  forceMobileView?: boolean;
  isPreviewMode?: boolean;
}

export function MobileBottomNav({ forceMobileView = false, isPreviewMode = false }: MobileBottomNavProps = {}) {
  const location = useLocation();

  // Check if we're in mobile preview mode based on URL params
  const urlParams = new URLSearchParams(window.location.search);
  const isMobilePreview = urlParams.get('mobile') === 'true' || forceMobileView || isPreviewMode;

  return (
    <div className={`${forceMobileView ? 'absolute' : 'fixed'} bottom-0 left-0 right-0 bg-card border-t shadow-lg ${forceMobileView ? 'block z-50' : 'block md:hidden z-50'}`}>
      {/* Mobile Preview Mode Indicator */}
      {isMobilePreview && (
        <div className="bg-primary/10 px-3 py-1 text-center border-b">
          <div className="flex items-center justify-center space-x-2">
            <Smartphone className="h-3 w-3 text-primary" />
            <span className="text-xs font-medium text-primary">Mobile Preview Mode</span>
          </div>
        </div>
      )}

      {/* Main Navigation - Only the 5 primary buttons */}
      <nav className="flex justify-around items-center py-2 px-2">
        {primaryNavigation.map((item) => {
          const isActive = location.pathname === item.href || 
            (item.href === '/profile/current' && location.pathname.startsWith('/profile/'));
          
          return (
            <NavLink
              key={item.name}
              to={item.href}
              className={`
                flex flex-col items-center justify-center py-3 px-3 rounded-xl min-w-[60px] min-h-[64px] 
                active:scale-95 touch-target relative
                ${isActive 
                  ? 'text-white bg-bude-green-dark shadow-sm border-3 border-bude-yellow' 
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent/50 transition-all duration-150 ease-out'
                }
              `}
              aria-label={`Navigate to ${item.name}`}
            >
              <item.icon className={`h-5 w-5 mb-1 ${isActive ? 'fill-current' : ''}`} />
              <span className="text-xs font-medium leading-tight">{item.label}</span>
            </NavLink>
          );
        })}
      </nav>

      {/* Safe area padding for phones with home indicators */}
      <div className="h-safe-area-inset-bottom bg-card"></div>
    </div>
  );
}