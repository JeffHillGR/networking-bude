import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Checkbox } from './ui/checkbox';
import { Card, CardContent } from './ui/card';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';
import { 
  Users, 
  Send, 
  ArrowRight,
  Lightbulb,
  X
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface User {
  id: number;
  name: string;
  title: string;
  company: string;
  avatar: string;
  image: string;
  interests: string[];
  commonInterests?: string[];
}

interface SuggestConnectionProps {
  isOpen: boolean;
  onClose: () => void;
  suggestedUser: User;
  availableConnections: User[];
}

export function SuggestConnection({ isOpen, onClose, suggestedUser, availableConnections }: SuggestConnectionProps) {
  const [selectedConnections, setSelectedConnections] = useState<number[]>([]);
  const [message, setMessage] = useState(
    "Hi! I thought you two should connect - I think you'd find some common interests and goals. Both of you are amazing professionals and I believe you could really benefit from knowing each other!"
  );
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleConnectionToggle = (userId: number) => {
    setSelectedConnections(prev => 
      prev.includes(userId) 
        ? prev.filter(id => id !== userId)
        : [...prev, userId]
    );
  };

  const handleSubmit = async () => {
    if (selectedConnections.length === 0) {
      toast.error('Please select at least one BudE to suggest this connection to');
      return;
    }

    if (!message.trim()) {
      toast.error('Please add a message explaining why they should connect');
      return;
    }

    setIsSubmitting(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const selectedUsers = availableConnections.filter(user => 
        selectedConnections.includes(user.id)
      );
      
      toast.success(
        `Connection suggestion sent to ${selectedUsers.length} BudE${selectedUsers.length > 1 ? 's' : ''}! 🤝`
      );
      
      // Reset form
      setSelectedConnections([]);
      setMessage(
        "Hi! I thought you two should connect - I think you'd find some common interests and goals. Both of you are amazing professionals and I believe you could really benefit from knowing each other!"
      );
      onClose();
      
    } catch (error) {
      toast.error('Failed to send suggestion. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const selectedUsers = availableConnections.filter(user => 
    selectedConnections.includes(user.id)
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            Suggest Connection
          </DialogTitle>
          <DialogDescription>
            Suggest <strong>{suggestedUser.name}</strong> to your other BudE connections
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Who you're suggesting */}
          <div className="bg-muted/50 p-4 rounded-lg">
            <div className="flex items-center gap-3 mb-2">
              <Lightbulb className="h-4 w-4 text-amber-500" />
              <span className="text-sm font-medium">You're suggesting:</span>
            </div>
            <div className="flex items-center gap-3">
              <Avatar className="w-10 h-10">
                <AvatarImage src={suggestedUser.image} alt={suggestedUser.name} />
                <AvatarFallback>{suggestedUser.avatar}</AvatarFallback>
              </Avatar>
              <div>
                <div className="font-medium">{suggestedUser.name}</div>
                <div className="text-sm text-muted-foreground">
                  {suggestedUser.title} at {suggestedUser.company}
                </div>
              </div>
            </div>
            <div className="flex flex-wrap gap-1 mt-2">
              {suggestedUser.interests.slice(0, 4).map((interest) => (
                <Badge key={interest} variant="outline" className="text-xs">
                  {interest}
                </Badge>
              ))}
              {suggestedUser.interests.length > 4 && (
                <Badge variant="outline" className="text-xs">
                  +{suggestedUser.interests.length - 4} more
                </Badge>
              )}
            </div>
          </div>

          {/* Arrow indicating suggestion direction */}
          <div className="flex justify-center">
            <div className="flex items-center gap-2 text-muted-foreground">
              <ArrowRight className="h-4 w-4" />
              <span className="text-sm">Suggest to your BudE's</span>
              <ArrowRight className="h-4 w-4" />
            </div>
          </div>

          {/* Available connections to suggest to */}
          <div>
            <h4 className="font-medium mb-3">
              Select BudE's to suggest this connection to:
            </h4>
            <ScrollArea className="max-h-48 border rounded-lg">
              <div className="space-y-2 p-3">
                {availableConnections.map((user) => (
                  <div key={user.id}>
                    <Card className={`cursor-pointer transition-colors ${
                      selectedConnections.includes(user.id) 
                        ? 'ring-2 ring-primary bg-primary/5' 
                        : 'hover:bg-muted/50'
                    }`}>
                      <CardContent className="p-3">
                        <div className="flex items-center gap-3">
                          <Checkbox
                            checked={selectedConnections.includes(user.id)}
                            onCheckedChange={() => handleConnectionToggle(user.id)}
                          />
                          <Avatar className="w-8 h-8 flex-shrink-0">
                            <AvatarImage src={user.image} alt={user.name} />
                            <AvatarFallback className="text-xs">{user.avatar}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="font-medium text-sm">{user.name}</div>
                            <div className="text-xs text-muted-foreground truncate">
                              {user.title} at {user.company}
                            </div>
                          </div>
                          {user.commonInterests && user.commonInterests.length > 0 && (
                            <div className="flex items-center gap-1 flex-shrink-0">
                              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                              <span className="text-xs text-muted-foreground">
                                {user.commonInterests.length} shared
                              </span>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </div>

          {/* Preview of selected connections */}
          {selectedUsers.length > 0 && (
            <div className="bg-green-50 dark:bg-green-950/20 p-4 rounded-lg border border-green-200 dark:border-green-800">
              <div className="flex items-center gap-2 mb-2">
                <Send className="h-4 w-4 text-green-600" />
                <span className="text-sm font-medium text-green-700 dark:text-green-300">
                  Will be suggested to ({selectedUsers.length}):
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                {selectedUsers.map((user) => (
                  <div key={user.id} className="flex items-center gap-2 bg-white dark:bg-green-900/20 px-2 py-1 rounded-md border border-green-200 dark:border-green-700">
                    <Avatar className="w-4 h-4">
                      <AvatarImage src={user.image} alt={user.name} />
                      <AvatarFallback className="text-xs">{user.avatar}</AvatarFallback>
                    </Avatar>
                    <span className="text-xs font-medium text-green-700 dark:text-green-300">
                      {user.name}
                    </span>
                    <button
                      onClick={() => handleConnectionToggle(user.id)}
                      className="text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          <Separator />

          {/* Message customization */}
          <div>
            <label className="text-sm font-medium mb-2 block">
              Suggestion Message:
            </label>
            <Textarea
              placeholder="Tell them why you think they should connect..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="min-h-24 resize-none"
              maxLength={500}
            />
            <div className="text-xs text-muted-foreground mt-1 text-right">
              {message.length}/500 characters
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit}
            disabled={selectedConnections.length === 0 || !message.trim() || isSubmitting}
            className="min-w-32"
          >
            {isSubmitting ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Sending...
              </div>
            ) : (
              <>
                <Send className="h-4 w-4 mr-2" />
                Send Suggestion{selectedConnections.length > 1 ? 's' : ''}
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}