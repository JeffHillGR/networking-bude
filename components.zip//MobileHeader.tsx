import { useState } from 'react';
import { useLocation, NavLink } from 'react-router-dom';
import { Menu, X, Settings, LogOut } from 'lucide-react';
import { Button } from './ui/button';
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle, SheetDescription } from './ui/sheet';
import { toast } from 'sonner@2.0.3';
import budeLogo from 'figma:asset/3e43a07a7faa73f2f417a9074a180615c3828a87.png';

const secondaryNavigation = [
  { name: 'Settings', href: '/settings', icon: Settings },
  { name: 'Payment Portal', href: '/payment-portal', icon: Settings },
  { name: 'Content Archive', href: '/content-archive', icon: Settings },
];

interface MobileHeaderProps {
  userData: any;
  onLogout: () => void;
}

export function MobileHeader({ userData, onLogout }: MobileHeaderProps) {
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const handleLogout = () => {
    toast.success('Successfully logged out!');
    onLogout();
    setIsOpen(false);
  };

  const getPageTitle = () => {
    switch (location.pathname) {
      case '/dashboard':
        return 'Dashboard';
      case '/events':
        return 'Events';
      case '/connections':
        return 'Connections';
      case '/messenger':
        return 'Messages';
      case '/settings':
        return 'Settings';
      case '/payment-portal':
        return 'Payment Portal';
      case '/content-archive':
        return 'Content Archive';
      default:
        if (location.pathname.startsWith('/profile/')) return 'Profile';
        if (location.pathname.startsWith('/events/')) return 'Event Details';
        if (location.pathname.startsWith('/messenger/')) return 'Conversation';
        return 'Networking BudE';
    }
  };

  return (
    <header className="md:hidden bg-card border-b px-4 py-3 flex items-center justify-between min-h-[60px]">
      {/* Logo and Title */}
      <div className="flex items-center space-x-3 flex-1 min-w-0">
        <img src={budeLogo} alt="Networking BudE" className="h-6 flex-shrink-0" />
        <h1 className="font-semibold text-lg truncate">{getPageTitle()}</h1>
      </div>

      {/* Menu Button - Enhanced touch target */}
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-10 w-10 flex-shrink-0 active:scale-95 transition-transform"
          >
            <Menu className="h-5 w-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="right" className="w-72">
          <SheetHeader>
            <SheetTitle className="flex items-center space-x-3">
              <img src={budeLogo} alt="Networking BudE" className="h-6" />
              <span>Networking BudE</span>
            </SheetTitle>
            <SheetDescription className="sr-only">
              Navigation menu with user account settings, secondary pages, and logout option
            </SheetDescription>
          </SheetHeader>
          
          <div className="flex flex-col h-full pt-6">
            {/* User Info - Touch optimized */}
            <div className="flex items-center space-x-3 p-5 bg-accent rounded-xl mb-6">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                <Settings className="h-6 w-6 text-primary-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">
                  {userData?.name || 
                   (userData?.firstName && userData?.lastName ? `${userData.firstName} ${userData.lastName}` : '') ||
                   userData?.firstName || 
                   userData?.lastName || 
                   'User'}
                </p>
                <p className="text-sm text-muted-foreground truncate">
                  {userData?.jobTitle || userData?.title || 'Professional'}
                </p>
              </div>
            </div>

            {/* Secondary Navigation - Enhanced touch targets */}
            <nav className="flex-1 space-y-2">
              <h3 className="px-3 text-sm font-medium text-muted-foreground mb-4">
                Account & Settings
              </h3>
              {secondaryNavigation.map((item) => {
                const isActive = location.pathname === item.href;
                return (
                  <NavLink
                    key={item.name}
                    to={item.href}
                    onClick={() => setIsOpen(false)}
                    className={`
                      flex items-center px-4 py-4 rounded-xl transition-all duration-200 min-h-[52px]
                      active:scale-98 
                      ${isActive 
                        ? 'bg-bude-green text-white hover:bg-bude-green/90' 
                        : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                      }
                    `}
                  >
                    <item.icon className="h-5 w-5 mr-4 flex-shrink-0" />
                    <span className="font-medium">{item.name}</span>
                  </NavLink>
                );
              })}
            </nav>

            {/* Logout Button - Enhanced touch target */}
            <div className="border-t pt-4">
              <Button
                variant="ghost"
                onClick={handleLogout}
                className="w-full justify-start text-muted-foreground hover:text-foreground hover:bg-accent 
                          py-4 px-4 h-auto min-h-[52px] rounded-xl active:scale-98 transition-all duration-200"
              >
                <LogOut className="h-5 w-5 mr-4" />
                <span className="font-medium">Logout</span>
              </Button>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </header>
  );
}