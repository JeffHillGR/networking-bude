import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { CityBanner } from './CityBanner';
import { NetworkingEventBanner } from './NetworkingEventBanner';
import { DynamicBannerAd } from './DynamicBannerAd';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { 
  Calendar, 
  Users, 
  TrendingUp, 
  MessageCircle, 
  Play,
  ExternalLink,
  Clock,
  MapPin,
  Heart,
  User,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useState } from 'react';
import { useConnectionAccess, useEventAccess, useSubscription } from '../hooks/useSubscription';

const FEATURED_CONTENT = [
  {
    id: 1,
    type: 'podcast',
    title: 'Building Meaningful Professional Networks',
    author: 'Career Growth Podcast',
    duration: '32 min',
    thumbnail: 'https://images.unsplash.com/photo-1478737270239-2f02b77fc618?w=400&h=300&fit=crop',
    description: 'Learn strategies for authentic networking that leads to lasting professional relationships.'
  },
  {
    id: 2,
    type: 'video',
    title: '5 Networking Mistakes That Kill Your Career',
    author: 'LinkedIn Learning',
    duration: '8 min',
    thumbnail: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=400&h=300&fit=crop',
    description: 'Avoid these common networking pitfalls and accelerate your professional growth.'
  },
  {
    id: 3,
    type: 'article',
    title: 'The Future of Remote Networking',
    author: 'Harvard Business Review',
    duration: '5 min read',
    thumbnail: 'https://images.unsplash.com/photo-1521737711867-e3b97375f902?w=400&h=300&fit=crop',
    description: 'How virtual networking is reshaping professional relationships in the digital age.'
  }
];

const UPCOMING_EVENTS = [
  {
    id: 1,
    title: 'Creative Mornings Design Session',
    date: '2025-09-20',
    time: '8:00 AM - 10:00 AM',
    location: 'Bamboo Grand Rapids',
    attendees: 45,
    type: 'In-Person'
  },
  {
    id: 3,
    title: 'StartGarden Entrepreneur Pitch',
    date: '2025-09-25',
    time: '6:30 PM - 9:00 PM',
    location: 'StartGarden',
    attendees: 80,
    type: 'In-Person'
  },
  {
    id: 4,
    title: 'Athena Leadership Workshop',
    date: '2025-09-28',
    time: '9:00 AM - 5:00 PM',
    location: 'Grand Rapids Art Museum',
    attendees: 150,
    type: 'In-Person'
  }
];

const RECENT_CONNECTIONS = [
  {
    id: 1,
    name: 'Alex Chen',
    title: 'Senior Developer at Google',
    image: 'https://images.unsplash.com/photo-1758599543154-76ec1c4257df?w=64&h=64&fit=crop&crop=face',
    commonInterests: ['Technology', 'AI/ML'],
    matchScore: 95,
    mutual: 3
  },
  {
    id: 2,
    name: 'Maria Rodriguez',
    title: 'Marketing Director at Spotify',
    image: 'https://images.unsplash.com/photo-1756699064606-36ddb087c3c7?w=64&h=64&fit=crop&crop=face',
    commonInterests: ['Marketing', 'Media'],
    matchScore: 88,
    mutual: 5
  },
  {
    id: 3,
    name: 'David Kim',
    title: 'Product Manager at Meta',
    image: 'https://images.unsplash.com/photo-1648129876012-3e37918d0a07?w=64&h=64&fit=crop&crop=face',
    commonInterests: ['Product Management', 'Design'],
    matchScore: 92,
    mutual: 2
  }
];



interface DashboardProps {
  userData?: any;
}

export function Dashboard({ userData }: DashboardProps) {
  const [currentContentIndex, setCurrentContentIndex] = useState(0);

  // Subscription hooks for feature access
  const { canConnect, requireConnectionUpgrade } = useConnectionAccess();
  const { canAccessEvent, requireEventUpgrade } = useEventAccess();
  const { isAdminBypass, showUpgradePrompt } = useSubscription();

  // Extract first name from userData (supporting both old and new formats)
  const getFirstName = () => {
    if (userData?.firstName) {
      return userData.firstName;
    }
    if (userData?.name) {
      return userData.name.split(' ')[0];
    }
    return 'there';
  };

  const firstName = getFirstName();
  
  // Check if this is a returning user (has existing session data)
  const isReturningUser = userData && (userData.firstName || userData.name);

  const handlePreviousContent = () => {
    setCurrentContentIndex((prev) => 
      prev === 0 ? FEATURED_CONTENT.length - 1 : prev - 1
    );
  };

  const handleNextContent = () => {
    setCurrentContentIndex((prev) => 
      prev === FEATURED_CONTENT.length - 1 ? 0 : prev + 1
    );
  };

  // Use the subscription hook's built-in developer mode detection
  const isDeveloperMode = isAdminBypass;

  // Debug logging for development
  if (process.env.NODE_ENV === 'development') {
    console.log('🔍 Dashboard Debug:', {
      isAdminBypass,
      isDeveloperMode,
      canConnect: canConnect(),
      canAccessEvent: canAccessEvent(''),
      urlParams: window.location.search,
      developerMode: localStorage.getItem('networkingbude_developer_mode'),
      permanentDev: localStorage.getItem('networking_bude_permanent_dev'),
      sessionEditing: sessionStorage.getItem('networking-bude-editing')
    });
  }

  // Handle restricted button clicks
  const handleConnectionsViewAll = (e: React.MouseEvent) => {
    // In developer mode, allow full access without prompts
    if (isDeveloperMode) {
      return; // Let the navigation proceed normally
    }
    
    // In demo/admin mode (but not dev mode), show upgrade prompt to demonstrate subscription flow
    if (isAdminBypass) {
      e.preventDefault();
      showUpgradePrompt('connections', 'to view all potential connections and unlock advanced filtering');
      return;
    }
    
    // Regular subscription check for non-admin users
    if (!canConnect()) {
      e.preventDefault();
      requireConnectionUpgrade();
      return;
    }
  };

  const handleEventsViewAll = (e: React.MouseEvent) => {
    // In developer mode, allow full access without prompts
    if (isDeveloperMode) {
      return; // Let the navigation proceed normally
    }
    
    // In demo/admin mode (but not dev mode), show upgrade prompt to demonstrate subscription flow
    if (isAdminBypass) {
      e.preventDefault();
      showUpgradePrompt('events', 'to view all events and RSVP to exclusive networking opportunities');
      return;
    }
    
    // Regular subscription check for non-admin users
    if (!canAccessEvent('')) {
      e.preventDefault();
      requireEventUpgrade();
      return;
    }
  };

  const handleEventClick = (e: React.MouseEvent, eventId: number) => {
    // In developer mode, allow full access
    if (isDeveloperMode) {
      return; // Let the navigation proceed normally
    }
    
    if (!canAccessEvent('')) {
      e.preventDefault();
      requireEventUpgrade();
      return;
    }
  };

  const currentContent = FEATURED_CONTENT[currentContentIndex];

  return (
    <div className="mobile-container mobile-content-spacing">
      {/* Admin/Developer Mode Indicator */}
      {isAdminBypass && (
        <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded-lg p-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-sm font-medium text-green-700 dark:text-green-300">
              {isDeveloperMode ? '🔧 Developer Mode Active' : '🔓 Admin Demo Mode Active'}
            </span>
            <span className="text-xs text-green-600 dark:text-green-400">
              {isDeveloperMode 
                ? '(Full access unlocked for development)' 
                : '(Connections unlocked for demo - "View All" buttons still show upgrade prompt)'
              }
            </span>
          </div>
        </div>
      )}
      
      {/* Networking Event Banner */}
      <NetworkingEventBanner />

      {/* Header - Mobile optimized */}
      <div>
        <h1 className="mobile-text-lg mb-2">
          {(() => {
            const hour = new Date().getHours();
            const timeGreeting = hour >= 5 && hour < 12 
              ? "Good morning" 
              : hour >= 12 && hour < 18 
                ? "Good afternoon" 
                : "Good evening";
            
            // Get first name from onboarding/profile data with fallbacks
            const firstNameFromData = userData?.firstName || 
              (userData?.name ? userData.name.split(' ')[0] : '') || 
              'there';
            
            return isReturningUser 
              ? `${timeGreeting}, ${firstNameFromData}, welcome back!`
              : `${timeGreeting}, ${firstNameFromData}!`;
          })()}
        </h1>
        <p className="text-muted-foreground mobile-text-sm">
          Here's what's happening in your professional network today.
        </p>
      </div>

      {/* Stats Overview - Compact Mobile optimized grid */}
      <div className="responsive-grid grid-cols-2 md:grid-cols-4 mb-4">
        <Card className="p-3">
          <CardContent className="p-0">
            <div className="flex items-center space-x-2">
              <div className="p-1.5 bg-primary/10 rounded-md">
                <Users className="h-4 w-4 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-lg font-semibold">47</p>
                <p className="text-xs text-muted-foreground">New Connections</p>
                <p className="text-xs text-bude-green-dark">+24% this week</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="p-3">
          <CardContent className="p-0">
            <div className="flex items-center space-x-2">
              <div className="p-1.5 bg-primary/10 rounded-md">
                <Calendar className="h-4 w-4 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-lg font-semibold">8</p>
                <p className="text-xs text-muted-foreground">Upcoming Events</p>
                <p className="text-xs text-bude-green-dark">3 this week</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="p-3">
          <CardContent className="p-0">
            <div className="flex items-center space-x-2">
              <div className="p-1.5 bg-primary/10 rounded-md">
                <MessageCircle className="h-4 w-4 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-lg font-semibold">12</p>
                <p className="text-xs text-muted-foreground">Active Conversations</p>
                <p className="text-xs text-bude-green-dark">89% response rate</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="p-3">
          <CardContent className="p-0">
            <div className="flex items-center space-x-2">
              <div className="p-1.5 bg-primary/10 rounded-md">
                <TrendingUp className="h-4 w-4 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-lg font-semibold">342</p>
                <p className="text-xs text-muted-foreground">Profile Views</p>
                <p className="text-xs text-bude-green-dark">+67% this month</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mobile-content-spacing">
        {/* Featured Content */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="font-bold">Featured Content</CardTitle>
                <CardDescription>
                  Curated content to help you grow professionally
                </CardDescription>
              </div>
              <div className="flex items-center space-x-2">
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={handlePreviousContent}
                  className="touch-target touch-active"
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <span className="text-sm text-muted-foreground">
                  {currentContentIndex + 1} of {FEATURED_CONTENT.length}
                </span>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={handleNextContent}
                  className="touch-target touch-active"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="mobile-card border hover:bg-accent/50 transition-colors cursor-pointer touch-active">
              <div className="flex flex-col md:flex-row md:space-x-4 space-y-3 md:space-y-0">
                <div className="relative flex-shrink-0">
                  <img 
                    src={currentContent.thumbnail} 
                    alt={currentContent.title}
                    className="w-full md:w-32 h-32 md:h-20 rounded-lg object-cover"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-16 h-16 md:w-12 md:h-12 bg-primary rounded-full flex items-center justify-center touch-target touch-active">
                      <Play className="h-8 w-8 md:h-6 md:w-6 text-primary-foreground fill-current" />
                    </div>
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium mb-2 mobile-text-base">{currentContent.title}</h4>
                  <p className="mobile-text-sm text-muted-foreground mb-3 line-clamp-2">{currentContent.description}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2 mobile-text-sm text-muted-foreground">
                      <span className="truncate">{currentContent.author}</span>
                      <span>•</span>
                      <span>{currentContent.duration}</span>
                    </div>
                    <Button variant="ghost" size="icon" className="touch-target touch-active">
                      <ExternalLink className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Content indicators */}
            <div className="flex justify-center space-x-2 mt-4">
              {FEATURED_CONTENT.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentContentIndex(index)}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    index === currentContentIndex 
                      ? 'bg-primary' 
                      : 'bg-muted-foreground/30 hover:bg-muted-foreground/50'
                  }`}
                />
              ))}
            </div>
            
            {/* Link to past entries */}
            <div className="flex justify-center mt-4">
              <Link to="/content-archive">
                <Button variant="ghost" size="sm" className="text-sm text-muted-foreground hover:text-foreground">
                  View entries from the past
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        {/* Recent Connections */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="font-bold">Step 1: Check Out Your Potential Connections (Find a BudE or two)</CardTitle>
              <Link to="/connections" onClick={handleConnectionsViewAll}>
                <Button variant="ghost" size="sm">View All</Button>
              </Link>
            </div>
            <CardDescription>
              People you might want to connect with
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {RECENT_CONNECTIONS.map((match) => (
                <div key={match.id} className="p-4 rounded-lg border hover:bg-accent/50 transition-colors space-y-3">
                  {/* Header with avatar and action button */}
                  <div className="flex items-start justify-between">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={match.image} alt={match.name} />
                      <AvatarFallback>
                        {match.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <Link to={`/profile/${match.id}`}>
                      <Button variant="ghost" size="sm">
                        <User className="h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                  
                  {/* Name and title */}
                  <div className="space-y-1">
                    <p className="font-medium leading-tight">{match.name}</p>
                    <p className="text-sm text-muted-foreground leading-tight">{match.title}</p>
                  </div>
                  
                  {/* Match metrics */}
                  <div className="flex flex-col gap-1.5">
                    <div className="flex items-center space-x-1">
                      <Heart className="h-3 w-3 text-red-500 flex-shrink-0" />
                      <span className="text-xs text-muted-foreground">{match.matchScore}% match</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Users className="h-3 w-3 text-blue-500 flex-shrink-0" />
                      <span className="text-xs text-muted-foreground">{match.mutual} mutual connections</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Events */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="font-bold">Step 2: See What Events Are Coming Up</CardTitle>
              <Link to="/events" onClick={handleEventsViewAll}>
                <Button variant="ghost" size="sm">View All Events</Button>
              </Link>
            </div>
            <CardDescription>
              Networking events happening near you that you can go to together
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {UPCOMING_EVENTS.map((event) => (
                <Link key={event.id} to={`/events/${event.id}`} onClick={(e) => handleEventClick(e, event.id)}>
                  <Card className="cursor-pointer hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="space-y-2">
                        <Badge variant={event.type === 'Virtual' ? 'secondary' : 'default'}>
                          {event.type}
                        </Badge>
                        <h4 className="font-medium">{event.title}</h4>
                        <div className="space-y-1 text-sm text-muted-foreground">
                          <div className="flex items-center space-x-1">
                            <Calendar className="h-3 w-3" />
                            <span>{new Date(event.date).toLocaleDateString()}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Clock className="h-3 w-3" />
                            <span>{event.time}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <MapPin className="h-3 w-3" />
                            <span>{event.location}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Users className="h-3 w-3" />
                            <span>{event.attendees} attending</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Dynamic Banner Ad */}
      <DynamicBannerAd 
        page="dashboard" 
        showRotateButton={isDeveloperMode || isAdminBypass}
        isAdminMode={isDeveloperMode || isAdminBypass}
      />
    </div>
  );
}