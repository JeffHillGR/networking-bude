import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Switch } from './ui/switch';
import { Separator } from './ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Calendar } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { 
  User, 
  Lock, 
  Bell, 
  Eye, 
  Shield, 
  Upload,
  X,
  Save,
  Trash2,
  CreditCard,
  ArrowRight,
  Calendar as CalendarIcon,
  MapPin,
  Plane,
  Scale,
  FileText
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { format } from 'date-fns';
import { PhotoUpload } from './PhotoUpload';

const INTERESTS = [
  'Technology', 'Marketing', 'Finance', 'Design', 'Sales', 'HR',
  'Data Science', 'Engineering', 'Consulting',
  'Healthcare', 'Education', 'Real Estate', 'Legal', 'Media',
  'Startup', 'AI/ML', 'Blockchain', 'Sustainability', 'Leadership'
];

const INDUSTRIES = [
  'Technology & Software', 'Healthcare & Medical', 'Financial Services', 'Education',
  'Manufacturing', 'Retail & E-commerce', 'Consulting', 'Real Estate',
  'Media & Entertainment', 'Non-profit', 'Government', 'Energy & Utilities',
  'Transportation & Logistics', 'Hospitality & Tourism', 'Legal Services',
  'Construction', 'Agriculture', 'Telecommunications', 'Automotive', 'Other'
];

const GENDER_PREFERENCES = [
  'No preference', 'Women', 'Men', 'Non-binary', 'Prefer not to say'
];

const RADIUS_OPTIONS = [
  { value: 'under25', label: 'Less than 25 miles' },
  { value: '25', label: '25 miles' },
  { value: '50', label: '50 miles' },
  { value: '100', label: '100 miles' },
  { value: 'anywhere', label: 'Anywhere in my state/region' }
];

const POPULAR_ASSOCIATIONS = [
  'Toastmasters International', 'Chamber of Commerce', 'Rotary Club', 'Kiwanis Club',
  'Women in Business', 'Young Professionals Network', 'Industry Trade Associations',
  'Alumni Networks', 'Professional Development Groups', 'Networking Groups',
  'Business Referral Groups', 'Entrepreneurship Organizations', 'Leadership Programs',
  'Mentorship Programs', 'Tech Meetups', 'Creative Professionals Groups'
];

const EVENT_TYPES = [
  'Networking Events', 'Industry Conferences', 'Trade Shows', 'Professional Workshops',
  'Business Mixers', 'Startup Events', 'Tech Meetups', 'Leadership Summits',
  'Women in Business Events', 'Young Professional Events', 'Alumni Gatherings',
  'Chamber of Commerce Events', 'Association Meetings', 'Career Fairs',
  'Educational Seminars', 'Awards Ceremonies'
];

interface AccountSettingsProps {
  userData?: any;
}

export function AccountSettings({ userData }: AccountSettingsProps) {
  const navigate = useNavigate();
  
  // Initialize profile data from userData (onboarding data) or defaults
  const [profileData, setProfileData] = useState({
    firstName: userData?.firstName || '',
    lastName: userData?.lastName || '',
    name: userData?.name || (userData?.firstName && userData?.lastName ? `${userData.firstName} ${userData.lastName}` : ''),
    email: userData?.email || '',
    jobTitle: userData?.jobTitle || '',
    title: userData?.jobTitle || '', // For backward compatibility
    company: '', // Not collected in onboarding
    location: userData?.zipCode ? `Zip Code: ${userData.zipCode}` : '',
    bio: userData?.bio || '',
    interests: userData?.interests || [],
    website: '', // Not collected in onboarding
    phone: '', // Not collected in onboarding
    industry: userData?.industry || '',
    sameIndustryPreference: userData?.sameIndustryPreference || '',
    genderPreference: userData?.genderPreference || '',
    zipCode: userData?.zipCode || '',
    radius: userData?.radius || '',
    tempZipCode: userData?.tempZipCode || '',
    tempStartDate: userData?.tempStartDate,
    tempEndDate: userData?.tempEndDate,
    associations: userData?.associations || [],
    wantedEvents: userData?.wantedEvents || [],
    networkingGoals: userData?.networkingGoals || '',
    spareTimeActivities: userData?.spareTimeActivities || ''
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    pushNotifications: true,
    messageNotifications: true,
    connectionNotifications: true,
    eventReminders: true,
    weeklyDigest: false
  });

  const [privacySettings, setPrivacySettings] = useState({
    profileVisibility: 'public',
    showEmail: false,
    showPhone: false,
    allowMessages: true,
    showOnlineStatus: true,
    searchable: true
  });

  const [image, setImage] = useState<File | null>(null);
  const [imageDataUrl, setImageDataUrl] = useState<string>('');

  const handleInterestToggle = (interest: string) => {
    setProfileData(prev => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest]
    }));
  };

  const handleAssociationToggle = (association: string) => {
    setProfileData(prev => ({
      ...prev,
      associations: prev.associations.includes(association)
        ? prev.associations.filter(a => a !== association)
        : [...prev.associations, association]
    }));
  };

  const handleEventToggle = (event: string) => {
    setProfileData(prev => ({
      ...prev,
      wantedEvents: prev.wantedEvents.includes(event)
        ? prev.wantedEvents.filter(e => e !== event)
        : [...prev.wantedEvents, event]
    }));
  };

  const handlePhotoSelect = (file: File | null, dataUrl: string) => {
    setImage(file);
    setImageDataUrl(dataUrl);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        toast.error('Please select a valid image file');
        return;
      }
      
      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast.error('Image size must be less than 5MB');
        return;
      }
      
      setImage(file);
      
      // Create a data URL for preview
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setImageDataUrl(e.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProfile = () => {
    toast.success('Profile updated successfully!');
  };

  const handleChangePassword = () => {
    if (!passwordData.currentPassword || !passwordData.newPassword) {
      toast.error('Please fill in all password fields');
      return;
    }
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast.error('New passwords do not match');
      return;
    }
    if (passwordData.newPassword.length < 8) {
      toast.error('Password must be at least 8 characters long');
      return;
    }
    
    toast.success('Password changed successfully!');
    setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
  };

  const handleSaveNotifications = () => {
    toast.success('Notification preferences saved!');
  };

  const handleSavePrivacy = () => {
    toast.success('Privacy settings updated!');
  };

  const handleDeleteAccount = () => {
    // In a real app, this would show a confirmation dialog
    toast.error('Account deletion is not available in this demo');
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl mb-2">Account Settings</h1>
        <p className="text-muted-foreground">
          Manage your profile, privacy, and account preferences
        </p>
      </div>

      {/* Account Management Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <CreditCard className="h-5 w-5" />
            <span>Account Management</span>
          </CardTitle>
          <CardDescription>
            Manage your subscription and payment methods
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium">Payment & Billing</h4>
              <p className="text-sm text-muted-foreground">
                Update payment methods, view billing history, and manage your subscription
              </p>
            </div>
            <Button onClick={() => navigate('/payment-portal')}>
              Payment Portal
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="privacy">Privacy</TabsTrigger>
          <TabsTrigger value="legal">Legal</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-6 max-h-[80vh] overflow-y-auto">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <User className="h-5 w-5" />
                <span>Profile Information</span>
              </CardTitle>
              <CardDescription>
                Update your professional profile information
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Profile Picture */}
              <div>
                <Label>Profile Picture</Label>
                <div className="mt-2 flex items-center space-x-4">
                  <Avatar className="w-20 h-20">
                    {image ? (
                      <img 
                        src={URL.createObjectURL(image)} 
                        alt="Profile" 
                        className="w-full h-full rounded-full object-cover"
                      />
                    ) : (
                      <AvatarFallback className="text-lg">SJ</AvatarFallback>
                    )}
                  </Avatar>
                  <div className="space-y-2">
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                      id="image-upload"
                    />
                    <Label htmlFor="image-upload" className="cursor-pointer">
                      <Button variant="outline" type="button">
                        <Upload className="h-4 w-4 mr-2" />
                        Upload Photo
                      </Button>
                    </Label>
                    {image && (
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => setImage(null)}
                      >
                        <X className="h-4 w-4 mr-1" />
                        Remove
                      </Button>
                    )}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name</Label>
                  <Input
                    id="firstName"
                    value={profileData.firstName}
                    onChange={(e) => setProfileData(prev => ({ 
                      ...prev, 
                      firstName: e.target.value,
                      name: `${e.target.value} ${prev.lastName}`.trim()
                    }))}
                  />
                </div>
                <div>
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input
                    id="lastName"
                    value={profileData.lastName}
                    onChange={(e) => setProfileData(prev => ({ 
                      ...prev, 
                      lastName: e.target.value,
                      name: `${prev.firstName} ${e.target.value}`.trim()
                    }))}
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={profileData.email}
                    onChange={(e) => setProfileData(prev => ({ ...prev, email: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="jobTitle">Job Title (or what are you better known for)</Label>
                  <Input
                    id="jobTitle"
                    value={profileData.jobTitle}
                    onChange={(e) => setProfileData(prev => ({ 
                      ...prev, 
                      jobTitle: e.target.value,
                      title: e.target.value 
                    }))}
                    placeholder="e.g., Entrepreneur, Consultant, Guru..."
                  />
                </div>
                <div>
                  <Label htmlFor="industry">Industry</Label>
                  <Select value={profileData.industry} onValueChange={(value) => setProfileData(prev => ({ ...prev, industry: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your industry" />
                    </SelectTrigger>
                    <SelectContent>
                      {INDUSTRIES.map((industry) => (
                        <SelectItem key={industry} value={industry}>
                          {industry}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="zipCode">
                    <MapPin className="h-4 w-4 inline mr-1" />
                    Zip Code
                  </Label>
                  <Input
                    id="zipCode"
                    value={profileData.zipCode}
                    onChange={(e) => setProfileData(prev => ({ ...prev, zipCode: e.target.value }))}
                    placeholder="Enter zip code"
                    maxLength={5}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="bio">Professional Bio</Label>
                <Textarea
                  id="bio"
                  value={profileData.bio}
                  onChange={(e) => setProfileData(prev => ({ ...prev, bio: e.target.value }))}
                  className="min-h-32"
                />
              </div>

              <div>
                <Label>Professional Interests</Label>
                <p className="text-sm text-muted-foreground mb-3">
                  Select topics that interest you professionally
                </p>
                <div className="flex flex-wrap gap-2">
                  {INTERESTS.map((interest) => (
                    <Badge
                      key={interest}
                      variant={profileData.interests.includes(interest) ? "default" : "outline"}
                      className="cursor-pointer hover:bg-primary hover:text-primary-foreground"
                      onClick={() => handleInterestToggle(interest)}
                    >
                      {interest}
                      {profileData.interests.includes(interest) && (
                        <X className="h-3 w-3 ml-1" />
                      )}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Industry Connect Preference</Label>
                  <Select value={profileData.sameIndustryPreference} onValueChange={(value) => setProfileData(prev => ({ ...prev, sameIndustryPreference: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose preference" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="same">Yes - connect with same industry</SelectItem>
                      <SelectItem value="open">No - open to other industries</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Gender Preference for Connections</Label>
                  <Select value={profileData.genderPreference} onValueChange={(value) => setProfileData(prev => ({ ...prev, genderPreference: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select preference" />
                    </SelectTrigger>
                    <SelectContent>
                      {GENDER_PREFERENCES.map((preference) => (
                        <SelectItem key={preference} value={preference}>
                          {preference}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label>Networking Radius</Label>
                <Select value={profileData.radius} onValueChange={(value) => setProfileData(prev => ({ ...prev, radius: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="How far do you typically go" />
                  </SelectTrigger>
                  <SelectContent>
                    {RADIUS_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="networkingGoals">Networking Goals</Label>
                <Textarea
                  id="networkingGoals"
                  value={profileData.networkingGoals}
                  onChange={(e) => setProfileData(prev => ({ ...prev, networkingGoals: e.target.value }))}
                  placeholder="Describe what you hope to achieve through networking..."
                  className="min-h-24"
                />
              </div>

              <div>
                <Label htmlFor="spareTimeActivities">What keeps you busy in your spare time?</Label>
                <Textarea
                  id="spareTimeActivities"
                  value={profileData.spareTimeActivities}
                  onChange={(e) => setProfileData(prev => ({ ...prev, spareTimeActivities: e.target.value }))}
                  placeholder="Tell us about your hobbies, interests, and activities outside of work"
                  className="min-h-24"
                />
              </div>

              <div>
                <Label>Professional Associations</Label>
                <p className="text-sm text-muted-foreground mb-2">
                  Select associations you're currently a member of (optional)
                </p>
                <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
                  {POPULAR_ASSOCIATIONS.map((association) => (
                    <Badge
                      key={association}
                      variant={profileData.associations.includes(association) ? "default" : "outline"}
                      className="cursor-pointer hover:bg-primary hover:text-primary-foreground text-xs"
                      onClick={() => handleAssociationToggle(association)}
                    >
                      {association}
                      {profileData.associations.includes(association) && (
                        <X className="h-3 w-3 ml-1" />
                      )}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <Label>Events/Associations I'd Like to Attend</Label>
                <p className="text-sm text-muted-foreground mb-2">
                  Select types of events you're interested in attending (optional)
                </p>
                <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
                  {EVENT_TYPES.map((event) => (
                    <Badge
                      key={event}
                      variant={profileData.wantedEvents.includes(event) ? "default" : "outline"}
                      className="cursor-pointer hover:bg-primary hover:text-primary-foreground text-xs"
                      onClick={() => handleEventToggle(event)}
                    >
                      {event}
                      {profileData.wantedEvents.includes(event) && (
                        <X className="h-3 w-3 ml-1" />
                      )}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Temporary Travel Location Section */}
              <div className="border rounded-lg p-4 bg-accent/20">
                <div className="flex items-center gap-2 mb-3">
                  <Plane className="h-4 w-4 text-primary" />
                  <Label className="text-primary">Traveling for work soon? Set a temporary networking destination</Label>
                </div>
                <p className="text-sm text-muted-foreground mb-4">
                  Optionally set a temporary location where you'd like to network during business travel
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="tempZipCode">Travel Zip Code</Label>
                    <Input
                      id="tempZipCode"
                      value={profileData.tempZipCode}
                      onChange={(e) => setProfileData(prev => ({ ...prev, tempZipCode: e.target.value }))}
                      placeholder="Travel destination zip"
                      maxLength={5}
                    />
                  </div>

                  <div>
                    <Label>Start Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-center"
                        >
                          <CalendarIcon className="h-4 w-4" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={profileData.tempStartDate}
                          onSelect={(date) => setProfileData(prev => ({ ...prev, tempStartDate: date }))}
                          disabled={(date) => date < new Date()}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div>
                    <Label>End Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-center"
                        >
                          <CalendarIcon className="h-4 w-4" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={profileData.tempEndDate}
                          onSelect={(date) => setProfileData(prev => ({ ...prev, tempEndDate: date }))}
                          disabled={(date) => {
                            const today = new Date();
                            const startDate = profileData.tempStartDate;
                            return date < today || (startDate && date < startDate);
                          }}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                {profileData.tempZipCode && profileData.tempStartDate && profileData.tempEndDate && (
                  <div className="mt-3 p-2 bg-primary/10 rounded text-sm">
                    <strong>Travel Plan:</strong> Looking to network in {profileData.tempZipCode} from {format(profileData.tempStartDate, "MMM d")} to {format(profileData.tempEndDate, "MMM d, yyyy")}
                  </div>
                )}
              </div>

              <div className="flex justify-end">
                <Button onClick={handleSaveProfile}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Changes
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Lock className="h-5 w-5" />
                <span>Change Password</span>
              </CardTitle>
              <CardDescription>
                Update your account password
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="current-password">Current Password</Label>
                <Input
                  id="current-password"
                  type="password"
                  value={passwordData.currentPassword}
                  onChange={(e) => setPasswordData(prev => ({ ...prev, currentPassword: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="new-password">New Password</Label>
                <Input
                  id="new-password"
                  type="password"
                  value={passwordData.newPassword}
                  onChange={(e) => setPasswordData(prev => ({ ...prev, newPassword: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="confirm-password">Confirm New Password</Label>
                <Input
                  id="confirm-password"
                  type="password"
                  value={passwordData.confirmPassword}
                  onChange={(e) => setPasswordData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                />
              </div>
              <div className="flex justify-end">
                <Button onClick={handleChangePassword}>
                  <Lock className="h-4 w-4 mr-2" />
                  Change Password
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Shield className="h-5 w-5" />
                <span>Account Security</span>
              </CardTitle>
              <CardDescription>
                Additional security options
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">Two-Factor Authentication</h4>
                  <p className="text-sm text-muted-foreground">
                    Add an extra layer of security to your account
                  </p>
                </div>
                <Button variant="outline">Enable</Button>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">Login Sessions</h4>
                  <p className="text-sm text-muted-foreground">
                    Manage your active login sessions
                  </p>
                </div>
                <Button variant="outline">View Sessions</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Bell className="h-5 w-5" />
                <span>Notification Preferences</span>
              </CardTitle>
              <CardDescription>
                Choose what notifications you want to receive
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {Object.entries({
                emailNotifications: 'Email Notifications',
                pushNotifications: 'Push Notifications',
                messageNotifications: 'New Messages',
                matchNotifications: 'New Matches',
                eventReminders: 'Event Reminders',
                weeklyDigest: 'Weekly Digest'
              }).map(([key, label]) => (
                <div key={key} className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">{label}</h4>
                    <p className="text-sm text-muted-foreground">
                      {key === 'emailNotifications' && 'Receive notifications via email'}
                      {key === 'pushNotifications' && 'Receive push notifications on your device'}
                      {key === 'messageNotifications' && 'Get notified when you receive new messages'}
                      {key === 'matchNotifications' && 'Get notified when you have new matches'}
                      {key === 'eventReminders' && 'Receive reminders about upcoming events'}
                      {key === 'weeklyDigest' && 'Weekly summary of your network activity'}
                    </p>
                  </div>
                  <Switch
                    checked={notificationSettings[key as keyof typeof notificationSettings]}
                    onCheckedChange={(checked) => 
                      setNotificationSettings(prev => ({ ...prev, [key]: checked }))
                    }
                  />
                </div>
              ))}
              
              <div className="flex justify-end">
                <Button onClick={handleSaveNotifications}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Preferences
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="privacy" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Eye className="h-5 w-5" />
                <span>Privacy Settings</span>
              </CardTitle>
              <CardDescription>
                Control who can see your information and contact you
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {Object.entries({
                showEmail: 'Show Email Address',
                showPhone: 'Show Phone Number',
                allowMessages: 'Allow Messages from Anyone',
                showOnlineStatus: 'Show Online Status',
                searchable: 'Make Profile Searchable'
              }).map(([key, label]) => (
                <div key={key} className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">{label}</h4>
                    <p className="text-sm text-muted-foreground">
                      {key === 'showEmail' && 'Display your email address on your profile'}
                      {key === 'showPhone' && 'Display your phone number on your profile'}
                      {key === 'allowMessages' && 'Let anyone send you messages, not just matches'}
                      {key === 'showOnlineStatus' && 'Show when you are online'}
                      {key === 'searchable' && 'Allow others to find you in search'}
                    </p>
                  </div>
                  <Switch
                    checked={privacySettings[key as keyof typeof privacySettings]}
                    onCheckedChange={(checked) => 
                      setPrivacySettings(prev => ({ ...prev, [key]: checked }))
                    }
                  />
                </div>
              ))}
              
              <div className="flex justify-end">
                <Button onClick={handleSavePrivacy}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Settings
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-destructive">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-destructive">
                <Trash2 className="h-5 w-5" />
                <span>Danger Zone</span>
              </CardTitle>
              <CardDescription>
                Irreversible and destructive actions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">Delete Account</h4>
                  <p className="text-sm text-muted-foreground">
                    Permanently delete your account and all associated data
                  </p>
                </div>
                <Button variant="destructive" onClick={handleDeleteAccount}>
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete Account
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="legal" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Scale className="h-5 w-5" />
                <span>Legal Documents</span>
              </CardTitle>
              <CardDescription>
                View our legal policies and documents
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate('/terms')}>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <FileText className="h-8 w-8 text-primary" />
                      <div>
                        <h4 className="font-medium">Terms of Service</h4>
                        <p className="text-sm text-muted-foreground">
                          Our platform rules and user agreements
                        </p>
                      </div>
                      <ArrowRight className="h-4 w-4 text-muted-foreground ml-auto" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate('/privacy')}>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Shield className="h-8 w-8 text-primary" />
                      <div>
                        <h4 className="font-medium">Privacy Policy</h4>
                        <p className="text-sm text-muted-foreground">
                          How we collect, use, and protect your data
                        </p>
                      </div>
                      <ArrowRight className="h-4 w-4 text-muted-foreground ml-auto" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Separator />

              <div className="space-y-4">
                <h4 className="font-medium">Terms Acceptance</h4>
                <div className="bg-muted/50 p-4 rounded-lg">
                  <p className="text-sm mb-2">
                    <strong>Terms Accepted:</strong> {userData?._onboardingData?.termsAcceptedAt ? 
                      new Date(userData._onboardingData.termsAcceptedAt).toLocaleDateString() : 
                      'During registration'
                    }
                  </p>
                  <p className="text-xs text-muted-foreground">
                    You accepted our Terms of Service and Privacy Policy during account registration. 
                    If our terms change significantly, we'll notify you via email.
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="font-medium">Contact Information</h4>
                <div className="space-y-2 text-sm">
                  <p>For legal questions or concerns, contact us:</p>
                  <div className="space-y-1 ml-4">
                    <p>• Email: privacy@networkingbude.com</p>
                    <p>• Company: The BudE System™</p>
                    <p>• Location: Grand Rapids, MI</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}