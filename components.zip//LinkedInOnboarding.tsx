import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Calendar } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { X, MapPin, Calendar as CalendarIcon, Plane, Linkedin } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { format } from 'date-fns';
import { PhotoUpload } from './PhotoUpload';
import budeLogo from 'figma:asset/3e43a07a7faa73f2f417a9074a180615c3828a87.png';
import phoneImage from 'figma:asset/221384bd887c9cb3071fb8bf5ae94cb16152d5ef.png';
import networkingImage from 'figma:asset/2d7709d2ea02ddad61763aa90c5fd81814a70b79.png';
import meetingImage from 'figma:asset/6c80cbd0a00b5a01a0b64817f9334c6250b87308.png';
import happyNetworkingImage from 'figma:asset/d433f70f458e8b69ec8a75463563def832ecd7f5.png';
import exampleImage from 'figma:asset/d18b8bb7ba5b21b4a48b3fec8c9947ad387e2dfe.png';


const INTERESTS = [
  'Technology', 'Marketing', 'Finance', 'Design', 'Sales', 'HR',
  'Product Management', 'Data Science', 'Engineering', 'Consulting',
  'Healthcare', 'Education', 'Real Estate', 'Legal', 'Media',
  'Startup', 'AI/ML', 'Blockchain', 'Sustainability', 'Leadership'
];

const INDUSTRIES = [
  'Technology & Software', 'Healthcare & Medical', 'Financial Services', 'Education',
  'Manufacturing', 'Retail & E-commerce', 'Consulting', 'Real Estate',
  'Media & Entertainment', 'Non-profit', 'Government', 'Energy & Utilities',
  'Transportation & Logistics', 'Hospitality & Tourism', 'Legal Services',
  'Construction', 'Agriculture', 'Telecommunications', 'Automotive', 'Other'
];

const GENDER_OPTIONS = [
  'Woman', 'Man', 'Non-binary', 'Prefer not to say'
];

const GENDER_PREFERENCES = [
  'No preference', 'Women', 'Men', 'Non-binary', 'Prefer not to say'
];

const DOB_CONNECT_OPTIONS = [
  '+/- 5 years of my DOB', '+/- 10 years of my DOB', 'No Preference'
];

const RADIUS_OPTIONS = [
  { value: '5', label: '5 miles' },
  { value: '10', label: '10 miles' },
  { value: '25', label: '25 miles' },
  { value: '50', label: '50 miles' },
  { value: '100', label: '100 miles' },
  { value: 'anywhere', label: 'Anywhere in my state/region' }
];

const POPULAR_ASSOCIATIONS = [
  'GR Chamber of Commerce', 'Rotary Club',
  'CREW', 'GRYP', 'Economics Club', 'Create Great Leaders',
  'Right Place', 'Bamboo', 'Hello West Michigan', 'GRAR',
  'CARWM', 'Creative Mornings', 'Grand Rapids Social Club', 'West Michigan Hispanic Chamber',
  'StartGarden', 'BNI', 'Athena', 'Inforum', 'Tech Council', 'CEO Roundtable',
  'JEM', 'AIGA West Michigan', 'BL²END', 'Toastmasters International'
];

const EVENT_TYPES = [
  'GR Chamber of Commerce', 'Rotary Club',
  'CREW', 'GRYP', 'Economics Club', 'Create Great Leaders',
  'Right Place', 'Bamboo', 'Hello West Michigan', 'GRAR',
  'CARWM', 'Creative Mornings', 'Grand Rapids Social Club', 'West Michigan Hispanic Chamber',
  'StartGarden', 'BNI', 'Athena', 'Inforum', 'Tech Council', 'CEO Roundtable',
  'JEM', 'AIGA West Michigan', 'BL²END', 'Toastmasters International'
];

// Onboarding-specific form data interface
interface OnboardingFormData {
  firstName: string;
  lastName: string;
  preferredUsername: string;
  email: string;
  password: string;
  jobTitle?: string;
  dateOfBirth?: string;
  dobConnectPreference?: string;
  bio?: string;
  interests: string[];
  image?: File | null;
  imageDataUrl?: string;
  industry?: string;
  sameIndustryPreference?: string;
  gender?: string;
  genderPreference?: string;
  zipCode?: string;
  radius?: string;
  tempZipCode?: string;
  tempStartDate?: Date;
  tempEndDate?: Date;
  associations: string[];
  wantedEvents: string[];
  networkingGoals?: string;
  spareTimeActivities?: string;
}

interface OnboardingProps {
  onComplete: (data: any) => void; // Will convert to proper UserData format
}

export function LinkedInOnboarding({ onComplete }: OnboardingProps) {
  const [step, setStep] = useState(1);
  const [showLogin, setShowLogin] = useState(false);

  const [loginData, setLoginData] = useState({
    username: '',
    password: '',
    confirmPassword: ''
  });
  const [formData, setFormData] = useState<OnboardingFormData>({
    firstName: '',
    lastName: '',
    preferredUsername: '',
    email: '',
    password: '',
    jobTitle: '',
    dateOfBirth: '',
    dobConnectPreference: '',
    bio: '',
    interests: [],
    image: null,
    industry: '',
    sameIndustryPreference: '',
    gender: '',
    genderPreference: '',
    zipCode: '',
    radius: '',
    tempZipCode: '',
    tempStartDate: undefined,
    tempEndDate: undefined,
    associations: [],
    wantedEvents: [],
    networkingGoals: '',
    spareTimeActivities: ''
  });

  const handleInterestToggle = (interest: string) => {
    setFormData(prev => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest]
    }));
  };

  const handleAssociationToggle = (association: string) => {
    setFormData(prev => ({
      ...prev,
      associations: prev.associations.includes(association)
        ? prev.associations.filter(a => a !== association)
        : [...prev.associations, association]
    }));
  };

  const handleEventToggle = (event: string) => {
    setFormData(prev => ({
      ...prev,
      wantedEvents: prev.wantedEvents.includes(event)
        ? prev.wantedEvents.filter(e => e !== event)
        : [...prev.wantedEvents, event]
    }));
  };

  const handlePhotoSelect = (file: File | null, dataUrl: string) => {
    setFormData(prev => ({ 
      ...prev, 
      image: file,
      imageDataUrl: dataUrl
    }));
  };

  const handleSubmit = () => {
    // Convert form data to proper UserData format and complete onboarding directly
    const userData = {
      id: `user_${Date.now()}`, // Generate a simple ID for demo
      firstName: formData.firstName,
      lastName: formData.lastName,
      name: formData.firstName && formData.lastName 
        ? `${formData.firstName} ${formData.lastName}`.trim()
        : formData.firstName || formData.lastName || '',
      email: formData.email,
      title: formData.jobTitle || '',
      company: '',
      location: formData.zipCode || '',
      bio: formData.bio || '',
      avatar: formData.imageDataUrl || '',
      skills: [],
      interests: formData.interests || [],
      goals: formData.networkingGoals ? [formData.networkingGoals] : [],
      experience: '',
      lookingFor: formData.wantedEvents || [],
      onboardingCompleted: true,
      profileComplete: !!(formData.firstName || formData.lastName || formData.email || formData.bio),
      createdAt: new Date().toISOString(),
      lastActive: new Date().toISOString(),
      // Add preview mode by default - users must upgrade to access full features
      subscriptionStatus: 'preview',
      termsAccepted: false, // Terms not accepted yet - will be required for payment
      // Keep additional onboarding specific data for internal use
      _onboardingData: {
        preferredUsername: formData.preferredUsername,
        password: formData.password,
        jobTitle: formData.jobTitle,
        dateOfBirth: formData.dateOfBirth,
        dobConnectPreference: formData.dobConnectPreference,
        industry: formData.industry,
        sameIndustryPreference: formData.sameIndustryPreference,
        gender: formData.gender,
        genderPreference: formData.genderPreference,
        radius: formData.radius,
        tempZipCode: formData.tempZipCode,
        tempStartDate: formData.tempStartDate,
        tempEndDate: formData.tempEndDate,
        associations: formData.associations,
        networkingGoals: formData.networkingGoals,
        spareTimeActivities: formData.spareTimeActivities
      }
    };
    
    toast.success('Welcome to Networking BudE Preview!');
    onComplete(userData);
  };

  const handleLinkedInConnect = () => {
    // Simulate LinkedIn API integration - in production this would use LinkedIn OAuth
    toast.success('Connected to LinkedIn!', {
      duration: 2500
    });
    
    // Mock LinkedIn profile data with separate name fields
    const linkedInData = {
      firstName: 'Sarah',
      lastName: 'Johnson',
      preferredUsername: 'sarah.johnson',
      email: 'sarah.johnson@email.com',
      password: '', // User will still need to set a password
      jobTitle: 'Senior Product Manager',
      bio: 'Experienced Product Manager with a passion for building innovative digital solutions. 5+ years in tech with focus on user experience and data-driven product decisions.',
      industry: 'Technology & Software',
      interests: ['Product Management', 'Technology', 'Leadership', 'Design'],
      associations: ['Young Professionals Network', 'Women in Business'],
      wantedEvents: ['Tech Meetups', 'Leadership Summits', 'Networking Events']
    };
    
    setFormData(prev => ({
      ...prev,
      ...linkedInData
    }));
    
    // Delay the second toast slightly so they stack properly instead of overlapping
    setTimeout(() => {
      toast.success('Profile information imported from LinkedIn!', {
        description: 'You can review and modify the information before continuing.',
        duration: 2500
      });
    }, 1000);
  };

  const handleLogin = () => {
    if (!loginData.username || !loginData.password) {
      toast.error('Please enter both username and password');
      return;
    }
    if (loginData.password !== loginData.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    toast.success('Welcome back to Networking BudE!');
    
    // Simulate login by creating basic user data in proper format
    const userData = {
      id: `user_${Date.now()}`,
      firstName: loginData.username,
      lastName: '',
      name: loginData.username,
      email: `${loginData.username}@example.com`,
      title: '',
      company: '',
      location: '',
      bio: '',
      avatar: '',
      skills: [],
      interests: [],
      goals: [],
      experience: '',
      lookingFor: [],
      onboardingCompleted: true,
      profileComplete: false,
      subscriptionStatus: 'preview',
      termsAccepted: false,
      createdAt: new Date().toISOString(),
      lastActive: new Date().toISOString(),
      _onboardingData: {
        preferredUsername: loginData.username,
        password: loginData.password,
        associations: [],
        wantedEvents: []
      }
    };
    
    onComplete(userData);
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-4">
            {/* LinkedIn Connect Option */}
            <div className="border rounded-lg p-6 bg-blue-50 border-blue-200 mb-4">
              <div className="text-center space-y-3">
                <h4 className="font-medium text-blue-900">Quick Setup</h4>
                <p className="text-sm text-blue-700">
                  Import your professional information from LinkedIn to get started faster
                </p>
                <Button
                  type="button"
                  onClick={handleLinkedInConnect}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                  disabled={false}
                >
                  <Linkedin className="h-4 w-4 mr-2" />
                  Import From LinkedIn
                </Button>
                <p className="text-xs text-blue-600">
                  Or fill out the form manually below
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name</Label>
                  <Input
                    id="firstName"
                    value={formData.firstName || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
                    placeholder=""
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input
                    id="lastName"
                    value={formData.lastName || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, lastName: e.target.value }))}
                    placeholder=""
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="preferredUsername">Preferred Username</Label>
                <Input
                  id="preferredUsername"
                  value={formData.preferredUsername}
                  onChange={(e) => setFormData(prev => ({ ...prev, preferredUsername: e.target.value }))}
                  placeholder=""
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  placeholder=""
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                  placeholder=""
                />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="jobTitle">Job Title (or what are you known for)</Label>
              <Input
                id="jobTitle"
                value={formData.jobTitle || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, jobTitle: e.target.value }))}
                placeholder="e.g., Senior Marketing Manager, Entrepreneur, Designer"
              />
            </div>

            <div>
              <Label htmlFor="bio">Professional Bio</Label>
              <Textarea
                id="bio"
                value={formData.bio}
                onChange={(e) => setFormData(prev => ({ ...prev, bio: e.target.value }))}
                placeholder="Tell us about your professional background..."
                className="min-h-24"
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Industry (optional)</Label>
                <Select value={formData.industry} onValueChange={(value) => setFormData(prev => ({ ...prev, industry: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select your industry" />
                  </SelectTrigger>
                  <SelectContent>
                    {INDUSTRIES.map((industry) => (
                      <SelectItem key={industry} value={industry}>
                        {industry}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Same Industry Connect</Label>
                <Select value={formData.sameIndustryPreference} onValueChange={(value) => setFormData(prev => ({ ...prev, sameIndustryPreference: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose preference" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="same">Same Industry Connect</SelectItem>
                    <SelectItem value="open">Open to other industries</SelectItem>
                    <SelectItem value="both">Open to my industry and other industries</SelectItem>
                  </SelectContent>
                </Select>

              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Gender (optional)</Label>
                <Select value={formData.gender} onValueChange={(value) => setFormData(prev => ({ ...prev, gender: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {GENDER_OPTIONS.map((gender) => (
                      <SelectItem key={gender} value={gender}>
                        {gender}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Gender Preference Connect?</Label>
                <Select value={formData.genderPreference} onValueChange={(value) => setFormData(prev => ({ ...prev, genderPreference: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select preference" />
                  </SelectTrigger>
                  <SelectContent>
                    {GENDER_PREFERENCES.map((preference) => (
                      <SelectItem key={preference} value={preference}>
                        {preference}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="dateOfBirth">DOB (optional)</Label>
                <Input
                  id="dateOfBirth"
                  type="date"
                  value={formData.dateOfBirth || ''}
                  onChange={(e) => setFormData(prev => ({ ...prev, dateOfBirth: e.target.value }))}
                  placeholder=""
                />
              </div>

              <div>
                <Label>DOB Connect?</Label>
                <Select value={formData.dobConnectPreference} onValueChange={(value) => setFormData(prev => ({ ...prev, dobConnectPreference: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select age preference" />
                  </SelectTrigger>
                  <SelectContent>
                    {DOB_CONNECT_OPTIONS.map((option) => (
                      <SelectItem key={option} value={option}>
                        {option}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="zipCode">
                  <MapPin className="h-4 w-4 inline mr-1" />
                  Zip Code
                </Label>
                <Input
                  id="zipCode"
                  value={formData.zipCode}
                  onChange={(e) => setFormData(prev => ({ ...prev, zipCode: e.target.value }))}
                  placeholder="Enter zip code"
                  maxLength={5}
                />
              </div>

              <div>
                <Label>Connecting Radius</Label>
                <Select value={formData.radius} onValueChange={(value) => setFormData(prev => ({ ...prev, radius: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="How far to connect?" />
                  </SelectTrigger>
                  <SelectContent>
                    {RADIUS_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Organizations That Have Events I Like To Attend</Label>
              <div className="flex flex-wrap gap-2 mt-2">
                {POPULAR_ASSOCIATIONS.map((association) => (
                  <Badge
                    key={association}
                    variant={formData.associations.includes(association) ? "default" : "outline"}
                    className="cursor-pointer hover:bg-primary hover:text-primary-foreground text-xs"
                    onClick={() => handleAssociationToggle(association)}
                  >
                    {association}
                    {formData.associations.includes(association) && (
                      <X className="h-3 w-3 ml-1" />
                    )}
                  </Badge>
                ))}
              </div>
              {formData.associations.length > 0 && (
                <p className="text-sm text-muted-foreground mt-1">
                  Selected: {formData.associations.length} associations
                </p>
              )}
            </div>

            <div className="relative">
              {/* Visual Divider */}
              <div className="flex items-center my-6">
                <div className="flex-1 h-px bg-gradient-to-r from-transparent via-border to-transparent"></div>
                <div className="flex items-center px-4">
                  <div className="w-2 h-2 rounded-full bg-primary/30 mx-1"></div>
                  <div className="w-1 h-1 rounded-full bg-primary/50 mx-1"></div>
                  <div className="w-2 h-2 rounded-full bg-primary/30 mx-1"></div>
                </div>
                <div className="flex-1 h-px bg-gradient-to-r from-transparent via-border to-transparent"></div>
              </div>
              
              <Label>Organizations and Events I've Wanted to Check Out</Label>
              <div className="flex flex-wrap gap-2 mt-2">
                {EVENT_TYPES.map((event) => (
                  <Badge
                    key={event}
                    variant={formData.wantedEvents.includes(event) ? "default" : "outline"}
                    className="cursor-pointer hover:bg-primary hover:text-primary-foreground text-xs"
                    onClick={() => handleEventToggle(event)}
                  >
                    {event}
                    {formData.wantedEvents.includes(event) && (
                      <X className="h-3 w-3 ml-1" />
                    )}
                  </Badge>
                ))}
              </div>
              {formData.wantedEvents.length > 0 && (
                <p className="text-sm text-muted-foreground mt-1">
                  Selected: {formData.wantedEvents.length} organizations
                </p>
              )}
            </div>

            <div>
              <Label>Profile Picture</Label>
              <PhotoUpload
                currentImage={formData.image}
                currentImageDataUrl={formData.imageDataUrl}
                onImageSelect={handlePhotoSelect}
                buttonText="Upload Photo"
                showPreview={true}
              />
            </div>

            {/* Temporary Travel Location Section */}
            <div className="border rounded-lg p-4 bg-accent/20">
              <div className="flex items-center gap-2 mb-3">
                <Plane className="h-4 w-4 text-primary" />
                <Label className="text-primary">NEW FEATURE: Traveling for work soon? Set a temporary connection destination</Label>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Optionally set a temporary location where you'd like to network during business travel
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="tempZipCode">Travel Zip Code</Label>
                  <Input
                    id="tempZipCode"
                    value={formData.tempZipCode}
                    onChange={(e) => setFormData(prev => ({ ...prev, tempZipCode: e.target.value }))}
                    placeholder="Destination"
                    maxLength={5}
                  />
                </div>

                <div>
                  <Label>Start Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={`w-full justify-start text-left ${
                          !formData.tempStartDate && "text-muted-foreground"
                        }`}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formData.tempStartDate ? format(formData.tempStartDate, "MMM d, yyyy") : ""}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={formData.tempStartDate}
                        onSelect={(date) => setFormData(prev => ({ ...prev, tempStartDate: date }))}
                        disabled={(date) => date < new Date()}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div>
                  <Label>End Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={`w-full justify-start text-left ${
                          !formData.tempEndDate && "text-muted-foreground"
                        }`}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formData.tempEndDate ? format(formData.tempEndDate, "MMM d, yyyy") : ""}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={formData.tempEndDate}
                        onSelect={(date) => setFormData(prev => ({ ...prev, tempEndDate: date }))}
                        disabled={(date) => {
                          const today = new Date();
                          const startDate = formData.tempStartDate;
                          return date < today || (startDate && date < startDate);
                        }}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              {formData.tempZipCode && formData.tempStartDate && formData.tempEndDate && (
                <div className="mt-3 p-2 bg-primary/10 rounded text-sm">
                  <strong>Travel Plan:</strong> Looking to network in {formData.tempZipCode} from {format(formData.tempStartDate, "MMM d")} to {format(formData.tempEndDate, "MMM d, yyyy")}
                </div>
              )}
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div>
              <Label>Professional Interests</Label>
              <p className="text-sm text-muted-foreground mb-4">
                Select topics that interest you professionally (choose as many as you like)
              </p>
              <div className="flex flex-wrap gap-2">
                {INTERESTS.map((interest) => (
                  <Badge
                    key={interest}
                    variant={formData.interests.includes(interest) ? "default" : "outline"}
                    className="cursor-pointer hover:bg-primary hover:text-primary-foreground"
                    onClick={() => handleInterestToggle(interest)}
                  >
                    {interest}
                    {formData.interests.includes(interest) && (
                      <X className="h-3 w-3 ml-1" />
                    )}
                  </Badge>
                ))}
              </div>
              {formData.interests.length > 0 && (
                <p className="text-sm text-muted-foreground mt-2">
                  Selected: {formData.interests.length} interests
                </p>
              )}
            </div>

            <div>
              <Label htmlFor="networkingGoals">Networking Goals (optional)</Label>
              <Textarea
                id="networkingGoals"
                value={formData.networkingGoals}
                onChange={(e) => setFormData(prev => ({ ...prev, networkingGoals: e.target.value }))}
                placeholder="What are you hoping to achieve through networking..."
                className="min-h-20"
              />
            </div>

            <div>
              <Label htmlFor="spareTimeActivities">Spare Time Activities (optional)</Label>
              <Textarea
                id="spareTimeActivities"
                value={formData.spareTimeActivities}
                onChange={(e) => setFormData(prev => ({ ...prev, spareTimeActivities: e.target.value }))}
                placeholder="What do you like to do outside of work..."
                className="min-h-20"
              />
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const getStepImage = () => {
    switch (step) {
      case 1:
        return phoneImage;
      case 2:
        return meetingImage;
      case 3:
        return networkingImage;
      default:
        return phoneImage;
    }
  };

  const getStepImageAlt = () => {
    switch (step) {
      case 1:
        return "Networking BudE app on mobile device";
      case 2:
        return "Professional networking meeting";
      case 3:
        return "Professionals networking at business event";
      default:
        return "Networking BudE";
    }
  };

  if (showLogin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-md">
          <div className="flex justify-center mb-6">
            <img src={budeLogo} alt="Networking BudE" className="h-12 w-auto" />
          </div>
          <h2 className="mt-6 text-center text-3xl tracking-tight text-gray-900">
            Welcome Back
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Sign in to your Networking BudE account
          </p>
        </div>

        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
          <Card>
            <CardContent className="py-6 px-4 space-y-6">
              <div>
                <Label htmlFor="username">Username or Email</Label>
                <Input
                  id="username"
                  type="text"
                  value={loginData.username}
                  onChange={(e) => setLoginData(prev => ({ ...prev, username: e.target.value }))}
                  placeholder="Enter your username or email"
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={loginData.password}
                  onChange={(e) => setLoginData(prev => ({ ...prev, password: e.target.value }))}
                  placeholder="Enter your password"
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="confirmPassword">Confirm Password</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={loginData.confirmPassword}
                  onChange={(e) => setLoginData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                  placeholder="Confirm your password"
                  className="mt-1"
                />
              </div>

              <Button 
                onClick={handleLogin} 
                className="w-full"
                disabled={!loginData.username || !loginData.password || !loginData.confirmPassword}
              >
                Sign In
              </Button>

              <div className="text-center">
                <button
                  onClick={() => setShowLogin(false)}
                  className="text-sm text-primary hover:text-primary-dark"
                >
                  Need an account? Sign up instead
                </button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/10">
      <div className="w-full max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8 items-start min-h-screen">
        {/* Image Section */}
        <div className="hidden lg:block lg:sticky lg:top-0 lg:h-screen lg:flex lg:items-start lg:pt-8">
          <div className="relative w-full">
            {/* Main Step Image */}
            <img 
              src={getStepImage()} 
              alt={getStepImageAlt()}
              className="w-full h-auto rounded-2xl shadow-2xl object-cover max-h-[600px]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-2xl"></div>
            
            {/* Collage - Only show on step 1 */}
            {step === 1 && (
              <div className="absolute bottom-4 right-4 flex flex-col space-y-2">
                <img 
                  src={networkingImage} 
                  alt="Networking event" 
                  className="w-32 h-32 rounded-lg object-cover shadow-lg border-2 border-white"
                />
                <img 
                  src={meetingImage} 
                  alt="Business meeting" 
                  className="w-32 h-32 rounded-lg object-cover shadow-lg border-2 border-white"
                />
                <img 
                  src={happyNetworkingImage} 
                  alt="Happy networking conversation" 
                  className="w-32 h-32 rounded-lg object-cover shadow-lg border-2 border-white"
                />
              </div>
            )}
          </div>
        </div>

        {/* Form Section */}
        <div className="flex flex-col justify-start lg:py-8">
          <Card className="w-full max-w-lg mx-auto lg:mx-0">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4">
                <img src={budeLogo} alt="Networking BudE" className="h-32 mx-auto" />
              </div>
              <CardTitle className="text-3xl font-bold">Welcome to Networking BudE</CardTitle>

              
              {/* What's this all about section - only show on step 1 */}
              {step === 1 && (
                <div className="mt-6 text-left bg-accent/30 rounded-lg p-4">
                  <h3 className="text-lg font-semibold mb-3 text-center">What's this all about?</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Networking BudE offers the ability to connect with others and attend events with people who share your networking goals:
                  </p>

                  <blockquote className="text-sm italic text-center text-muted-foreground border-l-2 border-primary pl-3 mb-3">
                    "I no longer feel awkward at events alone anymore. Thanks BudE!" - Meghan a Satisfied BudE User
                  </blockquote>
                  <p className="text-center font-semibold text-primary">
                    Ready to jump in? Let's go!
                  </p>
                </div>
              )}
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Progress indicator */}
                <div className="flex space-x-2">
                  {[1, 2, 3].map((num) => (
                    <div
                      key={num}
                      className={`flex-1 h-2 rounded-full ${
                        num <= step ? 'bg-primary' : 'bg-muted'
                      }`}
                    />
                  ))}
                </div>

                {/* Mobile Image (visible on small screens) */}
                <div className="lg:hidden mb-6">
                  <div className="relative">
                    <img 
                      src={getStepImage()} 
                      alt={getStepImageAlt()}
                      className="w-full h-48 rounded-lg object-cover shadow-lg"
                    />
                    {/* Mobile Collage - Only show on step 1 */}
                    {step === 1 && (
                      <div className="absolute bottom-2 right-2 flex flex-col space-y-1">
                        <img 
                          src={networkingImage} 
                          alt="Networking event" 
                          className="w-20 h-20 rounded object-cover shadow-md border border-white"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Step Content */}
                {renderStep()}

                {/* Navigation */}
                <div className="flex justify-between">
                  <Button
                    variant="outline"
                    onClick={() => setStep(prev => Math.max(1, prev - 1))}
                    disabled={step === 1}
                  >
                    Previous
                  </Button>
                  
                  {step < 3 ? (
                    <Button
                      onClick={() => setStep(prev => Math.min(3, prev + 1))}
                    >
                      Continue
                    </Button>
                  ) : (
                    <Button
                      onClick={handleSubmit}
                      className="bg-bude-green-dark text-white hover:bg-bude-green-dark/90 border-3 border-bude-yellow"
                    >
                      Let's Go!
                    </Button>
                  )}
                </div>

                {/* Login toggle */}
                <div className="text-center">
                  <button
                    onClick={() => setShowLogin(true)}
                    className="text-sm text-primary hover:text-primary-dark"
                  >
                    Already have an account? Sign in
                  </button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Hero Images Section */}


          <div className="mt-8 text-center">
            <p className="text-xs text-gray-500">
              Networking BudE by The BudE System™
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}