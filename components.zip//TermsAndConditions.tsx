// Terms and Conditions Component - Industry Standard Terms for Professional Networking App
import { useState, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Button } from './ui/button';
import { Checkbox } from './ui/checkbox';
import { ScrollArea } from './ui/scroll-area';
import { AlertTriangle, Scale, Shield, Users, Mail, Building } from 'lucide-react';

interface TermsAndConditionsProps {
  isOpen: boolean;
  onAccept: () => void;
  onDecline: () => void;
  userEmail?: string;
}

export function TermsAndConditions({ 
  isOpen, 
  onAccept, 
  onDecline, 
  userEmail 
}: TermsAndConditionsProps) {
  const [hasAcceptedTerms, setHasAcceptedTerms] = useState(false);
  const [hasAcceptedPrivacy, setHasAcceptedPrivacy] = useState(false);
  const [hasScrolledToBottom, setHasScrolledToBottom] = useState(false);

  const canAccept = hasAcceptedTerms && hasAcceptedPrivacy && hasScrolledToBottom;

  const handleScroll = useCallback((event: React.UIEvent<HTMLDivElement>) => {
    const { scrollTop, scrollHeight, clientHeight } = event.currentTarget;
    const threshold = 50; // Allow 50px before bottom
    
    if (scrollTop + clientHeight >= scrollHeight - threshold) {
      setHasScrolledToBottom(true);
    }
  }, []);

  const handleAccept = useCallback(() => {
    if (canAccept) {
      onAccept();
    }
  }, [canAccept, onAccept]);

  const lastUpdated = "September 21, 2025";
  const effectiveDate = "September 21, 2025";

  return (
    <Dialog open={isOpen} onOpenChange={() => {}}>
      <DialogContent className="max-w-4xl max-h-[90vh] p-0">
        <DialogHeader className="p-6 pb-4 border-b">
          <DialogTitle className="flex items-center space-x-2 text-2xl">
            <Scale className="h-6 w-6 text-primary" />
            <span>Terms of Service & Privacy Policy</span>
          </DialogTitle>
          <DialogDescription className="text-muted-foreground mt-2">
            Please review and accept our terms to continue with Networking BudE. You must read the complete document and agree to both the Terms of Service and Privacy Policy to proceed.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-hidden">
          <ScrollArea 
            className="h-[60vh] px-6" 
            onScrollCapture={handleScroll}
          >
            <div className="space-y-8 pb-6">
              {/* Terms of Service Section */}
              <section>
                <div className="flex items-center space-x-2 mb-4">
                  <Scale className="h-5 w-5 text-primary" />
                  <h2 className="text-xl font-semibold">Terms of Service</h2>
                </div>
                
                <div className="space-y-4 text-sm">
                  <div className="bg-muted/50 p-4 rounded-lg">
                    <p className="font-medium">Effective Date: {effectiveDate}</p>
                    <p className="font-medium">Last Updated: {lastUpdated}</p>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">1. Acceptance of Terms</h3>
                    <p>
                      By accessing or using Networking BudE ("the Service"), you agree to be bound by these Terms of Service and our Privacy Policy. If you do not agree to these terms, please do not use our Service.
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">2. Description of Service</h3>
                    <p>
                      Networking BudE is a professional networking platform designed to connect professionals in the Grand Rapids area. Our Service facilitates meaningful professional relationships through events, messaging, and professional connecting.
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">3. User Accounts and Registration</h3>
                    <ul className="list-disc list-inside space-y-1 ml-4">
                      <li>You must provide accurate and complete information during registration</li>
                      <li>You are responsible for maintaining the confidentiality of your account credentials</li>
                      <li>You must be at least 18 years old to use this Service</li>
                      <li>One person may maintain only one account</li>
                      <li>You must notify us immediately of any unauthorized use of your account</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">4. User Conduct and Responsibilities</h3>
                    
                    <div className="bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 p-4 rounded-lg mb-4">
                      <p className="font-semibold text-red-900 dark:text-red-100 mb-2">Important Usage Restrictions:</p>
                      <div className="space-y-2 text-red-800 dark:text-red-200 text-sm">
                        <p>
                          <strong>This is not a DATING app.</strong> If you are reported by another BudE user for using it for that purpose your correspondence will be reviewed and you could be subject to suspension and NO refund of your subscription.
                        </p>
                        <p>
                          <strong>This app shall not be used by you (as a user) to SELL goods or services to other users.</strong> If you are reported by another BudE user for using it for that purpose your correspondence will be reviewed and you could be subject to suspension and NO refund of your subscription.
                        </p>
                      </div>
                    </div>
                    
                    <p className="mb-2">You agree NOT to:</p>
                    <ul className="list-disc list-inside space-y-1 ml-4">
                      <li>Use the Service for any unlawful purpose or in violation of any local, state, national, or international law</li>
                      <li>Harass, threaten, intimidate, or harm other users</li>
                      <li>Post false, misleading, or inaccurate information</li>
                      <li>Impersonate any person or entity or misrepresent your affiliation</li>
                      <li>Use automated systems (bots, scripts) to access the Service</li>
                      <li>Attempt to gain unauthorized access to the Service or other users' accounts</li>
                      <li>Upload or transmit viruses, malware, or other harmful code</li>
                      <li>Collect or harvest information about other users without consent</li>
                      <li>Use the Service for commercial solicitation without prior written consent</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">5. Content and Intellectual Property</h3>
                    <ul className="list-disc list-inside space-y-1 ml-4">
                      <li>You retain ownership of content you post, but grant us a license to use, display, and distribute it</li>
                      <li>You are responsible for ensuring you have rights to any content you post</li>
                      <li>We may remove content that violates these terms or applicable laws</li>
                      <li>Our Service, design, and software are protected by intellectual property laws</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">6. Professional Use Only</h3>
                    <p>
                      This platform is intended solely for professional networking purposes. Personal dating, romantic connections, or non-professional solicitation are strictly prohibited.
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">7. Payment and Subscription Terms</h3>
                    <ul className="list-disc list-inside space-y-1 ml-4">
                      <li>Subscription fees are billed in advance and are non-refundable</li>
                      <li>Prices may change with 30 days notice</li>
                      <li>You may cancel your subscription at any time</li>
                      <li>Upon cancellation, you retain access until the end of your billing period</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">8. Disclaimers and Limitation of Liability</h3>
                    <ul className="list-disc list-inside space-y-1 ml-4">
                      <li>The Service is provided "as is" without warranties of any kind</li>
                      <li>We do not guarantee the accuracy of user-provided information</li>
                      <li>We are not responsible for interactions between users</li>
                      <li>Our liability is limited to the amount you paid for the Service in the last 12 months</li>
                      <li>We are not liable for indirect, incidental, or consequential damages</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">9. Termination</h3>
                    <p>
                      We reserve the right to suspend or terminate your account at any time for violation of these terms or for any other reason. Upon termination, your right to use the Service ceases immediately.
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">10. Governing Law</h3>
                    <p>
                      These terms are governed by the laws of the State of Michigan, United States. Any disputes will be resolved in the courts of Kent County, Michigan.
                    </p>
                  </div>
                </div>
              </section>

              {/* Privacy Policy Section */}
              <section className="border-t pt-6">
                <div className="flex items-center space-x-2 mb-4">
                  <Shield className="h-5 w-5 text-primary" />
                  <h2 className="text-xl font-semibold">Privacy Policy</h2>
                </div>

                <div className="space-y-4 text-sm">
                  <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                    <div className="flex items-start space-x-2">
                      <AlertTriangle className="h-5 w-5 text-blue-600 mt-0.5" />
                      <div>
                        <p className="font-medium text-blue-900 dark:text-blue-100">Important Notice</p>
                        <p className="text-blue-800 dark:text-blue-200 text-xs mt-1">
                          Figma Make and Networking BudE are not intended for collecting personally identifiable information (PII) or securing sensitive data. This is a prototype application for demonstration purposes.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">Information We Collect</h3>
                    <ul className="list-disc list-inside space-y-1 ml-4">
                      <li><strong>Profile Information:</strong> Name, email, professional title, company, biography</li>
                      <li><strong>Professional Details:</strong> Industry, interests, networking goals, associations</li>
                      <li><strong>Location Data:</strong> ZIP code for local networking (not precise location)</li>
                      <li><strong>Usage Data:</strong> How you interact with our Service, features used</li>
                      <li><strong>Communications:</strong> Messages sent through our platform</li>
                      <li><strong>Device Information:</strong> Device type, browser, IP address</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">How We Use Your Information</h3>
                    <ul className="list-disc list-inside space-y-1 ml-4">
                      <li>Facilitate professional connections and networking opportunities</li>
                      <li>Recommend relevant events and professional contacts</li>
                      <li>Improve our Service and develop new features</li>
                      <li>Send important account and service notifications</li>
                      <li>Provide customer support and respond to inquiries</li>
                      <li>Ensure platform safety and prevent misuse</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">Information Sharing</h3>
                    <p className="mb-2">We do NOT sell your personal information. We may share information:</p>
                    <ul className="list-disc list-inside space-y-1 ml-4">
                      <li>With other users as part of networking features (profile information)</li>
                      <li>With service providers who help operate our platform</li>
                      <li>When required by law or to protect safety</li>
                      <li>In connection with a business transfer or merger</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">Data Security</h3>
                    <p>
                      We implement appropriate security measures to protect your information, including encryption, secure servers, and access controls. However, no internet transmission is 100% secure.
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">Your Rights</h3>
                    <ul className="list-disc list-inside space-y-1 ml-4">
                      <li>Access and review your personal information</li>
                      <li>Correct inaccurate or incomplete information</li>
                      <li>Delete your account and associated data</li>
                      <li>Object to certain uses of your information</li>
                      <li>Receive a copy of your data in a portable format</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">Contact Information</h3>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Mail className="h-4 w-4" />
                        <span>privacy@networkingbude.com</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Building className="h-4 w-4" />
                        <span>The BudE System™, Grand Rapids, MI</span>
                      </div>
                    </div>
                  </div>
                </div>
              </section>

              {/* Scroll indicator */}
              {!hasScrolledToBottom && (
                <div className="text-center py-4 text-muted-foreground text-sm">
                  ↓ Please scroll to continue reading ↓
                </div>
              )}
            </div>
          </ScrollArea>
        </div>

        {/* Footer with checkboxes and buttons */}
        <div className="border-t p-6 space-y-4">
          <div className="space-y-3">
            <div className="flex items-start space-x-3">
              <Checkbox
                id="terms-checkbox"
                checked={hasAcceptedTerms}
                onCheckedChange={setHasAcceptedTerms}
                className="mt-1"
              />
              <label 
                htmlFor="terms-checkbox" 
                className="text-sm leading-relaxed cursor-pointer"
              >
                I have read and agree to the <strong>Terms of Service</strong> and understand my rights and responsibilities as outlined above.
              </label>
            </div>

            <div className="flex items-start space-x-3">
              <Checkbox
                id="privacy-checkbox"
                checked={hasAcceptedPrivacy}
                onCheckedChange={setHasAcceptedPrivacy}
                className="mt-1"
              />
              <label 
                htmlFor="privacy-checkbox" 
                className="text-sm leading-relaxed cursor-pointer"
              >
                I have read and agree to the <strong>Privacy Policy</strong> and consent to the collection and use of my information as described.
              </label>
            </div>

            {!hasScrolledToBottom && (
              <p className="text-xs text-muted-foreground">
                Please scroll through the entire document above to continue.
              </p>
            )}
          </div>

          <div className="flex space-x-3 justify-end">
            <Button 
              variant="outline" 
              onClick={onDecline}
              className="min-w-24"
            >
              Decline
            </Button>
            <Button 
              onClick={handleAccept}
              disabled={!canAccept}
              className={`min-w-24 ${
                canAccept 
                  ? 'bg-primary hover:bg-primary/90' 
                  : 'bg-muted text-muted-foreground cursor-not-allowed'
              }`}
            >
              Accept & Continue
            </Button>
          </div>

          {userEmail && (
            <p className="text-xs text-muted-foreground mt-2">
              By accepting, these terms will apply to your account: {userEmail}
            </p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}