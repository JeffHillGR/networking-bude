import { useState, useEffect } from 'react';
import { MapPin } from 'lucide-react';

// City-specific images from Unsplash
const CITY_IMAGES: Record<string, string> = {
  'New York City': 'https://images.unsplash.com/photo-1643406416661-0456c5d1b53e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxOZXclMjBZb3JrJTIwQ2l0eSUyME1hbmhhdHRhbiUyMHNreWxpbmV8ZW58MXx8fHwxNzU4MDQ5NDI5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  'Los Angeles': 'https://images.unsplash.com/photo-1729244958261-76a200619125?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxMb3MlMjBBbmdlbGVzJTIwZG93bnRvd24lMjBza3lsaW5lfGVufDF8fHx8MTc1ODA0OTQzM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  'Chicago': 'https://images.unsplash.com/photo-1682987211350-3211e7eb9dc0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxDaGljYWdvJTIwZG93bnRvd24lMjBza3lsaW5lfGVufDF8fHx8MTc1ODA0OTQzOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  'San Francisco': 'https://images.unsplash.com/photo-1720794673740-30e3449dc738?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxTYW4lMjBGcmFuY2lzY28lMjBjaXR5JTIwc2t5bGluZXxlbnwxfHx8fDE3NTgwNDk0NDF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  'Seattle': 'https://images.unsplash.com/photo-1751127939825-787bd35e62c8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxTZWF0dGxlJTIwZG93bnRvd24lMjBza3lsaW5lfGVufDF8fHx8MTc1ODA0OTQ0NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  // Default fallback for unmapped cities
  'default': 'https://images.unsplash.com/photo-1605474456643-9bb8045cdec9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaXR5JTIwc2t5bGluZSUyMHVyYmFuJTIwZG93bnRvd258ZW58MXx8fHwxNzU4MDQ5NDA0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
};

// Mapping of zip code ranges to major cities
const ZIP_CODE_TO_CITY: Record<string, string> = {
  // New York
  '100': 'New York City', '101': 'New York City', '102': 'New York City',
  '103': 'New York City', '104': 'New York City', '105': 'New York City',
  
  // Los Angeles
  '900': 'Los Angeles', '901': 'Los Angeles', '902': 'Los Angeles',
  '903': 'Los Angeles', '904': 'Los Angeles', '905': 'Los Angeles',
  '906': 'Los Angeles', '907': 'Los Angeles', '908': 'Los Angeles',
  
  // Chicago
  '606': 'Chicago', '607': 'Chicago', '608': 'Chicago',
  
  // Houston
  '770': 'Houston', '771': 'Houston', '772': 'Houston', '773': 'Houston',
  
  // Philadelphia
  '191': 'Philadelphia', '192': 'Philadelphia', '193': 'Philadelphia',
  
  // Phoenix
  '850': 'Phoenix', '851': 'Phoenix', '852': 'Phoenix',
  
  // San Antonio
  '782': 'San Antonio',
  
  // San Diego
  '921': 'San Diego', '922': 'San Diego', '923': 'San Diego', '924': 'San Diego',
  
  // Dallas
  '752': 'Dallas', '753': 'Dallas', '754': 'Dallas',
  
  // San Jose/San Francisco Bay Area
  '941': 'San Francisco', '942': 'San Francisco', '943': 'San Francisco', '944': 'San Francisco',
  '950': 'San Francisco', '951': 'San Francisco',
  
  // Austin
  '787': 'Austin', '788': 'Austin',
  
  // Jacksonville
  '322': 'Jacksonville',
  
  // Fort Worth
  '761': 'Fort Worth',
  
  // Columbus
  '432': 'Columbus',
  
  // Charlotte
  '282': 'Charlotte',
  
  // San Francisco
  '941': 'San Francisco',
  
  // Indianapolis
  '462': 'Indianapolis', '463': 'Indianapolis',
  
  // Seattle
  '981': 'Seattle', '982': 'Seattle',
  
  // Denver
  '802': 'Denver', '803': 'Denver',
  
  // Washington DC
  '200': 'Washington DC', '201': 'Washington DC', '202': 'Washington DC',
  
  // Boston
  '021': 'Boston', '022': 'Boston',
  
  // El Paso
  '799': 'El Paso',
  
  // Detroit
  '482': 'Detroit', '483': 'Detroit',
  
  // Nashville
  '372': 'Nashville', '373': 'Nashville',
  
  // Portland
  '972': 'Portland',
  
  // Oklahoma City
  '731': 'Oklahoma City', '732': 'Oklahoma City',
  
  // Las Vegas
  '891': 'Las Vegas', '892': 'Las Vegas',
  
  // Louisville
  '402': 'Louisville',
  
  // Baltimore
  '212': 'Baltimore',
  
  // Milwaukee
  '532': 'Milwaukee', '533': 'Milwaukee',
  
  // Albuquerque
  '871': 'Albuquerque',
  
  // Tucson
  '857': 'Tucson',
  
  // Fresno
  '937': 'Fresno',
  
  // Sacramento
  '942': 'Sacramento', '943': 'Sacramento',
  
  // Mesa
  '852': 'Mesa',
  
  // Kansas City
  '641': 'Kansas City',
  
  // Atlanta
  '303': 'Atlanta', '304': 'Atlanta',
  
  // Long Beach
  '908': 'Long Beach',
  
  // Colorado Springs
  '809': 'Colorado Springs',
  
  // Raleigh
  '276': 'Raleigh',
  
  // Miami
  '331': 'Miami', '332': 'Miami', '333': 'Miami',
  
  // Virginia Beach
  '234': 'Virginia Beach',
  
  // Omaha
  '681': 'Omaha',
  
  // Oakland
  '946': 'Oakland',
  
  // Minneapolis
  '554': 'Minneapolis', '555': 'Minneapolis',
  
  // Tulsa
  '741': 'Tulsa',
  
  // Arlington
  '760': 'Arlington',
  
  // New Orleans
  '701': 'New Orleans',
  
  // Wichita
  '672': 'Wichita',
  
  // Cleveland
  '441': 'Cleveland', '442': 'Cleveland',
  
  // Tampa
  '336': 'Tampa',
  
  // Bakersfield
  '933': 'Bakersfield',
  
  // Aurora
  '805': 'Aurora',
  
  // Honolulu
  '968': 'Honolulu',
  
  // Anaheim
  '928': 'Anaheim',
  
  // Santa Ana
  '927': 'Santa Ana',
  
  // Corpus Christi
  '784': 'Corpus Christi',
  
  // Riverside
  '925': 'Riverside',
  
  // Lexington
  '405': 'Lexington',
  
  // Stockton
  '952': 'Stockton',
  
  // Henderson
  '890': 'Henderson',
  
  // Saint Paul
  '551': 'Saint Paul',
  
  // St. Louis
  '631': 'St. Louis', '632': 'St. Louis', '633': 'St. Louis',
  
  // Cincinnati
  '452': 'Cincinnati', '453': 'Cincinnati',
  
  // Pittsburgh
  '152': 'Pittsburgh', '153': 'Pittsburgh'
};

interface CityBannerProps {
  zipCode: string;
}

export function CityBanner({ zipCode }: CityBannerProps) {
  const [cityImage, setCityImage] = useState<string | null>(null);
  const [cityName, setCityName] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!zipCode || zipCode.length < 3) {
      setIsLoading(false);
      return;
    }

    // Get the first 3 digits of the zip code for mapping
    const zipPrefix = zipCode.substring(0, 3);
    const mappedCity = ZIP_CODE_TO_CITY[zipPrefix];
    
    if (mappedCity) {
      setCityName(mappedCity);
      fetchCityImage(mappedCity);
    } else {
      // Fallback for unmapped zip codes - use a generic city search
      setCityName('Your City');
      fetchCityImage('city skyline');
    }
  }, [zipCode]);

  const fetchCityImage = async (city: string) => {
    try {
      setIsLoading(true);
      
      // Get city-specific image or use default
      const cityImage = CITY_IMAGES[city] || CITY_IMAGES['default'];
      setCityImage(cityImage);
      setIsLoading(false);
    } catch (error) {
      console.error('Error fetching city image:', error);
      setCityImage(CITY_IMAGES['default']);
      setIsLoading(false);
    }
  };

  if (!zipCode || isLoading) {
    return (
      <div className="relative h-32 md:h-48 bg-gradient-to-r from-primary/20 to-accent/20 rounded-lg overflow-hidden animate-pulse">
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
        <div className="absolute bottom-4 left-6 right-6">
          <div className="h-6 bg-white/20 rounded w-48 mb-2"></div>
          <div className="h-4 bg-white/20 rounded w-32"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative h-32 md:h-48 rounded-lg overflow-hidden">
      {cityImage && (
        <img 
          src={cityImage} 
          alt={`${cityName} skyline`}
          className="w-full h-full object-cover"
        />
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
      <div className="absolute bottom-4 left-6 right-6 text-white">
        <div className="flex items-center space-x-2 mb-1">
          <MapPin className="h-4 w-4" />
          <span className="text-sm opacity-90">Your networking hub</span>
        </div>
        <h2 className="text-xl md:text-2xl font-semibold">
          Welcome to {cityName}
        </h2>
        <p className="text-sm opacity-90 mt-1">
          Discover professional connections in your area
        </p>
      </div>
    </div>
  );
}