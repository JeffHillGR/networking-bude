import { useParams, Link } from 'react-router-dom';
import { useState } from 'react';
import { Card, CardContent, CardHeader } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Avatar, AvatarFallback } from './ui/avatar';
import { 
  ArrowLeft, 
  Phone, 
  Video, 
  MoreHorizontal,
  Send,
  Paperclip,
  Smile,
  Image,
  File,
  Info,
  Flag
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

// Mock conversation data
const CONVERSATION_DATA = {
  1: {
    id: 1,
    name: 'Sarah Thompson',
    title: 'UX Designer at Adobe',
    avatar: 'ST',
    isOnline: true,
    messages: [
      {
        id: 1,
        senderId: 1,
        content: "Hi! I saw your profile and I'm really impressed with your product management experience. I'd love to chat about potential collaboration opportunities.",
        timestamp: '2025-09-16T10:00:00Z',
        type: 'text'
      },
      {
        id: 2,
        senderId: 'me',
        content: "Thank you so much! I checked out your portfolio and your design work is fantastic. I'd definitely be interested in discussing potential collaborations.",
        timestamp: '2025-09-16T10:15:00Z',
        type: 'text'
      },
      {
        id: 3,
        senderId: 1,
        content: "That's great! I'm working on a new product concept and could really use some product strategy insights. Are you free for a coffee chat this week?",
        timestamp: '2025-09-16T10:30:00Z',
        type: 'text'
      },
      {
        id: 4,
        senderId: 'me',
        content: "Absolutely! I'm free Tuesday or Thursday afternoon. What works better for you?",
        timestamp: '2025-09-16T11:00:00Z',
        type: 'text'
      },
      {
        id: 5,
        senderId: 1,
        content: "Tuesday afternoon would be perfect! How about 2 PM at the Blue Bottle Coffee on Market Street?",
        timestamp: '2025-09-16T13:45:00Z',
        type: 'text'
      },
      {
        id: 6,
        senderId: 'me',
        content: "Perfect! I'll see you there on Tuesday at 2 PM. Looking forward to our chat! ☕",
        timestamp: '2025-09-16T14:00:00Z',
        type: 'text'
      },
      {
        id: 7,
        senderId: 1,
        content: "Looking forward to our coffee chat!",
        timestamp: '2025-09-16T14:30:00Z',
        type: 'text'
      }
    ]
  }
};

export function Conversation() {
  const { id } = useParams();
  const [newMessage, setNewMessage] = useState('');
  const [showInfo, setShowInfo] = useState(false);
  
  const conversation = CONVERSATION_DATA[id as keyof typeof CONVERSATION_DATA];

  if (!conversation) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="p-12 text-center">
            <h2 className="text-xl font-semibold mb-2">Conversation not found</h2>
            <p className="text-muted-foreground mb-4">
              The conversation you're looking for doesn't exist.
            </p>
            <Link to="/messenger">
              <Button>Back to Messages</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    
    // In a real app, this would send the message to the backend
    toast.success('Message sent!');
    setNewMessage('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleReportMessage = (messageId: number, messageContent: string) => {
    // In a real app, this would send the report to the backend/moderation system
    toast.success('Message reported successfully. Our team will review it.');
    console.log('Reporting message:', { messageId, messageContent, reportedBy: 'current_user' });
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 24) {
      return date.toLocaleTimeString('en-US', { 
        hour: 'numeric', 
        minute: '2-digit',
        hour12: true 
      });
    } else {
      return date.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
      });
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Link to="/messenger">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl font-semibold">Conversation</h1>
          <p className="text-muted-foreground">
            Chat with {conversation.name}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[600px]">
        {/* Main Chat Area */}
        <div className={`${showInfo ? 'lg:col-span-3' : 'lg:col-span-4'}`}>
          <Card className="h-full flex flex-col">
            {/* Chat Header */}
            <CardHeader className="border-b">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <Avatar>
                      <AvatarFallback>{conversation.avatar}</AvatarFallback>
                    </Avatar>
                    {conversation.isOnline && (
                      <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                    )}
                  </div>
                  <div>
                    <h3 className="font-medium">{conversation.name}</h3>
                    <p className="text-sm text-muted-foreground">{conversation.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {conversation.isOnline ? 'Online now' : 'Last seen recently'}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="ghost" size="icon">
                    <Phone className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Video className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => setShowInfo(!showInfo)}
                  >
                    <Info className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>

            {/* Messages Area */}
            <div className="flex-1 p-4 overflow-y-auto">
              <div className="space-y-4">
                {conversation.messages.map((message) => {
                  const isOwnMessage = message.senderId === 'me';
                  return (
                    <div
                      key={message.id}
                      className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-[70%] ${isOwnMessage ? 'order-2' : 'order-1'} group relative`}>
                        <div
                          className={`rounded-lg p-3 ${
                            isOwnMessage
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-muted'
                          }`}
                        >
                          <p className="text-sm">{message.content}</p>
                        </div>
                        <div className={`flex items-center mt-1 ${
                          isOwnMessage ? 'justify-end' : 'justify-between'
                        }`}>
                          <p className={`text-xs text-muted-foreground ${
                            isOwnMessage ? 'text-right' : 'text-left'
                          }`}>
                            {formatTimestamp(message.timestamp)}
                          </p>
                          {/* Report button - only show for messages from others */}
                          {!isOwnMessage && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleReportMessage(message.id, message.content)}
                              className="opacity-0 group-hover:opacity-100 focus:opacity-100 transition-opacity duration-200 h-6 w-6 p-0 ml-2 hover:bg-destructive/10 hover:text-destructive"
                              title="Report inappropriate message"
                              aria-label="Report message"
                            >
                              <Flag className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Message Input */}
            <div className="border-t p-4">
              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="icon">
                  <Paperclip className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon">
                  <Image className="h-4 w-4" />
                </Button>
                <div className="flex-1 relative">
                  <Input
                    placeholder="Type a message..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    className="pr-10"
                  />
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="absolute right-1 top-1/2 transform -translate-y-1/2"
                  >
                    <Smile className="h-4 w-4" />
                  </Button>
                </div>
                <Button onClick={handleSendMessage}>
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* Info Panel */}
        {showInfo && (
          <div className="lg:col-span-1">
            <Card className="h-full">
              <CardHeader>
                <h3 className="font-medium">Conversation Info</h3>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Profile */}
                <div className="text-center">
                  <Avatar className="w-16 h-16 mx-auto mb-3">
                    <AvatarFallback className="text-lg">{conversation.avatar}</AvatarFallback>
                  </Avatar>
                  <h4 className="font-medium">{conversation.name}</h4>
                  <p className="text-sm text-muted-foreground">{conversation.title}</p>
                  <div className="flex space-x-2 mt-3">
                    <Link to={`/profile/${conversation.id}`} className="flex-1">
                      <Button variant="outline" size="sm" className="w-full">
                        View Profile
                      </Button>
                    </Link>
                  </div>
                </div>

                {/* Quick Actions */}
                <div className="space-y-2">
                  <h5 className="font-medium text-sm">Quick Actions</h5>
                  <div className="space-y-2">
                    <Button variant="outline" size="sm" className="w-full justify-start">
                      <Phone className="h-4 w-4 mr-2" />
                      Voice Call
                    </Button>
                    <Button variant="outline" size="sm" className="w-full justify-start">
                      <Video className="h-4 w-4 mr-2" />
                      Video Call
                    </Button>
                    <Button variant="outline" size="sm" className="w-full justify-start">
                      <File className="h-4 w-4 mr-2" />
                      Share File
                    </Button>
                  </div>
                </div>

                {/* Shared Files/Media */}
                <div className="space-y-2">
                  <h5 className="font-medium text-sm">Shared Media</h5>
                  <p className="text-xs text-muted-foreground">
                    No shared files yet
                  </p>
                </div>

                {/* Conversation Settings */}
                <div className="space-y-2">
                  <h5 className="font-medium text-sm">Settings</h5>
                  <div className="space-y-2">
                    <Button variant="ghost" size="sm" className="w-full justify-start text-muted-foreground">
                      Mute Notifications
                    </Button>
                    <Button variant="ghost" size="sm" className="w-full justify-start text-muted-foreground">
                      Archive Chat
                    </Button>
                    <Button variant="ghost" size="sm" className="w-full justify-start text-destructive">
                      Block User
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}