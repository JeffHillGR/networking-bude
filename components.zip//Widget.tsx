import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Users, Calendar, MessageCircle, Download, Smartphone, Monitor } from 'lucide-react';
import budeLogo from 'figma:asset/3e43a07a7faa73f2f417a9074a180615c3828a87.png';
import { useState, useEffect } from 'react';

interface WidgetProps {
  onLaunchApp: () => void;
}

export function Widget({ onLaunchApp }: WidgetProps) {
  const [platform, setPlatform] = useState<'ios' | 'android' | 'desktop'>('desktop');

  useEffect(() => {
    const userAgent = navigator.userAgent.toLowerCase();
    if (/iphone|ipad|ipod/.test(userAgent)) {
      setPlatform('ios');
    } else if (/android/.test(userAgent)) {
      setPlatform('android');
    } else {
      setPlatform('desktop');
    }
  }, []);

  const handleDownload = () => {
    if (platform === 'ios') {
      // In a real app, this would link to the App Store
      window.open('https://apps.apple.com/search?term=networking', '_blank');
    } else if (platform === 'android') {
      // In a real app, this would link to Google Play Store
      window.open('https://play.google.com/store/search?q=networking', '_blank');
    } else {
      // For desktop, launch the web app
      onLaunchApp();
    }
  };

  const getButtonText = () => {
    switch (platform) {
      case 'ios':
        return 'Download on App Store';
      case 'android':
        return 'Get it on Google Play';
      default:
        return 'Download the App';
    }
  };

  const getButtonIcon = () => {
    switch (platform) {
      case 'ios':
      case 'android':
        return <Smartphone className="ml-2 h-4 w-4 group-hover:scale-110 transition-transform" />;
      default:
        return <Download className="ml-2 h-4 w-4 group-hover:translate-y-1 transition-transform" />;
    }
  };
  return (
    <Card className="w-full max-w-sm mx-auto shadow-lg hover:shadow-xl transition-shadow duration-300 border-2 border-primary/10 bg-gradient-to-br from-background to-accent/20">
      <CardContent className="p-6">
        {/* Header with Logo */}
        <div className="text-center mb-4">
          <div className="flex justify-center mb-3">
            <img src={budeLogo} alt="Networking BudE" className="h-10" />
          </div>
          <h3 className="font-semibold text-lg text-primary">Networking BudE</h3>
          <p className="text-sm text-muted-foreground">
            Professional networking made easier
          </p>
        </div>

        {/* Key Features */}
        <div className="space-y-3 mb-5">
          <div className="flex items-center space-x-3 text-sm">
            <div className="p-1.5 rounded-full bg-primary/10">
              <Users className="h-4 w-4 text-primary" />
            </div>
            <span className="text-muted-foreground">Match with networking buddies</span>
          </div>
          <div className="flex items-center space-x-3 text-sm">
            <div className="p-1.5 rounded-full bg-primary/10">
              <Calendar className="h-4 w-4 text-primary" />
            </div>
            <span className="text-muted-foreground">Attend events together</span>
          </div>
          <div className="flex items-center space-x-3 text-sm">
            <div className="p-1.5 rounded-full bg-primary/10">
              <MessageCircle className="h-4 w-4 text-primary" />
            </div>
            <span className="text-muted-foreground">Build meaningful connections</span>
          </div>
        </div>

        {/* Platform Info */}
        <div className="flex items-center justify-center space-x-2 mb-4 text-xs text-muted-foreground">
          {platform === 'desktop' ? (
            <>
              <Monitor className="h-3 w-3" />
              <span>Available on Web, iOS & Android</span>
            </>
          ) : (
            <>
              <Smartphone className="h-3 w-3" />
              <span>Mobile App Available</span>
            </>
          )}
        </div>

        {/* CTA */}
        <Button 
          onClick={handleDownload}
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium group"
        >
          {getButtonText()}
          {getButtonIcon()}
        </Button>

        {/* Tagline */}
        <p className="text-xs text-center text-muted-foreground mt-3 italic">
          "Why feel awkward alone?"
        </p>

        {/* Cross-platform note */}
        <p className="text-xs text-center text-muted-foreground mt-2">
          {platform === 'desktop' 
            ? 'Try the web version now, get the mobile app later!' 
            : 'Download the full app for the best experience'
          }
        </p>

        {/* Attribution */}
        <div className="text-center mt-4 pt-3 border-t border-border/50">
          <p className="text-xs text-muted-foreground">
            by The Buddy System™
          </p>
        </div>
      </CardContent>
    </Card>
  );
}