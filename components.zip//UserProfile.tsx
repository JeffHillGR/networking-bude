import { useParams, Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Separator } from './ui/separator';
import { 
  ArrowLeft, 
  MapPin, 
  Building, 
  Calendar, 
  GraduationCap, 
  Briefcase,
  Heart,
  MessageCircle,
  Share2,
  Star,
  User,
  Mail,
  Phone,
  Globe,
  Award,
  Users,
  Plane
} from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner@2.0.3';

// Mock user data - in a real app this would come from an API
const USER_DATA = {
  me: {
    id: 'me',
    name: 'Sarah Johnson',
    title: 'Product Manager',
    company: 'TechCorp',
    location: 'San Francisco, CA',
    bio: 'Passionate product manager with 7+ years of experience building user-centric products. I love connecting with fellow PMs, designers, and entrepreneurs to share insights and learn from each other.',
    avatar: 'SJ',
    email: 'sarah.johnson@techcorp.com',
    phone: '+1 (555) 123-4567',
    website: 'sarahjohnson.dev',
    experience: '7 years',
    education: 'Stanford University, MBA',
    interests: ['Product Management', 'Design', 'Technology', 'Startup', 'Leadership'],
    skills: ['Product Strategy', 'User Research', 'Data Analysis', 'Agile', 'Leadership'],
    isOwnProfile: true,
    connections: 234,
    joinDate: '2023-03-15',
    achievements: [
      { title: 'Top Performer 2024', company: 'TechCorp' },
      { title: 'Product Launch Excellence', company: 'TechCorp' },
      { title: 'Leadership Recognition', company: 'Previous Company' }
    ],
    recentActivity: [
      { type: 'event', title: 'Attended Tech Leaders Breakfast', date: '2025-09-15' },
      { type: 'match', title: 'Matched with Alex Chen', date: '2025-09-14' },
      { type: 'event', title: 'Registered for Startup Pitch Night', date: '2025-09-12' }
    ]
  },
  1: {
    id: 1,
    name: 'Alex Chen',
    title: 'Senior Software Engineer',
    company: 'Google',
    location: 'San Francisco, CA',
    bio: 'Passionate about building scalable systems and leading engineering teams. Always interested in discussing the latest in cloud architecture and AI applications.',
    avatar: 'AC',
    experience: '8 years',
    education: 'Stanford University, MS Computer Science',
    interests: ['Technology', 'AI/ML', 'Leadership', 'Startup'],
    skills: ['Python', 'Go', 'Kubernetes', 'System Design', 'Team Leadership'],
    isOwnProfile: false,
    connections: 445,
    joinDate: '2023-01-20',
    mutualConnections: 12,
    matchScore: 95,
    commonInterests: ['Technology', 'AI/ML'],
    achievements: [
      { title: 'Engineering Excellence Award', company: 'Google' },
      { title: 'Tech Lead of the Year', company: 'Google' }
    ]
  }
};

interface UserProfileProps {
  userData?: any;
}

export function UserProfile({ userData }: UserProfileProps) {
  const { id } = useParams();
  const [isLiked, setIsLiked] = useState(false);
  
  // If this is the user's own profile (id === 'me') and we have userData from onboarding
  const isOwnProfile = id === 'me';
  
  let user;
  if (isOwnProfile && userData) {
    // Create user object from onboarding data
    // Handle both old format (name) and new format (firstName + lastName)
    const displayName = userData.name || 
      (userData.firstName && userData.lastName ? `${userData.firstName} ${userData.lastName}` : '') ||
      userData.firstName || 
      userData.lastName || 
      'Unknown User';
    
    // Create avatar initials from firstName/lastName or fallback to splitting name
    let avatarInitials = 'UN';
    if (userData.firstName && userData.lastName) {
      avatarInitials = `${userData.firstName[0]}${userData.lastName[0]}`.toUpperCase();
    } else if (userData.firstName) {
      avatarInitials = userData.firstName.slice(0, 2).toUpperCase();
    } else if (userData.name) {
      avatarInitials = userData.name.split(' ').map((n: string) => n[0]).join('').toUpperCase().slice(0, 2);
    }
    
    user = {
      id: 'me',
      name: displayName,
      title: userData.jobTitle || '', // Use job title from onboarding
      company: '', // We don't collect this in onboarding
      location: userData.zipCode ? `Zip Code: ${userData.zipCode}` : '',
      bio: userData.bio || '',
      avatar: avatarInitials,
      profilePhoto: userData.imageDataUrl || userData.avatar || userData.imageUrl, // Add profile photo support
      email: userData.email || '',
      phone: '', // We don't collect this in onboarding
      website: '', // We don't collect this in onboarding
      experience: '', // We don't collect this in onboarding
      education: '', // We don't collect this in onboarding
      interests: userData.interests || [],
      skills: [], // We don't collect skills separately in onboarding
      isOwnProfile: true,
      connections: 0, // New user starts with 0
      joinDate: new Date().toISOString().split('T')[0], // Today's date
      achievements: [],
      industry: userData.industry || '',
      networkingGoals: userData.networkingGoals || '',
      spareTimeActivities: userData.spareTimeActivities || '',
      associations: userData.associations || [],
      wantedEvents: userData.wantedEvents || [],
      genderPreference: userData.genderPreference || '',
      sameIndustryPreference: userData.sameIndustryPreference || '',
      radius: userData.radius || '',
      tempZipCode: userData.tempZipCode || '',
      tempStartDate: userData.tempStartDate,
      tempEndDate: userData.tempEndDate,
      recentActivity: [
        { type: 'profile', title: 'Profile created', date: new Date().toISOString().split('T')[0] }
      ]
    };
  } else {
    // Use mock data for other profiles
    user = USER_DATA[id as keyof typeof USER_DATA];
  }

  if (!user) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="p-12 text-center">
            <h2 className="text-xl font-semibold mb-2">Profile not found</h2>
            <p className="text-muted-foreground mb-4">
              The profile you're looking for doesn't exist.
            </p>
            <Link to="/matches">
              <Button>Back to Matches</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleLike = () => {
    setIsLiked(!isLiked);
    toast.success(isLiked ? 'Like removed' : 'Like sent! 💕');
  };

  const handleMessage = () => {
    toast.success('Message sent!');
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success('Profile link copied to clipboard!');
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Link to={user.isOwnProfile ? "/dashboard" : "/matches"}>
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl font-semibold">
            {user.isOwnProfile ? 'Your Profile' : `${user.name}'s Profile`}
          </h1>
          <p className="text-muted-foreground">
            {user.isOwnProfile ? 'Manage your professional profile' : 'Professional networking profile'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Profile */}
        <div className="lg:col-span-2 space-y-6">
          {/* Basic Info */}
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row md:items-start space-y-4 md:space-y-0 md:space-x-6">
                <div className="flex flex-col items-center md:items-start">
                  <Avatar className="w-24 h-24 mb-4">
                    {user.profilePhoto ? (
                      <img 
                        src={user.profilePhoto} 
                        alt="Profile" 
                        className="w-full h-full rounded-full object-cover"
                      />
                    ) : (
                      <AvatarFallback className="text-2xl">{user.avatar}</AvatarFallback>
                    )}
                  </Avatar>
                  {user.isOwnProfile && (
                    <Link to="/settings">
                      <Button variant="outline" size="sm">
                        Edit Profile
                      </Button>
                    </Link>
                  )}
                </div>

                <div className="flex-1 text-center md:text-left">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                    <h2 className="text-2xl font-semibold">{user.name}</h2>
                    {!user.isOwnProfile && (
                      <div className="flex items-center space-x-2 mt-2 md:mt-0">
                        <Button variant="ghost" size="icon" onClick={handleShare}>
                          <Share2 className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={handleLike}
                          className={isLiked ? 'text-red-500' : ''}
                        >
                          <Heart className={`h-4 w-4 ${isLiked ? 'fill-current' : ''}`} />
                        </Button>
                        <Button onClick={handleMessage}>
                          <MessageCircle className="h-4 w-4 mr-2" />
                          Message
                        </Button>
                      </div>
                    )}
                  </div>

                  <div className="space-y-2 text-muted-foreground">
                    {user.title && (
                      <div className="flex items-center justify-center md:justify-start space-x-2">
                        <Briefcase className="h-4 w-4" />
                        <span>{user.title}</span>
                      </div>
                    )}
                    {user.company && (
                      <div className="flex items-center justify-center md:justify-start space-x-2">
                        <Building className="h-4 w-4" />
                        <span>{user.company}</span>
                      </div>
                    )}
                    {user.industry && !user.company && (
                      <div className="flex items-center justify-center md:justify-start space-x-2">
                        <Building className="h-4 w-4" />
                        <span>{user.industry}</span>
                      </div>
                    )}
                    {user.location && (
                      <div className="flex items-center justify-center md:justify-start space-x-2">
                        <MapPin className="h-4 w-4" />
                        <span>{user.location}</span>
                      </div>
                    )}
                    {user.education && (
                      <div className="flex items-center justify-center md:justify-start space-x-2">
                        <GraduationCap className="h-4 w-4" />
                        <span>{user.education}</span>
                      </div>
                    )}
                  </div>

                  {!user.isOwnProfile && 'matchScore' in user && (
                    <div className="flex items-center justify-center md:justify-start space-x-2 mt-4">
                      <Star className="h-4 w-4 text-yellow-500" />
                      <span className="font-medium">{user.matchScore}% match</span>
                      {user.mutualConnections && (
                        <>
                          <span className="text-muted-foreground">•</span>
                          <span className="text-sm text-muted-foreground">
                            {user.mutualConnections} mutual connections
                          </span>
                        </>
                      )}
                    </div>
                  )}
                </div>
              </div>

              <Separator className="my-6" />

              <div>
                <h3 className="font-medium mb-2">About</h3>
                <p className="text-muted-foreground">{user.bio}</p>
              </div>
            </CardContent>
          </Card>

          {/* Professional Interests */}
          <Card>
            <CardHeader>
              <CardTitle>Professional Interests</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {user.interests.map((interest) => {
                  const isCommon = !user.isOwnProfile && 'commonInterests' in user && 
                    user.commonInterests?.includes(interest);
                  return (
                    <Badge 
                      key={interest} 
                      variant={isCommon ? "default" : "outline"}
                      className={isCommon ? "bg-green-100 text-green-800 border-green-200" : ""}
                    >
                      {interest}
                      {isCommon && <span className="ml-1">✓</span>}
                    </Badge>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Skills */}
          <Card>
            <CardHeader>
              <CardTitle>Skills & Expertise</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {user.skills.map((skill) => (
                  <Badge key={skill} variant="secondary">
                    {skill}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Networking Goals */}
          {user.networkingGoals && (
            <Card>
              <CardHeader>
                <CardTitle>Networking Goals</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{user.networkingGoals}</p>
              </CardContent>
            </Card>
          )}

          {/* Spare Time Activities */}
          {user.spareTimeActivities && (
            <Card>
              <CardHeader>
                <CardTitle>Interests Outside of Work</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{user.spareTimeActivities}</p>
              </CardContent>
            </Card>
          )}

          {/* Professional Associations */}
          {user.associations && user.associations.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Professional Associations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {user.associations.map((association: string) => (
                    <Badge key={association} variant="outline">
                      {association}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Interested Events */}
          {user.wantedEvents && user.wantedEvents.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Events I'd Like to Attend</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {user.wantedEvents.map((event: string) => (
                    <Badge key={event} variant="secondary">
                      {event}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Travel Plans */}
          {user.tempZipCode && user.tempStartDate && user.tempEndDate && (
            <Card>
              <CardHeader>
                <CardTitle>Travel Plans</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-2 text-sm">
                  <Plane className="h-4 w-4 text-primary" />
                  <span>
                    Traveling to {user.tempZipCode} from {new Date(user.tempStartDate).toLocaleDateString()} to {new Date(user.tempEndDate).toLocaleDateString()}
                  </span>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Achievements */}
          {user.achievements && user.achievements.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Achievements</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {user.achievements.map((achievement, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <Award className="h-5 w-5 text-yellow-500 mt-0.5" />
                      <div>
                        <p className="font-medium">{achievement.title}</p>
                        <p className="text-sm text-muted-foreground">{achievement.company}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Contact Info */}
          {user.isOwnProfile && (
            <Card>
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{user.email}</span>
                </div>
                {user.phone && (
                  <div className="flex items-center space-x-3">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{user.phone}</span>
                  </div>
                )}
                {user.website && (
                  <div className="flex items-center space-x-3">
                    <Globe className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{user.website}</span>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Stats */}
          <Card>
            <CardHeader>
              <CardTitle>Profile Stats</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">Connections</span>
                </div>
                <span className="font-medium">{user.connections}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">Member since</span>
                </div>
                <span className="font-medium">
                  {new Date(user.joinDate).toLocaleDateString('en-US', { 
                    month: 'short', 
                    year: 'numeric' 
                  })}
                </span>
              </div>
              {user.experience && (
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Briefcase className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">Experience</span>
                  </div>
                  <span className="font-medium">{user.experience}</span>
                </div>
              )}
              {user.industry && (
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Building className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">Industry</span>
                  </div>
                  <span className="font-medium text-sm">{user.industry}</span>
                </div>
              )}
              {user.radius && (
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">Match Radius</span>
                  </div>
                  <span className="font-medium text-sm">{user.radius === 'anywhere' ? 'Statewide' : `${user.radius} miles`}</span>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Activity */}
          {user.isOwnProfile && user.recentActivity && (
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {user.recentActivity.map((activity, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                      <div className="flex-1">
                        <p className="text-sm">{activity.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(activity.date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Actions */}
          {!user.isOwnProfile && (
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full" onClick={handleMessage}>
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Send Message
                </Button>
                <Button variant="outline" className="w-full" onClick={handleLike}>
                  <Heart className={`h-4 w-4 mr-2 ${isLiked ? 'fill-current' : ''}`} />
                  {isLiked ? 'Unlike' : 'Like Profile'}
                </Button>
                <Button variant="outline" className="w-full" onClick={handleShare}>
                  <Share2 className="h-4 w-4 mr-2" />
                  Share Profile
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}