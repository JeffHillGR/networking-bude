import { Users, MapPin } from 'lucide-react';
import networkingEventImage from 'figma:asset/8d47b3f43908ac23e739b09083d94ccc7bc57cae.png';

export function NetworkingEventBanner() {
  return (
    <div className="relative h-32 md:h-40 rounded-lg overflow-hidden mb-6">
      <img 
        src={networkingEventImage} 
        alt="Professional networking event"
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
      <div className="absolute bottom-4 left-6 right-6 text-white">
        <h2 className="text-lg md:text-xl mb-1 flex items-center space-x-2">
          <Users className="h-4 w-4" />
          <span>Discover. Connect. Grow.</span>
        </h2>
        <p className="text-xs md:text-sm opacity-90">
          Join professionals making meaningful connections
        </p>
      </div>
    </div>
  );
}