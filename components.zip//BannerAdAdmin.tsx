import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Textarea } from './ui/textarea';
import { 
  Plus, 
  Edit, 
  Trash2, 
  Eye, 
  EyeOff,
  ExternalLink,
  BarChart3,
  Calendar,
  Users,
  MousePointer,
  TrendingUp,
  Image,
  Copy,
  Refresh
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { useBannerAds, BannerAd } from '../hooks/useBannerAds';
import { DynamicBannerAd } from './DynamicBannerAd';

interface BannerAdFormData {
  name: string;
  imageUrl: string;
  title: string;
  subtitle: string;
  ctaText: string;
  ctaUrl: string;
  isActive: boolean;
  priority: number;
  targetPages: ('dashboard' | 'events' | 'connections' | 'all')[];
  startDate: string;
  endDate: string;
}

const TARGET_PAGE_OPTIONS = [
  { id: 'dashboard', name: 'Dashboard', color: 'blue' },
  { id: 'events', name: 'Events', color: 'green' },
  { id: 'connections', name: 'Connections', color: 'purple' },
  { id: 'all', name: 'All Pages', color: 'orange' }
];

const SAMPLE_IMAGES = [
  'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800&h=240&fit=crop&crop=center',
  'https://images.unsplash.com/photo-1552664730-d307ca884978?w=800&h=240&fit=crop&crop=center',
  'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=800&h=240&fit=crop&crop=center',
  'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&h=240&fit=crop&crop=center',
  'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=240&fit=crop&crop=center'
];

export function BannerAdAdmin() {
  const {
    bannerAds,
    createBannerAd,
    updateBannerAd,
    deleteBannerAd,
    toggleBannerAdStatus,
    getBannerStatistics,
    getActiveBannerAds
  } = useBannerAds();

  const [showForm, setShowForm] = useState(false);
  const [editingAd, setEditingAd] = useState<BannerAd | null>(null);
  const [previewPage, setPreviewPage] = useState<'dashboard' | 'events' | 'connections'>('dashboard');
  const [formData, setFormData] = useState<BannerAdFormData>({
    name: '',
    imageUrl: '',
    title: '',
    subtitle: '',
    ctaText: 'Learn More',
    ctaUrl: '',
    isActive: true,
    priority: 5,
    targetPages: ['all'],
    startDate: '',
    endDate: ''
  });

  const stats = getBannerStatistics();

  const handleFormSubmit = () => {
    // Validation
    if (!formData.name.trim()) {
      toast.error('Please enter a banner name');
      return;
    }
    if (!formData.title.trim()) {
      toast.error('Please enter a banner title');
      return;
    }
    if (!formData.imageUrl.trim()) {
      toast.error('Please enter an image URL');
      return;
    }
    if (!formData.ctaText.trim()) {
      toast.error('Please enter CTA text');
      return;
    }
    if (!formData.ctaUrl.trim()) {
      toast.error('Please enter a CTA URL');
      return;
    }
    if (formData.targetPages.length === 0) {
      toast.error('Please select at least one target page');
      return;
    }

    const bannerData = {
      name: formData.name.trim(),
      imageUrl: formData.imageUrl.trim(),
      title: formData.title.trim(),
      subtitle: formData.subtitle.trim(),
      ctaText: formData.ctaText.trim(),
      ctaUrl: formData.ctaUrl.trim(),
      isActive: formData.isActive,
      priority: formData.priority,
      targetPages: formData.targetPages,
      schedule: (formData.startDate || formData.endDate) ? {
        startDate: formData.startDate || undefined,
        endDate: formData.endDate || undefined
      } : undefined
    };

    if (editingAd) {
      updateBannerAd(editingAd.id, bannerData);
    } else {
      createBannerAd(bannerData);
    }

    handleFormCancel();
  };

  const handleFormCancel = () => {
    setShowForm(false);
    setEditingAd(null);
    setFormData({
      name: '',
      imageUrl: '',
      title: '',
      subtitle: '',
      ctaText: 'Learn More',
      ctaUrl: '',
      isActive: true,
      priority: 5,
      targetPages: ['all'],
      startDate: '',
      endDate: ''
    });
  };

  const handleEditAd = (ad: BannerAd) => {
    setEditingAd(ad);
    setFormData({
      name: ad.name,
      imageUrl: ad.imageUrl,
      title: ad.title,
      subtitle: ad.subtitle || '',
      ctaText: ad.ctaText,
      ctaUrl: ad.ctaUrl,
      isActive: ad.isActive,
      priority: ad.priority,
      targetPages: ad.targetPages,
      startDate: ad.schedule?.startDate || '',
      endDate: ad.schedule?.endDate || ''
    });
    setShowForm(true);
  };

  const handlePageToggle = (pageId: string) => {
    if (pageId === 'all') {
      // If selecting "all", clear other selections
      setFormData(prev => ({
        ...prev,
        targetPages: prev.targetPages.includes('all') ? [] : ['all']
      }));
    } else {
      setFormData(prev => {
        const newPages = prev.targetPages.includes('all')
          ? [pageId as any] // If "all" was selected, replace with specific page
          : prev.targetPages.includes(pageId as any)
            ? prev.targetPages.filter(p => p !== pageId)
            : [...prev.targetPages.filter(p => p !== 'all'), pageId as any];
        
        return { ...prev, targetPages: newPages };
      });
    }
  };

  const copyAdData = (ad: BannerAd) => {
    navigator.clipboard.writeText(JSON.stringify({
      name: ad.name,
      imageUrl: ad.imageUrl,
      title: ad.title,
      subtitle: ad.subtitle,
      ctaText: ad.ctaText,
      ctaUrl: ad.ctaUrl,
      targetPages: ad.targetPages,
      priority: ad.priority
    }, null, 2));
    toast.success('Banner ad data copied to clipboard!');
  };

  const getStatusBadgeVariant = (isActive: boolean, schedule?: { startDate?: string; endDate?: string }) => {
    if (!isActive) return 'secondary';
    
    if (schedule) {
      const now = new Date();
      if (schedule.startDate && new Date(schedule.startDate) > now) return 'outline';
      if (schedule.endDate && new Date(schedule.endDate) < now) return 'destructive';
    }
    
    return 'default';
  };

  const getStatusLabel = (isActive: boolean, schedule?: { startDate?: string; endDate?: string }) => {
    if (!isActive) return 'Inactive';
    
    if (schedule) {
      const now = new Date();
      if (schedule.startDate && new Date(schedule.startDate) > now) return 'Scheduled';
      if (schedule.endDate && new Date(schedule.endDate) < now) return 'Expired';
    }
    
    return 'Active';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold">Banner Ad Management</h2>
          <p className="text-muted-foreground">
            Create and manage banner advertisements across Networking BudE
          </p>
        </div>
        <Button
          onClick={() => setShowForm(true)}
          className="bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="h-4 w-4 mr-2" />
          Create Banner Ad
        </Button>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <BarChart3 className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-2xl font-semibold">{stats.totalAds}</p>
                <p className="text-sm text-muted-foreground">Total Banners</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <Eye className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-2xl font-semibold">{stats.activeAds}</p>
                <p className="text-sm text-muted-foreground">Active Banners</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <Users className="h-8 w-8 text-purple-600" />
              <div>
                <p className="text-2xl font-semibold">{stats.totalViews.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Total Views</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <MousePointer className="h-8 w-8 text-orange-600" />
              <div>
                <p className="text-2xl font-semibold">{stats.totalClicks.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Total Clicks</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-8 w-8 text-red-600" />
              <div>
                <p className="text-2xl font-semibold">{stats.averageCTR.toFixed(1)}%</p>
                <p className="text-sm text-muted-foreground">Average CTR</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Live Preview */}
      <Card className="border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Eye className="h-5 w-5" />
            <span>Live Preview</span>
          </CardTitle>
          <CardDescription>
            See how banner ads appear on different pages
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Page selector */}
          <div className="flex space-x-2">
            {TARGET_PAGE_OPTIONS.slice(0, 3).map((page) => (
              <Button
                key={page.id}
                variant={previewPage === page.id ? 'default' : 'outline'}
                size="sm"
                onClick={() => setPreviewPage(page.id as any)}
              >
                {page.name}
              </Button>
            ))}
          </div>
          
          {/* Preview */}
          <div className="border-2 border-dashed border-muted rounded-lg p-4 bg-muted/20">
            <DynamicBannerAd 
              page={previewPage} 
              showRotateButton={true}
              isAdminMode={true}
            />
            {getActiveBannerAds(previewPage).length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                No active banner ads for {previewPage} page
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Create/Edit Form */}
      {showForm && (
        <Card className="border-blue-200">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Plus className="h-5 w-5" />
              <span>{editingAd ? 'Edit Banner Ad' : 'Create New Banner Ad'}</span>
            </CardTitle>
            <CardDescription>
              {editingAd ? 'Modify the existing banner ad' : 'Create a new banner advertisement'}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Basic Info */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Banner Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., Grand Rapids Chamber Networking"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="title">Display Title *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="e.g., Join Grand Rapids Chamber"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="subtitle">Subtitle (Optional)</Label>
                  <Input
                    id="subtitle"
                    value={formData.subtitle}
                    onChange={(e) => setFormData(prev => ({ ...prev, subtitle: e.target.value }))}
                    placeholder="e.g., Connect with 2,000+ local business leaders"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="ctaText">CTA Button Text *</Label>
                    <Input
                      id="ctaText"
                      value={formData.ctaText}
                      onChange={(e) => setFormData(prev => ({ ...prev, ctaText: e.target.value }))}
                      placeholder="Learn More"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="priority">Priority (1-10)</Label>
                    <Input
                      id="priority"
                      type="number"
                      min="1"
                      max="10"
                      value={formData.priority}
                      onChange={(e) => setFormData(prev => ({ ...prev, priority: parseInt(e.target.value) || 5 }))}
                    />
                  </div>
                </div>
              </div>

              {/* Image and URL */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="imageUrl">Image URL *</Label>
                  <Input
                    id="imageUrl"
                    value={formData.imageUrl}
                    onChange={(e) => setFormData(prev => ({ ...prev, imageUrl: e.target.value }))}
                    placeholder="https://..."
                  />
                  
                  {/* Sample images */}
                  <div className="flex flex-wrap gap-2 mt-2">
                    <span className="text-xs text-muted-foreground">Quick select:</span>
                    {SAMPLE_IMAGES.map((url, index) => (
                      <Button
                        key={index}
                        variant="ghost"
                        size="sm"
                        className="h-6 text-xs"
                        onClick={() => setFormData(prev => ({ ...prev, imageUrl: url }))}
                      >
                        <Image className="h-3 w-3 mr-1" />
                        Sample {index + 1}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="ctaUrl">CTA URL *</Label>
                  <Input
                    id="ctaUrl"
                    value={formData.ctaUrl}
                    onChange={(e) => setFormData(prev => ({ ...prev, ctaUrl: e.target.value }))}
                    placeholder="https://... or /internal-page"
                  />
                </div>

                {/* Image preview */}
                {formData.imageUrl && (
                  <div className="space-y-2">
                    <Label>Image Preview</Label>
                    <div className="border rounded-lg overflow-hidden bg-muted">
                      <img
                        src={formData.imageUrl}
                        alt="Preview"
                        className="w-full h-24 object-cover"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                        }}
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Target Pages */}
            <div className="space-y-2">
              <Label>Target Pages *</Label>
              <div className="flex flex-wrap gap-2">
                {TARGET_PAGE_OPTIONS.map((page) => (
                  <Button
                    key={page.id}
                    type="button"
                    variant={formData.targetPages.includes(page.id as any) ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => handlePageToggle(page.id)}
                    className={formData.targetPages.includes(page.id as any) ? `bg-${page.color}-600 hover:bg-${page.color}-700` : ''}
                  >
                    {page.name}
                  </Button>
                ))}
              </div>
            </div>

            {/* Schedule */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="startDate">Start Date (Optional)</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={formData.startDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, startDate: e.target.value }))}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="endDate">End Date (Optional)</Label>
                <Input
                  id="endDate"
                  type="date"
                  value={formData.endDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, endDate: e.target.value }))}
                />
              </div>
            </div>

            {/* Status */}
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="isActive"
                checked={formData.isActive}
                onChange={(e) => setFormData(prev => ({ ...prev, isActive: e.target.checked }))}
                className="rounded border-gray-300"
              />
              <Label htmlFor="isActive">Active (visible to users)</Label>
            </div>

            <Separator />

            {/* Form Actions */}
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={handleFormCancel}>
                Cancel
              </Button>
              <Button onClick={handleFormSubmit} className="bg-blue-600 hover:bg-blue-700">
                {editingAd ? 'Update Banner' : 'Create Banner'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Existing Banner Ads */}
      <Card>
        <CardHeader>
          <CardTitle>Existing Banner Ads</CardTitle>
          <CardDescription>
            Manage all banner advertisements and view their performance
          </CardDescription>
        </CardHeader>
        <CardContent>
          {bannerAds.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No banner ads created yet.</p>
              <Button
                onClick={() => setShowForm(true)}
                className="mt-4 bg-blue-600 hover:bg-blue-700"
              >
                Create Your First Banner Ad
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {bannerAds.map((ad) => (
                <Card key={ad.id} className="border">
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <div className="space-y-3 flex-1">
                        <div className="flex items-center space-x-3">
                          <h4 className="font-medium">{ad.name}</h4>
                          <Badge variant={getStatusBadgeVariant(ad.isActive, ad.schedule)}>
                            {getStatusLabel(ad.isActive, ad.schedule)}
                          </Badge>
                          <span className="text-sm text-muted-foreground">
                            Priority: {ad.priority}
                          </span>
                        </div>
                        
                        <div className="space-y-1">
                          <p className="font-medium">{ad.title}</p>
                          {ad.subtitle && (
                            <p className="text-sm text-muted-foreground">{ad.subtitle}</p>
                          )}
                        </div>
                        
                        {/* Target pages */}
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-muted-foreground">Pages:</span>
                          <div className="flex space-x-1">
                            {ad.targetPages.map((page) => {
                              const pageOption = TARGET_PAGE_OPTIONS.find(p => p.id === page);
                              return (
                                <Badge key={page} variant="outline" className="text-xs">
                                  {pageOption?.name || page}
                                </Badge>
                              );
                            })}
                          </div>
                        </div>

                        {/* Analytics */}
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <span>Views: {ad.analytics.views.toLocaleString()}</span>
                          <span>Clicks: {ad.analytics.clicks.toLocaleString()}</span>
                          <span>CTR: {ad.analytics.ctr.toFixed(1)}%</span>
                          {ad.schedule?.endDate && (
                            <span>Expires: {new Date(ad.schedule.endDate).toLocaleDateString()}</span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyAdData(ad)}
                          title="Copy ad data"
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleBannerAdStatus(ad.id)}
                          className={ad.isActive ? "text-orange-600" : "text-green-600"}
                        >
                          {ad.isActive ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditAd(ad)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteBannerAd(ad.id)}
                          className="text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}