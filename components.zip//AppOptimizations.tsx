// App optimizations component - Extracted optimization features from App.tsx
import { memo, useEffect, useCallback } from 'react';
import { useLocation } from 'react-router-dom';

interface AppOptimizationsProps {
  enableSEO?: boolean;
  enableSecurityHeaders?: boolean;
  enablePerformanceMonitoring?: boolean;
  enableAccessibility?: boolean;
}

const DEFAULT_PROPS: AppOptimizationsProps = {
  enableSEO: true,
  enableSecurityHeaders: true,
  enablePerformanceMonitoring: true,
  enableAccessibility: true
};

// SEO and metadata management
const useMetadata = () => {
  const location = useLocation();
  
  useEffect(() => {
    const routeMetadata = {
      '/dashboard': {
        title: 'Dashboard - Networking BudE',
        description: 'Your professional networking dashboard for Grand Rapids connections'
      },
      '/events': {
        title: 'Events - Networking BudE',
        description: 'Discover professional networking events in Grand Rapids'
      },
      '/connections': {
        title: 'Connections - Networking BudE',
        description: 'Build meaningful professional relationships in Grand Rapids'
      },
      '/messenger': {
        title: 'Messages - Networking BudE',
        description: 'Connect with your professional network'
      }
    };
    
    const metadata = routeMetadata[location.pathname as keyof typeof routeMetadata] || {
      title: 'Networking BudE - Professional Networking in Grand Rapids',
      description: 'Connect with professionals, discover events, and grow your network in Grand Rapids'
    };
    
    // Update document title
    document.title = metadata.title;
    
    // Update meta description
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', metadata.description);
    
    // Update Open Graph tags
    const ogTags = [
      { property: 'og:title', content: metadata.title },
      { property: 'og:description', content: metadata.description },
      { property: 'og:type', content: 'website' },
      { property: 'og:url', content: window.location.href }
    ];
    
    ogTags.forEach(({ property, content }) => {
      let tag = document.querySelector(`meta[property="${property}"]`);
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('property', property);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    });
  }, [location.pathname]);
};

// Security headers management
const useSecurityHeaders = () => {
  useEffect(() => {
    const securityHeaders = [
      { name: 'X-Content-Type-Options', content: 'nosniff' },
      { name: 'X-Frame-Options', content: 'DENY' },
      { name: 'X-XSS-Protection', content: '1; mode=block' },
      { name: 'Referrer-Policy', content: 'strict-origin-when-cross-origin' }
    ];
    
    securityHeaders.forEach(({ name, content }) => {
      let meta = document.querySelector(`meta[http-equiv="${name}"]`);
      if (!meta) {
        meta = document.createElement('meta');
        meta.setAttribute('http-equiv', name);
        document.head.appendChild(meta);
      }
      meta.setAttribute('content', content);
    });
  }, []);
};

// PWA meta tags
const usePWAHeaders = () => {
  useEffect(() => {
    const pwaHeaders = [
      { name: 'apple-mobile-web-app-capable', content: 'yes' },
      { name: 'apple-mobile-web-app-status-bar-style', content: 'default' },
      { name: 'apple-mobile-web-app-title', content: 'Networking BudE' },
      { name: 'mobile-web-app-capable', content: 'yes' },
      { name: 'theme-color', content: '#22c55e' }
    ];
    
    pwaHeaders.forEach(({ name, content }) => {
      let meta = document.querySelector(`meta[name="${name}"]`);
      if (!meta) {
        meta = document.createElement('meta');
        meta.setAttribute('name', name);
        document.head.appendChild(meta);
      }
      meta.setAttribute('content', content);
    });
  }, []);
};

// Performance monitoring
const usePerformanceMonitoring = () => {
  const logMetric = useCallback((name: string, value: number) => {
    if (process.env.NODE_ENV === 'development') {
      console.log(`Performance metric - ${name}: ${value.toFixed(2)}ms`);
    }
    // Could send to analytics service in production
  }, []);

  useEffect(() => {
    if (typeof window.performance !== 'object') return;
    
    // Monitor Largest Contentful Paint
    const lcpObserver = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      const lastEntry = entries[entries.length - 1];
      logMetric('LCP', lastEntry.startTime);
    });
    
    // Monitor Cumulative Layout Shift
    let clsValue = 0;
    const clsObserver = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (!entry.hadRecentInput) {
          clsValue += entry.value;
          logMetric('CLS', clsValue);
        }
      }
    });
    
    // Monitor First Input Delay
    const fidObserver = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        logMetric('FID', entry.processingStart - entry.startTime);
      }
    });

    try {
      lcpObserver.observe({ entryTypes: ['largest-contentful-paint'] });
      clsObserver.observe({ entryTypes: ['layout-shift'] });
      fidObserver.observe({ entryTypes: ['first-input'] });
    } catch (error) {
      console.warn('Performance observer not supported:', error);
    }
    
    return () => {
      lcpObserver.disconnect();
      clsObserver.disconnect();
      fidObserver.disconnect();
    };
  }, [logMetric]);
};

// Accessibility enhancements
const useAccessibilityEnhancements = () => {
  useEffect(() => {
    // Set language attribute
    document.documentElement.lang = 'en';
    
    // Keyboard navigation indicator
    const handleKeyDown = () => {
      document.body.setAttribute('data-using-keyboard', 'true');
    };
    
    const handleMouseDown = () => {
      document.body.setAttribute('data-using-keyboard', 'false');
    };
    
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('mousedown', handleMouseDown);
    
    // Touch device detection
    if ('ontouchstart' in window) {
      document.body.classList.add('touch-device');
    }
    
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('mousedown', handleMouseDown);
    };
  }, []);
};

// Enhanced viewport setup
const useViewportOptimization = () => {
  useEffect(() => {
    let viewport = document.querySelector('meta[name="viewport"]');
    if (!viewport) {
      viewport = document.createElement('meta');
      viewport.setAttribute('name', 'viewport');
      document.head.appendChild(viewport);
    }
    viewport.setAttribute(
      'content', 
      'width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes, viewport-fit=cover'
    );
  }, []);
};

export const AppOptimizations = memo<AppOptimizationsProps>(({
  enableSEO = DEFAULT_PROPS.enableSEO,
  enableSecurityHeaders = DEFAULT_PROPS.enableSecurityHeaders,
  enablePerformanceMonitoring = DEFAULT_PROPS.enablePerformanceMonitoring,
  enableAccessibility = DEFAULT_PROPS.enableAccessibility
}) => {
  // Apply optimizations based on props
  if (enableSEO) useMetadata();
  if (enableSecurityHeaders) useSecurityHeaders();
  if (enablePerformanceMonitoring) usePerformanceMonitoring();
  if (enableAccessibility) useAccessibilityEnhancements();
  
  // Always apply these core optimizations
  usePWAHeaders();
  useViewportOptimization();
  
  // This component doesn't render anything - it's purely for side effects
  return null;
});

AppOptimizations.displayName = 'AppOptimizations';