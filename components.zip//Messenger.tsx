import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { 
  Search, 
  MessageCircle, 
  Phone, 
  Video, 
  MoreHorizontal,
  Send,
  Paperclip,
  Smile,
  Clock
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useMessagingAccess } from '../hooks/useSubscription';
import { UpgradePrompt } from './UpgradePrompt';

const CONVERSATIONS = [
  {
    id: 1,
    name: 'Sarah Thompson',
    title: 'UX Designer at Adobe',
    avatar: 'ST',
    lastMessage: 'Looking forward to our coffee chat!',
    timestamp: '2025-09-16T14:30:00Z',
    unreadCount: 2,
    isOnline: true
  },
  {
    id: 2,
    name: 'Michael Brown',
    title: 'Data Scientist at Netflix',
    avatar: 'MB',
    lastMessage: 'Thanks for the ML resources!',
    timestamp: '2025-09-16T09:15:00Z',
    unreadCount: 0,
    isOnline: false
  },
  {
    id: 3,
    name: 'Lisa Wang',
    title: 'Startup Founder',
    avatar: 'LW',
    lastMessage: 'Would love to discuss your product strategy approach. Are you free this week?',
    timestamp: '2025-09-15T16:45:00Z',
    unreadCount: 1,
    isOnline: true
  },
  {
    id: 4,
    name: 'Alex Chen',
    title: 'Senior Engineer at Google',
    avatar: 'AC',
    lastMessage: 'The tech conference was amazing! Did you catch the AI session?',
    timestamp: '2025-09-15T11:20:00Z',
    unreadCount: 0,
    isOnline: false
  },
  {
    id: 5,
    name: 'Jennifer Walsh',
    title: 'VP Sales at Salesforce',
    avatar: 'JW',
    lastMessage: 'Great meeting you at the networking event yesterday.',
    timestamp: '2025-09-14T18:30:00Z',
    unreadCount: 0,
    isOnline: true
  },
  {
    id: 6,
    name: 'David Kim',
    title: 'Product Manager at Meta',
    avatar: 'DK',
    lastMessage: 'Hey! I saw your post about product metrics. Very insightful.',
    timestamp: '2025-09-14T10:10:00Z',
    unreadCount: 0,
    isOnline: false
  }
];

export function Messenger() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedConversation, setSelectedConversation] = useState<number | null>(null);
  const [showUpgradePrompt, setShowUpgradePrompt] = useState(false);
  
  // Subscription hooks
  const { canMessage, requireMessagingUpgrade } = useMessagingAccess();

  const filteredConversations = CONVERSATIONS.filter(conversation =>
    conversation.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    conversation.lastMessage.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 1) {
      const diffInMinutes = Math.floor(diffInHours * 60);
      return `${diffInMinutes}m ago`;
    } else if (diffInHours < 24) {
      return `${Math.floor(diffInHours)}h ago`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      return `${diffInDays}d ago`;
    }
  };

  const selectedConv = selectedConversation ? 
    CONVERSATIONS.find(c => c.id === selectedConversation) : null;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl mb-2">Messages</h1>
        <p className="text-muted-foreground">
          Connect and chat with your professional network
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[600px]">
        {/* Conversations List */}
        <div className="lg:col-span-1">
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Conversations</span>
                <Badge variant="secondary">
                  {CONVERSATIONS.filter(c => c.unreadCount > 0).length} unread
                </Badge>
              </CardTitle>
              <CardDescription>
                Your recent conversations
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              {/* Search */}
              <div className="p-4 border-b">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    placeholder="Search conversations..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9"
                  />
                </div>
              </div>

              {/* Conversation List */}
              <div className="overflow-y-auto max-h-[400px]">
                {filteredConversations.map((conversation) => (
                  <div
                    key={conversation.id}
                    className={`flex items-center space-x-3 p-4 hover:bg-accent cursor-pointer border-b transition-colors ${
                      selectedConversation === conversation.id ? 'bg-accent' : ''
                    }`}
                    onClick={() => {
                      if (!canMessage()) {
                        setShowUpgradePrompt(true);
                        return;
                      }
                      setSelectedConversation(conversation.id);
                    }}
                  >
                    <div className="relative">
                      <Avatar>
                        <AvatarFallback>{conversation.avatar}</AvatarFallback>
                      </Avatar>
                      {conversation.isOnline && (
                        <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                      )}
                      {conversation.unreadCount > 0 && (
                        <div className="absolute -top-1 -right-1 w-5 h-5 bg-primary rounded-full flex items-center justify-center text-xs text-primary-foreground">
                          {conversation.unreadCount}
                        </div>
                      )}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium truncate">{conversation.name}</h4>
                        <span className="text-xs text-muted-foreground">
                          {formatTimestamp(conversation.timestamp)}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">{conversation.title}</p>
                      <p className={`text-sm truncate ${
                        conversation.unreadCount > 0 ? 'font-medium text-foreground' : 'text-muted-foreground'
                      }`}>
                        {conversation.lastMessage}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {filteredConversations.length === 0 && (
                <div className="p-8 text-center">
                  <MessageCircle className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">No conversations found</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Chat Area */}
        <div className="lg:col-span-2">
          <Card className="h-full flex flex-col">
            {selectedConv && canMessage() ? (
              <>
                {/* Chat Header */}
                <CardHeader className="border-b">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="relative">
                        <Avatar>
                          <AvatarFallback>{selectedConv.avatar}</AvatarFallback>
                        </Avatar>
                        {selectedConv.isOnline && (
                          <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                        )}
                      </div>
                      <div>
                        <h3 className="font-medium">{selectedConv.name}</h3>
                        <p className="text-sm text-muted-foreground">{selectedConv.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {selectedConv.isOnline ? 'Online now' : `Last seen ${formatTimestamp(selectedConv.timestamp)}`}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button variant="ghost" size="icon">
                        <Phone className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <Video className="h-4 w-4" />
                      </Button>
                      <Link to={`/messenger/${selectedConv.id}`}>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </Link>
                    </div>
                  </div>
                </CardHeader>

                {/* Messages Area */}
                <div className="flex-1 p-4 overflow-y-auto">
                  <div className="text-center text-sm text-muted-foreground mb-4">
                    <p>This is the beginning of your conversation with {selectedConv.name}</p>
                  </div>
                  
                  {/* Sample messages */}
                  <div className="space-y-4">
                    <div className="flex justify-end">
                      <div className="bg-primary text-primary-foreground rounded-lg p-3 max-w-[70%]">
                        <p className="text-sm">Hi! I saw your profile and thought we might have some interesting things to discuss about product management.</p>
                        <p className="text-xs opacity-70 mt-1">2:30 PM</p>
                      </div>
                    </div>
                    
                    <div className="flex justify-start">
                      <div className="bg-muted rounded-lg p-3 max-w-[70%]">
                        <p className="text-sm">{selectedConv.lastMessage}</p>
                        <p className="text-xs text-muted-foreground mt-1">{formatTimestamp(selectedConv.timestamp)}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Message Input */}
                <div className="border-t p-4">
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="icon">
                      <Paperclip className="h-4 w-4" />
                    </Button>
                    <div className="flex-1 relative">
                      <Input
                        placeholder="Type a message..."
                        className="pr-10"
                      />
                      <Button variant="ghost" size="icon" className="absolute right-1 top-1/2 transform -translate-y-1/2">
                        <Smile className="h-4 w-4" />
                      </Button>
                    </div>
                    <Button>
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </>
            ) : (
              /* No conversation selected */
              <CardContent className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <MessageCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-medium mb-2">Select a conversation</h3>
                  <p className="text-sm text-muted-foreground">
                    Choose a conversation from the left to start messaging
                  </p>
                </div>
              </CardContent>
            )}
          </Card>
        </div>
      </div>

      {/* Upgrade Prompt Modal */}
      <UpgradePrompt
        isOpen={showUpgradePrompt}
        onClose={() => setShowUpgradePrompt(false)}
        feature="messaging"
        context="to send and receive messages"
      />
    </div>
  );
}