import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { 
  Star, 
  TrendingUp, 
  Users, 
  Briefcase, 
  DollarSign,
  MessageCircle,
  Calendar,
  Award,
  Target,
  Heart,
  Building2,
  MapPin
} from 'lucide-react';

const successStories = [
  {
    id: 1,
    user: 'Sarah Chen',
    title: 'Senior Product Manager',
    company: 'Meta',
    image: 'https://images.unsplash.com/photo-1494790108755-2616b612b65c?w=64&h=64&fit=crop&crop=face',
    story: 'Found my co-founder through Networking BudE and raised $2.5M in Series A funding',
    outcome: 'Started unicorn startup',
    value: '$2.5M raised',
    timeframe: '6 months'
  },
  {
    id: 2,
    user: 'Marcus Johnson',
    title: 'VP Engineering',
    company: 'Stripe',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=64&h=64&fit=crop&crop=face',
    story: 'Connected with a mentor who helped me transition from IC to leadership role',
    outcome: 'Promoted to VP',
    value: '40% salary increase',
    timeframe: '8 months'
  },
  {
    id: 3,
    user: 'Emily Rodriguez',
    title: 'Marketing Director',
    company: 'Airbnb',
    image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop&crop=face',
    story: 'Met my business partners at a networking event and launched successful agency',
    outcome: 'Founded agency',
    value: '$1.2M ARR',
    timeframe: '12 months'
  }
];

const platformROI = [
  {
    metric: 'Average Salary Increase',
    value: '28%',
    description: 'Users report significant salary growth after making connections',
    icon: TrendingUp,
    color: 'text-green-600'
  },
  {
    metric: 'Job Placement Success',
    value: '73%',
    description: 'Users who actively network find new opportunities within 6 months',
    icon: Briefcase,
    color: 'text-blue-600'
  },
  {
    metric: 'Business Partnerships',
    value: '156',
    description: 'New business partnerships formed through platform connections',
    icon: Building2,
    color: 'text-purple-600'
  },
  {
    metric: 'Funding Secured',
    value: '$47M',
    description: 'Total funding raised by startups formed through platform',
    icon: DollarSign,
    color: 'text-yellow-600'
  }
];

const networkingImpact = [
  {
    category: 'Career Advancement',
    stats: [
      { label: 'Promotions', value: '342', change: '+24%' },
      { label: 'Job Changes', value: '567', change: '+31%' },
      { label: 'Salary Increases', value: '89%', change: '+12%' }
    ]
  },
  {
    category: 'Business Development',
    stats: [
      { label: 'New Partnerships', value: '156', change: '+45%' },
      { label: 'Client Acquisitions', value: '289', change: '+38%' },
      { label: 'Revenue Generated', value: '$12M', change: '+52%' }
    ]
  },
  {
    category: 'Knowledge Sharing',
    stats: [
      { label: 'Mentoring Relationships', value: '423', change: '+28%' },
      { label: 'Skill Exchanges', value: '678', change: '+19%' },
      { label: 'Industry Insights', value: '1.2K', change: '+33%' }
    ]
  }
];

const testimonials = [
  {
    user: 'Alex Thompson',
    title: 'CTO, TechStart Inc.',
    rating: 5,
    text: 'Networking BudE completely transformed how I approach professional relationships. The quality of connections is unmatched.',
    outcome: 'Hired 3 key team members'
  },
  {
    user: 'Priya Patel',
    title: 'Investment Manager',
    rating: 5,
    text: 'The platform\'s matching algorithm is incredibly sophisticated. I\'ve made connections that directly led to deal flow.',
    outcome: '$5M in new investments'
  },
  {
    user: 'James Wilson',
    title: 'Startup Founder',
    rating: 5,
    text: 'Met my advisor, first customer, and lead investor all through this platform. It\'s been instrumental to our success.',
    outcome: 'Successful Series A'
  }
];

const corporateClients = [
  { name: 'Google', logo: 'G', users: 340, engagement: '94%' },
  { name: 'Microsoft', logo: 'M', users: 280, engagement: '91%' },
  { name: 'Apple', logo: 'A', users: 220, engagement: '96%' },
  { name: 'Amazon', logo: 'A', users: 195, engagement: '89%' },
  { name: 'Meta', logo: 'M', users: 165, engagement: '93%' },
  { name: 'Tesla', logo: 'T', users: 120, engagement: '88%' }
];

export function SuccessMetrics() {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl mb-2">Success Stories & ROI</h1>
        <p className="text-muted-foreground">
          Real impact delivered to professionals and organizations through our platform
        </p>
      </div>

      {/* Key ROI Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {platformROI.map((item, index) => (
          <Card key={index}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <item.icon className={`h-6 w-6 ${item.color}`} />
                <Badge variant="outline">ROI</Badge>
              </div>
              <p className="text-2xl font-bold mb-1">{item.value}</p>
              <p className="text-sm font-medium mb-2">{item.metric}</p>
              <p className="text-xs text-muted-foreground">{item.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Success Stories */}
      <Card>
        <CardHeader>
          <CardTitle>Featured Success Stories</CardTitle>
          <CardDescription>How our platform creates real value for professionals</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {successStories.map((story) => (
              <div key={story.id} className="border rounded-lg p-4 space-y-4">
                <div className="flex items-center space-x-3">
                  <Avatar>
                    <AvatarImage src={story.image} alt={story.user} />
                    <AvatarFallback>{story.user.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{story.user}</p>
                    <p className="text-sm text-muted-foreground">{story.title}</p>
                    <p className="text-sm text-muted-foreground">{story.company}</p>
                  </div>
                </div>
                <p className="text-sm italic">"{story.story}"</p>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Outcome:</span>
                    <span className="text-sm font-medium">{story.outcome}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Value:</span>
                    <span className="text-sm font-medium text-green-600">{story.value}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Timeline:</span>
                    <span className="text-sm font-medium">{story.timeframe}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Networking Impact Categories */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {networkingImpact.map((category, index) => (
          <Card key={index}>
            <CardHeader>
              <CardTitle className="text-lg">{category.category}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {category.stats.map((stat, statIndex) => (
                  <div key={statIndex} className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">{stat.label}</span>
                    <div className="text-right">
                      <p className="font-semibold">{stat.value}</p>
                      <p className="text-xs text-green-600">{stat.change}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* User Testimonials */}
      <Card>
        <CardHeader>
          <CardTitle>User Testimonials</CardTitle>
          <CardDescription>What our users say about their networking success</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="border rounded-lg p-4 space-y-3">
                <div className="flex items-center space-x-1">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-current text-yellow-500" />
                  ))}
                </div>
                <p className="text-sm italic">"{testimonial.text}"</p>
                <div>
                  <p className="font-medium">{testimonial.user}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.title}</p>
                  <Badge variant="outline" className="mt-2">
                    {testimonial.outcome}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Corporate Clients */}
      <Card>
        <CardHeader>
          <CardTitle>Enterprise Clients</CardTitle>
          <CardDescription>Leading companies using our platform for employee networking</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {corporateClients.map((client, index) => (
              <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                    <span className="font-bold text-primary-foreground">{client.logo}</span>
                  </div>
                  <div>
                    <p className="font-medium">{client.name}</p>
                    <p className="text-sm text-muted-foreground">{client.users} employees</p>
                  </div>
                </div>
                <Badge variant="outline" className="text-green-600">
                  {client.engagement}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Platform Impact Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Platform Impact Summary</CardTitle>
          <CardDescription>Quantified value delivered to our ecosystem</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center p-4 border rounded-lg">
              <Heart className="h-8 w-8 text-red-500 mx-auto mb-2" />
              <p className="text-2xl font-bold">8,342</p>
              <p className="text-sm text-muted-foreground">Successful Connections Made</p>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <Briefcase className="h-8 w-8 text-blue-500 mx-auto mb-2" />
              <p className="text-2xl font-bold">1,247</p>
              <p className="text-sm text-muted-foreground">Career Opportunities Created</p>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <Building2 className="h-8 w-8 text-purple-500 mx-auto mb-2" />
              <p className="text-2xl font-bold">89</p>
              <p className="text-sm text-muted-foreground">Startups Launched</p>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <Award className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
              <p className="text-2xl font-bold">4.8/5</p>
              <p className="text-sm text-muted-foreground">Average User Rating</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}