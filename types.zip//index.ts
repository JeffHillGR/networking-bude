// Core user and app types for Networking BudE

export interface UserData {
  id: string;
  firstName: string;
  lastName: string;
  name?: string; // For backward compatibility
  email: string;
  title?: string;
  company?: string;
  location?: string;
  bio?: string;
  avatar?: string;
  skills?: string[];
  interests?: string[];
  goals?: string[];
  experience?: string;
  lookingFor?: string[];
  onboardingCompleted: boolean;
  profileComplete: boolean;
  createdAt: string;
  lastActive: string;
}

export interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  venue?: string;
  type: 'In-Person' | 'Virtual' | 'Hybrid';
  category: string;
  organizer: string;
  organizerLogo?: string;
  attendees: number;
  maxAttendees?: number;
  price?: number;
  registrationUrl?: string;
  featured: boolean;
  tags: string[];
  image?: string;
}

export interface Connection {
  id: string;
  name: string;
  title: string;
  company?: string;
  image?: string;
  bio?: string;
  commonInterests: string[];
  matchScore: number;
  mutual: number;
  status: 'pending' | 'connected' | 'declined';
  connectedAt?: string;
  lastMessage?: string;
  lastMessageTime?: string;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: string;
  read: boolean;
  type: 'text' | 'image' | 'file';
}

export interface Conversation {
  id: string;
  participantIds: string[];
  participants: UserData[];
  lastMessage?: Message;
  unreadCount: number;
  updatedAt: string;
}

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface LoadingState {
  isLoading: boolean;
  error?: string;
}

// App configuration types
export interface AppConfig {
  apiBaseUrl: string;
  environment: 'development' | 'staging' | 'production';
  version: string;
  features: {
    messaging: boolean;
    events: boolean;
    connections: boolean;
    analytics: boolean;
  };
}

// Navigation types
export interface NavItem {
  name: string;
  href: string;
  icon: any;
  badge?: number;
  mobileOnly?: boolean;
  desktopOnly?: boolean;
}

// Form types
export interface FormValidation {
  isValid: boolean;
  errors: Record<string, string>;
}

export interface OnboardingData {
  personalInfo: {
    firstName: string;
    lastName: string;
    email: string;
    title: string;
    company: string;
    location: string;
  };
  professional: {
    experience: string;
    skills: string[];
    interests: string[];
  };
  networking: {
    goals: string[];
    lookingFor: string[];
    bio: string;
  };
  preferences: {
    notifications: boolean;
    visibility: 'public' | 'connections' | 'private';
    emailUpdates: boolean;
  };
}

// Analytics types
export interface AnalyticsEvent {
  event: string;
  properties?: Record<string, any>;
  userId?: string;
  timestamp?: string;
}

// Error types
export interface AppError {
  code: string;
  message: string;
  details?: any;
  timestamp: string;
}